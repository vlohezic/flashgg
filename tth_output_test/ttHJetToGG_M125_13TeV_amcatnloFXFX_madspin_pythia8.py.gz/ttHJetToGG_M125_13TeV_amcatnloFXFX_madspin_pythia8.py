import FWCore.ParameterSet.Config as cms

process = cms.Process("FLASHggSyst")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring('root://cms-xrd-global.cern.ch//store/user/spigazzi/flashgg/Era2017_RR-31Mar2018_v2/legacyRun2FullV1/ttHJetToGG_M125_13TeV_amcatnloFXFX_madspin_pythia8/Era2017_RR-31Mar2018_v2-legacyRun2FullV1-v0-RunIIFall17MiniAODv2-PU2017_12Apr2018_94X_mc2017_realistic_v14-v1/190703_133141/0000/myMicroAODOutputFile_9.root')
)
process.CondDB = cms.PSet(
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    connect = cms.string('')
)

process.FNUFBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.00062),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00208),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(5e-05),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.00227),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.FNUFEB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.00062),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.00208),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(5e-05),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.00227),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FNUFEE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.00062),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.00208),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(5e-05),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.00227),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FNUFEE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.FracRVNvtxWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(-0.5),
                uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
                upBounds = cms.vdouble(10.5),
                values = cms.vdouble(1.02898, 0.828452)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10.5),
                uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
                upBounds = cms.vdouble(12.5),
                values = cms.vdouble(1.00775, 0.960156)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(12.5),
                uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
                upBounds = cms.vdouble(14.5),
                values = cms.vdouble(1.00406, 0.980929)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(14.5),
                uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
                upBounds = cms.vdouble(16.5),
                values = cms.vdouble(1.00159, 0.992869)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(16.5),
                uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
                upBounds = cms.vdouble(18.5),
                values = cms.vdouble(0.993201, 1.02899)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(18.5),
                uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
                upBounds = cms.vdouble(20.5),
                values = cms.vdouble(0.991425, 1.03468)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20.5),
                uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
                upBounds = cms.vdouble(22.5),
                values = cms.vdouble(0.989716, 1.03941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(22.5),
                uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
                upBounds = cms.vdouble(25.5),
                values = cms.vdouble(0.98674, 1.04837)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(25.5),
                uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
                upBounds = cms.vdouble(30.5),
                values = cms.vdouble(0.976922, 1.07893)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30.5),
                uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
                upBounds = cms.vdouble(100.5),
                values = cms.vdouble(0.959731, 1.13018)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100.5),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('nVert')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVNvtxWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('nVert<99999')
)

process.FracRVWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0),
                uncertainties = cms.vdouble(0.0244223, 0.0244223, 0.0242939, 0.0242939),
                upBounds = cms.vdouble(5),
                values = cms.vdouble(0.97405, 1.02581)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(5),
                uncertainties = cms.vdouble(0.0259363, 0.0259363, 0.0291707, 0.0291707),
                upBounds = cms.vdouble(10),
                values = cms.vdouble(0.992877, 1.00801)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(10),
                uncertainties = cms.vdouble(0.0235248, 0.0235248, 0.0324417, 0.0324417),
                upBounds = cms.vdouble(15),
                values = cms.vdouble(0.989147, 1.01497)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(15),
                uncertainties = cms.vdouble(0.0193127, 0.0193127, 0.033296, 0.033296),
                upBounds = cms.vdouble(20),
                values = cms.vdouble(0.977417, 1.03893)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(20),
                uncertainties = cms.vdouble(0.0141051, 0.0141051, 0.0368292, 0.0368292),
                upBounds = cms.vdouble(30),
                values = cms.vdouble(0.974667, 1.06613)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(30),
                uncertainties = cms.vdouble(0.0083176, 0.0083176, 0.0363466, 0.0363466),
                upBounds = cms.vdouble(40),
                values = cms.vdouble(0.979387, 1.09002)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(40),
                uncertainties = cms.vdouble(0.00576372, 0.00576372, 0.0391516, 0.0391516),
                upBounds = cms.vdouble(50),
                values = cms.vdouble(0.985972, 1.09517)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(50),
                uncertainties = cms.vdouble(0.00378304, 0.00378304, 0.0372533, 0.0372533),
                upBounds = cms.vdouble(60),
                values = cms.vdouble(0.98862, 1.11167)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(60),
                uncertainties = cms.vdouble(0.00249869, 0.00249869, 0.0378921, 0.0378921),
                upBounds = cms.vdouble(80),
                values = cms.vdouble(0.991643, 1.12609)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(80),
                uncertainties = cms.vdouble(0.00165178, 0.00165178, 0.0427137, 0.0427137),
                upBounds = cms.vdouble(100),
                values = cms.vdouble(0.994479, 1.1408)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(100),
                uncertainties = cms.vdouble(0.00117866, 0.00117866, 0.0434459, 0.0434459),
                upBounds = cms.vdouble(140),
                values = cms.vdouble(0.996918, 1.11227)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(140),
                uncertainties = cms.vdouble(0.000855418, 0.000855418, 0.0653476, 0.0653476),
                upBounds = cms.vdouble(200),
                values = cms.vdouble(0.998692, 1.09851)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(200),
                uncertainties = cms.vdouble(0.00099373, 0.00099373, 0.1642, 0.1642),
                upBounds = cms.vdouble(400),
                values = cms.vdouble(0.999521, 1.07875)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(400),
                uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
                upBounds = cms.vdouble(999999999),
                values = cms.vdouble(1, 1)
            )
        ),
        variables = cms.vstring('pt')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('FracRVWeight'),
    MethodName = cms.string('FlashggDiPhotonWeightFromFracRV'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999')
)

process.HFRecalParameterBlock = cms.PSet(
    HFdepthOneParameterA = cms.vdouble(
        0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
        0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
        0.058939, 0.125497
    ),
    HFdepthOneParameterB = cms.vdouble(
        -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
        2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
        0.000425, 0.000209
    ),
    HFdepthTwoParameterA = cms.vdouble(
        0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
        0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
        0.051579, 0.086593
    ),
    HFdepthTwoParameterB = cms.vdouble(
        -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
        1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
        0.000157, -3e-06
    )
)

process.LooseMvaSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0001),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.9999)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(1.0003)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(1.0003)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.0),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.0004)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('LooseMvaSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.MCScaleGain1EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain1EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain1&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleGain6EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleGain6EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('hasSwitchToGain6&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('100')
)

process.MCScaleHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCScaleLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MCScaleLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(

    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCScaleLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
    UncertaintyBitMask = cms.string('011')
)

process.MCSmearHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearHighR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EB_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MCSmearLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSmearConstant'),
    RandomLabel = cms.string('rnd_g_E')
)

process.MCSmearLowR9EE_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    FirstParameterName = cms.string('Rho'),
    Label = cms.string('MCSmearLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
    NSigmas = cms.PSet(
        firstVar = cms.vint32(1, -1, 0, 0),
        secondVar = cms.vint32(0, 0, 1, -1)
    ),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
    PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
    RandomLabel = cms.string('rnd_g_E'),
    SecondParameterName = cms.string('Phi')
)

process.MaterialCentralBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialCentralBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)<1.0 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialForward = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialForward'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MaterialOuterBarrel = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.000455),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(0.000233),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(0.002089),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.00109),
                upBounds = cms.vdouble(999.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.002377),
                upBounds = cms.vdouble(999.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MaterialOuterBarrel'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(superCluster.eta)>=1.0&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.MvaShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    CorrectionFile = cms.FileInPath('flashgg/Systematics/data/SystematicsIDMVA_LegRunII_v1_2017.root'),
    Debug = cms.untracked.bool(False),
    Label = cms.string('MvaShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonMvaTransform')
)

process.PixelSeedWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00401807),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00200421),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0224756),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00631264),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0162106),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.08876)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0678807),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.5961)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0263745),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.09763)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0214274),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20264)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.00415083),
                upBounds = cms.vdouble(1.5, 0.85, 0.1),
                values = cms.vdouble(0.978)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, -0.1),
                uncertainties = cms.vdouble(-0.00280026),
                upBounds = cms.vdouble(1.5, 999.0, 0.1),
                values = cms.vdouble(0.9824)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, -0.1),
                uncertainties = cms.vdouble(-0.0225538),
                upBounds = cms.vdouble(6.0, 0.9, 0.1),
                values = cms.vdouble(0.9168)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, -0.1),
                uncertainties = cms.vdouble(-0.00655045),
                upBounds = cms.vdouble(6.0, 999.0, 0.1),
                values = cms.vdouble(0.9403)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0248967),
                upBounds = cms.vdouble(1.5, 0.85, 1.1),
                values = cms.vdouble(1.13196)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85, 0.9),
                uncertainties = cms.vdouble(0.0978689),
                upBounds = cms.vdouble(1.5, 999.0, 1.1),
                values = cms.vdouble(1.61512)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0, 0.9),
                uncertainties = cms.vdouble(0.0287957),
                upBounds = cms.vdouble(6.0, 0.9, 1.1),
                values = cms.vdouble(1.10623)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9, 0.9),
                uncertainties = cms.vdouble(0.0222861),
                upBounds = cms.vdouble(6.0, 999.0, 1.1),
                values = cms.vdouble(1.20311)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9', 
            'hasPixelSeed'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PixelSeedWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.PreselSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.005),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.998)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.003),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(1.001)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.006),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(0.989)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.009),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(1.002)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('PreselSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.RVBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0),
            uncertainties = cms.vdouble(0.0244223, 0.0244223, 0.0242939, 0.0242939),
            upBounds = cms.vdouble(5),
            values = cms.vdouble(0.97405, 1.02581)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(5),
            uncertainties = cms.vdouble(0.0259363, 0.0259363, 0.0291707, 0.0291707),
            upBounds = cms.vdouble(10),
            values = cms.vdouble(0.992877, 1.00801)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10),
            uncertainties = cms.vdouble(0.0235248, 0.0235248, 0.0324417, 0.0324417),
            upBounds = cms.vdouble(15),
            values = cms.vdouble(0.989147, 1.01497)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(15),
            uncertainties = cms.vdouble(0.0193127, 0.0193127, 0.033296, 0.033296),
            upBounds = cms.vdouble(20),
            values = cms.vdouble(0.977417, 1.03893)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20),
            uncertainties = cms.vdouble(0.0141051, 0.0141051, 0.0368292, 0.0368292),
            upBounds = cms.vdouble(30),
            values = cms.vdouble(0.974667, 1.06613)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30),
            uncertainties = cms.vdouble(0.0083176, 0.0083176, 0.0363466, 0.0363466),
            upBounds = cms.vdouble(40),
            values = cms.vdouble(0.979387, 1.09002)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(40),
            uncertainties = cms.vdouble(0.00576372, 0.00576372, 0.0391516, 0.0391516),
            upBounds = cms.vdouble(50),
            values = cms.vdouble(0.985972, 1.09517)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(50),
            uncertainties = cms.vdouble(0.00378304, 0.00378304, 0.0372533, 0.0372533),
            upBounds = cms.vdouble(60),
            values = cms.vdouble(0.98862, 1.11167)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(60),
            uncertainties = cms.vdouble(0.00249869, 0.00249869, 0.0378921, 0.0378921),
            upBounds = cms.vdouble(80),
            values = cms.vdouble(0.991643, 1.12609)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(80),
            uncertainties = cms.vdouble(0.00165178, 0.00165178, 0.0427137, 0.0427137),
            upBounds = cms.vdouble(100),
            values = cms.vdouble(0.994479, 1.1408)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100),
            uncertainties = cms.vdouble(0.00117866, 0.00117866, 0.0434459, 0.0434459),
            upBounds = cms.vdouble(140),
            values = cms.vdouble(0.996918, 1.11227)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(140),
            uncertainties = cms.vdouble(0.000855418, 0.000855418, 0.0653476, 0.0653476),
            upBounds = cms.vdouble(200),
            values = cms.vdouble(0.998692, 1.09851)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(200),
            uncertainties = cms.vdouble(0.00099373, 0.00099373, 0.1642, 0.1642),
            upBounds = cms.vdouble(400),
            values = cms.vdouble(0.999521, 1.07875)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(400),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('pt')
)

process.RVBinsNvtx = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-0.5),
            uncertainties = cms.vdouble(0.00155068, 0.00155068, 0.00918045, 0.00918045),
            upBounds = cms.vdouble(10.5),
            values = cms.vdouble(1.02898, 0.828452)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(10.5),
            uncertainties = cms.vdouble(0.0013211, 0.0013211, 0.00679271, 0.00679271),
            upBounds = cms.vdouble(12.5),
            values = cms.vdouble(1.00775, 0.960156)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(12.5),
            uncertainties = cms.vdouble(0.00113947, 0.00113947, 0.00535269, 0.00535269),
            upBounds = cms.vdouble(14.5),
            values = cms.vdouble(1.00406, 0.980929)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(14.5),
            uncertainties = cms.vdouble(0.00109956, 0.00109956, 0.00493888, 0.00493888),
            upBounds = cms.vdouble(16.5),
            values = cms.vdouble(1.00159, 0.992869)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(16.5),
            uncertainties = cms.vdouble(0.00112887, 0.00112887, 0.00481407, 0.00481407),
            upBounds = cms.vdouble(18.5),
            values = cms.vdouble(0.993201, 1.02899)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(18.5),
            uncertainties = cms.vdouble(0.0012414, 0.0012414, 0.00502105, 0.00502105),
            upBounds = cms.vdouble(20.5),
            values = cms.vdouble(0.991425, 1.03468)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(20.5),
            uncertainties = cms.vdouble(0.00142369, 0.00142369, 0.00545553, 0.00545553),
            upBounds = cms.vdouble(22.5),
            values = cms.vdouble(0.989716, 1.03941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(22.5),
            uncertainties = cms.vdouble(0.00147513, 0.00147513, 0.00538112, 0.00538112),
            upBounds = cms.vdouble(25.5),
            values = cms.vdouble(0.98674, 1.04837)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(25.5),
            uncertainties = cms.vdouble(0.00188024, 0.00188024, 0.00643049, 0.00643049),
            upBounds = cms.vdouble(30.5),
            values = cms.vdouble(0.976922, 1.07893)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(30.5),
            uncertainties = cms.vdouble(0.00440431, 0.00440431, 0.0142389, 0.0142389),
            upBounds = cms.vdouble(100.5),
            values = cms.vdouble(0.959731, 1.13018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(100.5),
            uncertainties = cms.vdouble(0.0, 0.0, 0.0, 0.0),
            upBounds = cms.vdouble(999999999),
            values = cms.vdouble(1, 1)
        )
    ),
    variables = cms.vstring('nVert')
)

process.ShowerShapeHighR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeHighR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeHighR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EB = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EB'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.ShowerShapeLowR9EE = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(-0.0001),
                upBounds = cms.vdouble(1.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.0),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(1.5, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.94),
                uncertainties = cms.vdouble(-0.0006),
                upBounds = cms.vdouble(1.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.0, 0.94),
                uncertainties = cms.vdouble(-0.0011),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0015),
                upBounds = cms.vdouble(2.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.0),
                uncertainties = cms.vdouble(0.0004),
                upBounds = cms.vdouble(6.0, 0.94),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.94),
                uncertainties = cms.vdouble(0.0002),
                upBounds = cms.vdouble(2.0, 999.0),
                values = cms.vdouble(0.0)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(2.0, 0.94),
                uncertainties = cms.vdouble(0.0003),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.0)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('ShowerShapeLowR9EE'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonScale')
)

process.SigmaEOverEShift = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    BinList = cms.PSet(
        bins = cms.VPSet(cms.PSet(
            lowBounds = cms.vdouble(0.0),
            uncertainties = cms.vdouble(0.05),
            upBounds = cms.vdouble(999.0),
            values = cms.vdouble(0.0)
        )),
        variables = cms.vstring('abs(superCluster.eta)')
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverEShift'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSigEOverEShift')
)

process.SigmaEOverESmearing = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(

    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearing')
)

process.SigmaEOverESmearing_EGM = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(),
        variables = cms.vstring('1')
    ),
    CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
    Debug = cms.untracked.bool(False),
    ExaggerateShiftUp = cms.bool(False),
    Label = cms.string('SigmaEOverESmearing'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(),
    OverallRange = cms.string('1'),
    PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
)

process.TriggerWeight = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
                upBounds = cms.vdouble(0.54, 1.5, 37.0),
                values = cms.vdouble(0.9204369513)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 37),
                uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
                upBounds = cms.vdouble(0.54, 1.5, 40.0),
                values = cms.vdouble(0.9268543618)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
                upBounds = cms.vdouble(0.54, 1.5, 45.0),
                values = cms.vdouble(0.9296864506)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
                upBounds = cms.vdouble(0.54, 1.5, 50.0),
                values = cms.vdouble(0.9312181087)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
                upBounds = cms.vdouble(0.54, 1.5, 60.0),
                values = cms.vdouble(0.9349061049)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
                upBounds = cms.vdouble(0.54, 1.5, 70.0),
                values = cms.vdouble(0.9425532022)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
                upBounds = cms.vdouble(0.54, 1.5, 90.0),
                values = cms.vdouble(0.9347621741)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.017714307, 0.017714307),
                upBounds = cms.vdouble(0.54, 1.5, 99999999),
                values = cms.vdouble(0.9489236873)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 37.0),
                values = cms.vdouble(0.9505374744)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.9559316002)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.960322746)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9628461917)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9662884361)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9715136996)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.9753661262)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.9818196687)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 37.0),
                values = cms.vdouble(0.9630117411)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.9680310533)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9721152461)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.9748189645)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9747597366)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.9753162174)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.9803243059)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9865482764)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
                upBounds = cms.vdouble(0.84, 3.0, 37.0),
                values = cms.vdouble(0.9093169942)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 37.0),
                uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
                upBounds = cms.vdouble(0.84, 3.0, 40.0),
                values = cms.vdouble(0.9214136806)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.84, 3.0, 45.0),
                values = cms.vdouble(0.9396498081)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
                upBounds = cms.vdouble(0.84, 3.0, 50.0),
                values = cms.vdouble(0.9455103913)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.00165793, 0.00165793),
                upBounds = cms.vdouble(0.84, 3.0, 60.0),
                values = cms.vdouble(0.9519493209)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
                upBounds = cms.vdouble(0.84, 3.0, 70.0),
                values = cms.vdouble(0.9560088523)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
                upBounds = cms.vdouble(0.84, 3.0, 90.0),
                values = cms.vdouble(0.9638480843)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
                upBounds = cms.vdouble(0.84, 3.0, 99999999),
                values = cms.vdouble(0.9714734218)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 37.0),
                values = cms.vdouble(0.961495108)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9750837371)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.9814701227)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9835352074)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9851237595)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.9869551174)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9916069861)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.9958525312)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 37.0),
                values = cms.vdouble(0.9470889409)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 37.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9646677794)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.9738993606)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9784039943)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.980234517)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.9828741312)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.9870534958)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9891255039)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    BinList2 = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001420359, 0.001420359),
                upBounds = cms.vdouble(0.54, 1.5, 28.0),
                values = cms.vdouble(0.9503915847)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 28.0),
                uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
                upBounds = cms.vdouble(0.54, 1.5, 31.0),
                values = cms.vdouble(0.9563040539)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 35.0),
                values = cms.vdouble(0.9554701294)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 40.0),
                values = cms.vdouble(0.9573495211)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.54, 1.5, 45.0),
                values = cms.vdouble(0.9615640328)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
                upBounds = cms.vdouble(0.54, 1.5, 50.0),
                values = cms.vdouble(0.9635847522)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
                upBounds = cms.vdouble(0.54, 1.5, 60.0),
                values = cms.vdouble(0.9613424282)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
                upBounds = cms.vdouble(0.54, 1.5, 70.0),
                values = cms.vdouble(0.953179846)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
                upBounds = cms.vdouble(0.54, 1.5, 90.0),
                values = cms.vdouble(0.9427949472)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
                upBounds = cms.vdouble(0.54, 1.5, 99999999),
                values = cms.vdouble(0.9180892383)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 28.0),
                values = cms.vdouble(0.9821722615)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 31.0),
                values = cms.vdouble(0.9846684256)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 35.0),
                values = cms.vdouble(0.9853409044)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 40.0),
                values = cms.vdouble(0.9851741151)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 45.0),
                values = cms.vdouble(0.9847237955)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 50.0),
                values = cms.vdouble(0.9836985511)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 60.0),
                values = cms.vdouble(0.9818687985)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 70.0),
                values = cms.vdouble(0.9793978257)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.85, 1.5, 90.0),
                values = cms.vdouble(0.9766027088)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
                upBounds = cms.vdouble(0.85, 1.5, 99999999),
                values = cms.vdouble(0.972331437)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 28.0),
                values = cms.vdouble(0.9997101832)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 31.0),
                values = cms.vdouble(0.9998675478)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 35.0),
                values = cms.vdouble(0.9999351175)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 40.0),
                values = cms.vdouble(0.999954156)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 45.0),
                values = cms.vdouble(0.9999645283)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 50.0),
                values = cms.vdouble(0.9999677894)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 60.0),
                values = cms.vdouble(0.9999665309)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 70.0),
                values = cms.vdouble(0.9999602573)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 90.0),
                values = cms.vdouble(0.9999369329)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 1.5, 99999999),
                values = cms.vdouble(0.9999456063)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
                upBounds = cms.vdouble(0.84, 3.0, 28.0),
                values = cms.vdouble(0.8799714219)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 28.0),
                uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
                upBounds = cms.vdouble(0.84, 3.0, 31.0),
                values = cms.vdouble(0.8962741603)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 31.0),
                uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
                upBounds = cms.vdouble(0.84, 3.0, 35.0),
                values = cms.vdouble(0.9042685088)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
                upBounds = cms.vdouble(0.84, 3.0, 40.0),
                values = cms.vdouble(0.9130894467)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
                upBounds = cms.vdouble(0.84, 3.0, 45.0),
                values = cms.vdouble(0.9236887059)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
                upBounds = cms.vdouble(0.84, 3.0, 50.0),
                values = cms.vdouble(0.926909296)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001993287, 0.001993287),
                upBounds = cms.vdouble(0.84, 3.0, 60.0),
                values = cms.vdouble(0.9300621013)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
                upBounds = cms.vdouble(0.84, 3.0, 70.0),
                values = cms.vdouble(0.9313708557)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
                upBounds = cms.vdouble(0.84, 3.0, 90.0),
                values = cms.vdouble(0.9387860583)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                uncertainties = cms.vdouble(0.007718235, 0.007718235),
                upBounds = cms.vdouble(0.84, 3.0, 99999999),
                values = cms.vdouble(0.9316696569)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
                upBounds = cms.vdouble(0.9, 3.0, 28.0),
                values = cms.vdouble(0.9482346612)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 31.0),
                values = cms.vdouble(0.9753440965)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 35.0),
                values = cms.vdouble(0.9760310914)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 40.0),
                values = cms.vdouble(0.9752981073)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 45.0),
                values = cms.vdouble(0.973705016)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 50.0),
                values = cms.vdouble(0.9719236369)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(0.9, 3.0, 60.0),
                values = cms.vdouble(0.9704295117)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
                upBounds = cms.vdouble(0.9, 3.0, 70.0),
                values = cms.vdouble(0.9692422639)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
                upBounds = cms.vdouble(0.9, 3.0, 90.0),
                values = cms.vdouble(0.9692330221)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
                upBounds = cms.vdouble(0.9, 3.0, 99999999),
                values = cms.vdouble(0.972663036)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 28.0),
                values = cms.vdouble(0.9706915047)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 28.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 31.0),
                values = cms.vdouble(0.9975115605)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 31.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 35.0),
                values = cms.vdouble(0.9992706525)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 40.0),
                values = cms.vdouble(0.9995305126)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 45.0),
                values = cms.vdouble(0.9995836941)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 50.0),
                values = cms.vdouble(0.9996279004)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 60.0),
                values = cms.vdouble(0.9995678968)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 70.0),
                values = cms.vdouble(0.9996782105)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 90.0),
                values = cms.vdouble(0.9997202663)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                uncertainties = cms.vdouble(0.001, 0.001),
                upBounds = cms.vdouble(999, 3.0, 99999999),
                values = cms.vdouble(0.9993842985)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 3.0, 0),
                uncertainties = cms.vdouble(1.0, 1.0),
                upBounds = cms.vdouble(999, 999, 999999),
                values = cms.vdouble(1.0)
            )
        ),
        variables = cms.vstring(
            'full5x5_r9', 
            'abs(superCluster.eta)', 
            'pt'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('TriggerWeight'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('pt<99999 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.binInfo2016 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(-6.0, 0.0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2.5, 9999999.0),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(-2, 20),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(-2, 35),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(-2, 50),
            values = cms.vdouble(0.999)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(-2, 100),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(-2, 200),
            values = cms.vdouble(1.014)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 200),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 500),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2.5, 500),
            uncertainties = cms.vdouble(0.089),
            upBounds = cms.vdouble(-2, 999999999),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(-1.566, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(-1.566, 20),
            values = cms.vdouble(0.962)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(-1.566, 35),
            values = cms.vdouble(0.951)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 50),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(-1.566, 100),
            values = cms.vdouble(0.977)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 100),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(-1.566, 200),
            values = cms.vdouble(0.983)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 500),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-2, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(-1.566, 99999999),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-1.566, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(-1.444, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 20),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0, 35),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0, 100),
            values = cms.vdouble(0.963)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0, 200),
            values = cms.vdouble(0.982)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 500),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(-0.8, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0, 99999999),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(0.8, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 10),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 20),
            values = cms.vdouble(0.954)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 20),
            uncertainties = cms.vdouble(0.015),
            upBounds = cms.vdouble(0.8, 35),
            values = cms.vdouble(0.966)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 35),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(0.8, 50),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(0.8, 100),
            values = cms.vdouble(0.979)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 100),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(0.8, 200),
            values = cms.vdouble(0.991)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 200),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 500),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0, 500),
            uncertainties = cms.vdouble(0.023),
            upBounds = cms.vdouble(0.8, 99999999),
            values = cms.vdouble(0.976)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(1.444, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 10),
            uncertainties = cms.vdouble(0.11),
            upBounds = cms.vdouble(1.444, 20),
            values = cms.vdouble(0.974)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 20),
            uncertainties = cms.vdouble(0.018),
            upBounds = cms.vdouble(1.444, 35),
            values = cms.vdouble(0.947)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 35),
            uncertainties = cms.vdouble(0.004),
            upBounds = cms.vdouble(1.444, 50),
            values = cms.vdouble(0.965)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 50),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(1.444, 100),
            values = cms.vdouble(0.97)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(1.444, 200),
            values = cms.vdouble(0.99)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 200),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 500),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 500),
            uncertainties = cms.vdouble(0.025),
            upBounds = cms.vdouble(1.444, 9999999),
            values = cms.vdouble(0.984)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 0),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 10),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 10),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 20),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 20),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 35),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 35),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 50),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 50),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 100),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 100),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 200),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 200),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 500),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.444, 500),
            uncertainties = cms.vdouble(1),
            upBounds = cms.vdouble(1.566, 9999999),
            values = cms.vdouble(1)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 10),
            uncertainties = cms.vdouble(0.017),
            upBounds = cms.vdouble(2, 20),
            values = cms.vdouble(0.971)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 20),
            uncertainties = cms.vdouble(0.012),
            upBounds = cms.vdouble(2, 35),
            values = cms.vdouble(0.933)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 35),
            uncertainties = cms.vdouble(0.01),
            upBounds = cms.vdouble(2, 50),
            values = cms.vdouble(0.957)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 50),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(2, 100),
            values = cms.vdouble(0.968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 100),
            uncertainties = cms.vdouble(0.011),
            upBounds = cms.vdouble(2, 200),
            values = cms.vdouble(0.995)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 200),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 500),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.566, 500),
            uncertainties = cms.vdouble(0.043),
            upBounds = cms.vdouble(2, 99999999),
            values = cms.vdouble(0.952)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(2.5, 10),
            values = cms.vdouble(1.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 10),
            uncertainties = cms.vdouble(0.021),
            upBounds = cms.vdouble(2.5, 20),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 20),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(2.5, 35),
            values = cms.vdouble(0.953)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 35),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(2.5, 50),
            values = cms.vdouble(0.961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 50),
            uncertainties = cms.vdouble(0.008),
            upBounds = cms.vdouble(2.5, 100),
            values = cms.vdouble(0.969)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 100),
            uncertainties = cms.vdouble(0.032),
            upBounds = cms.vdouble(2.5, 200),
            values = cms.vdouble(0.994)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 200),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 500),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2, 500),
            uncertainties = cms.vdouble(0.09),
            upBounds = cms.vdouble(2.5, 999999999),
            values = cms.vdouble(1.018)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.5, 0.0),
            uncertainties = cms.vdouble(0.001),
            upBounds = cms.vdouble(6.0, 999999999.0),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'eta', 
        'pt'
    )
)

process.electronVetoBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0023),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.982)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0006),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.9911)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0076),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(0.9639)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.002),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.983)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.electronVetoSF = cms.PSet(
    ApplyCentralValue = cms.bool(True),
    BinList = cms.PSet(
        bins = cms.VPSet(
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.0),
                uncertainties = cms.vdouble(0.0023),
                upBounds = cms.vdouble(1.5, 0.85),
                values = cms.vdouble(0.982)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(0.0, 0.85),
                uncertainties = cms.vdouble(0.0006),
                upBounds = cms.vdouble(1.5, 999.0),
                values = cms.vdouble(0.9911)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.0),
                uncertainties = cms.vdouble(0.0076),
                upBounds = cms.vdouble(6.0, 0.9),
                values = cms.vdouble(0.9639)
            ), 
            cms.PSet(
                lowBounds = cms.vdouble(1.5, 0.9),
                uncertainties = cms.vdouble(0.002),
                upBounds = cms.vdouble(6.0, 999.0),
                values = cms.vdouble(0.983)
            )
        ),
        variables = cms.vstring(
            'abs(superCluster.eta)', 
            'full5x5_r9'
        )
    ),
    Debug = cms.untracked.bool(False),
    Label = cms.string('electronVetoSF'),
    MethodName = cms.string('FlashggDiPhotonFromPhoton'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('1 && full5x5_r9>0.'),
    PhotonMethodName = cms.string('FlashggPhotonWeight')
)

process.emptyBins = cms.PSet(
    bins = cms.VPSet(),
    variables = cms.vstring('1')
)

process.emptySigma = cms.PSet(
    firstVar = cms.vint32(),
    secondVar = cms.vint32()
)

process.globalVariables = cms.PSet(
    dataPu = cms.vdouble(
        6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
        0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
        0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
        0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
        0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
        0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
        0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
        0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
        0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
        0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
        0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
        0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
        0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
        5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
        5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
        7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
        1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
        1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
        1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
        8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
    ),
    extraFloats = cms.PSet(

    ),
    mcPu = cms.vdouble(
        0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
        0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
        0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
        0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
        0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
        0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
        0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
        0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
        0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
        0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
        0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
        0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
        0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
        0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
        0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
        0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
        0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
        0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
        8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
        0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
    ),
    puBins = cms.vdouble(
        0.0, 1.0, 2.0, 3.0, 4.0, 
        5.0, 6.0, 7.0, 8.0, 9.0, 
        10.0, 11.0, 12.0, 13.0, 14.0, 
        15.0, 16.0, 17.0, 18.0, 19.0, 
        20.0, 21.0, 22.0, 23.0, 24.0, 
        25.0, 26.0, 27.0, 28.0, 29.0, 
        30.0, 31.0, 32.0, 33.0, 34.0, 
        35.0, 36.0, 37.0, 38.0, 39.0, 
        40.0, 41.0, 42.0, 43.0, 44.0, 
        45.0, 46.0, 47.0, 48.0, 49.0, 
        50.0, 51.0, 52.0, 53.0, 54.0, 
        55.0, 56.0, 57.0, 58.0, 59.0, 
        60.0, 61.0, 62.0, 63.0, 64.0, 
        65.0, 66.0, 67.0, 68.0, 69.0, 
        70.0, 71.0, 72.0, 73.0, 74.0, 
        75.0, 76.0, 77.0, 78.0, 79.0, 
        80.0, 81.0, 82.0, 83.0, 84.0, 
        85.0, 86.0, 87.0, 88.0, 89.0, 
        90.0, 91.0, 92.0, 93.0, 94.0, 
        95.0, 96.0, 97.0, 98.0, 99.0
    ),
    puInfo = cms.InputTag("slimmedAddPileupInfo"),
    puReWeight = cms.bool(True),
    rho = cms.InputTag("fixedGridRhoAll"),
    useTruePu = cms.bool(True),
    vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
)

process.leadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00401807),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00200421),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0224756),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00631264),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0162106),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.08876)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0678807),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.5961)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0263745),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.09763)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0214274),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20264)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.leadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
            upBounds = cms.vdouble(0.54, 1.5, 37.0),
            values = cms.vdouble(0.9204369513)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 37),
            uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
            upBounds = cms.vdouble(0.54, 1.5, 40.0),
            values = cms.vdouble(0.9268543618)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
            upBounds = cms.vdouble(0.54, 1.5, 45.0),
            values = cms.vdouble(0.9296864506)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
            upBounds = cms.vdouble(0.54, 1.5, 50.0),
            values = cms.vdouble(0.9312181087)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
            upBounds = cms.vdouble(0.54, 1.5, 60.0),
            values = cms.vdouble(0.9349061049)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
            upBounds = cms.vdouble(0.54, 1.5, 70.0),
            values = cms.vdouble(0.9425532022)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
            upBounds = cms.vdouble(0.54, 1.5, 90.0),
            values = cms.vdouble(0.9347621741)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.017714307, 0.017714307),
            upBounds = cms.vdouble(0.54, 1.5, 99999999),
            values = cms.vdouble(0.9489236873)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 37.0),
            values = cms.vdouble(0.9505374744)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.9559316002)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.960322746)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9628461917)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9662884361)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9715136996)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.9753661262)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.9818196687)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 37.0),
            values = cms.vdouble(0.9630117411)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.9680310533)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9721152461)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.9748189645)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9747597366)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.9753162174)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.9803243059)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9865482764)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
            upBounds = cms.vdouble(0.84, 3.0, 37.0),
            values = cms.vdouble(0.9093169942)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 37.0),
            uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
            upBounds = cms.vdouble(0.84, 3.0, 40.0),
            values = cms.vdouble(0.9214136806)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.84, 3.0, 45.0),
            values = cms.vdouble(0.9396498081)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
            upBounds = cms.vdouble(0.84, 3.0, 50.0),
            values = cms.vdouble(0.9455103913)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.00165793, 0.00165793),
            upBounds = cms.vdouble(0.84, 3.0, 60.0),
            values = cms.vdouble(0.9519493209)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
            upBounds = cms.vdouble(0.84, 3.0, 70.0),
            values = cms.vdouble(0.9560088523)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
            upBounds = cms.vdouble(0.84, 3.0, 90.0),
            values = cms.vdouble(0.9638480843)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
            upBounds = cms.vdouble(0.84, 3.0, 99999999),
            values = cms.vdouble(0.9714734218)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 37.0),
            values = cms.vdouble(0.961495108)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9750837371)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.9814701227)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9835352074)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9851237595)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.9869551174)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9916069861)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.9958525312)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 37.0),
            values = cms.vdouble(0.9470889409)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 37.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9646677794)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.9738993606)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9784039943)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.980234517)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.9828741312)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.9870534958)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9891255039)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.looseMvaBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0001),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.9999)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(1.0003)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(1.0003)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.0004)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsICHEP = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.0007),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00036),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00089),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.0017),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsMoriond17 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.000455),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.000233),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.002089),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.00109),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.002377),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.materialBinsRun1 = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.00035),
            upBounds = cms.vdouble(0.8, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(0.00033),
            upBounds = cms.vdouble(0.8, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.0),
            uncertainties = cms.vdouble(0.00058),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.8, 0.94),
            uncertainties = cms.vdouble(0.0012),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0022),
            upBounds = cms.vdouble(999.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0034),
            upBounds = cms.vdouble(999.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(1000)
)

process.metJecSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJecUncertainty'),
    MethodName = cms.string('FlashggMetJecSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metJerSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metJerUncertainty'),
    MethodName = cms.string('FlashggMetJerSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metPhoSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metPhoUncertainty'),
    MethodName = cms.string('FlashggMetPhoSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.metUncSmear = cms.PSet(
    ApplyCentralValue = cms.bool(False),
    Debug = cms.untracked.bool(False),
    Label = cms.string('metUncUncertainty'),
    MethodName = cms.string('FlashggMetUncSmear'),
    NSigmas = cms.vint32(-1, 1),
    OverallRange = cms.string('abs(eta)<2.5')
)

process.mvaShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.0),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.options = cms.untracked.PSet(
    allowUnscheduled = cms.untracked.bool(True),
    wantSummary = cms.untracked.bool(True)
)

process.photonScaleUncertBins = cms.PSet(

)

process.photonSmearBins = cms.PSet(

)

process.preselBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(0.005),
            upBounds = cms.vdouble(1.5, 0.85),
            values = cms.vdouble(0.998)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85),
            uncertainties = cms.vdouble(0.003),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(1.001)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.006),
            upBounds = cms.vdouble(6.0, 0.9),
            values = cms.vdouble(0.989)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9),
            uncertainties = cms.vdouble(0.009),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(1.002)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.regressionModifier = cms.PSet(
    eOverP_ECALTRKThr = cms.double(0.025),
    electron_config = cms.PSet(
        regressionKey = cms.vstring(
            'electron_eb_ECALonly_lowpt', 
            'electron_eb_ECALonly', 
            'electron_ee_ECALonly_lowpt', 
            'electron_ee_ECALonly', 
            'electron_eb_ECALTRK_lowpt', 
            'electron_eb_ECALTRK', 
            'electron_ee_ECALTRK_lowpt', 
            'electron_ee_ECALTRK'
        ),
        uncertaintyKey = cms.vstring(
            'electron_eb_ECALonly_lowpt_var', 
            'electron_eb_ECALonly_var', 
            'electron_ee_ECALonly_lowpt_var', 
            'electron_ee_ECALonly_var', 
            'electron_eb_ECALTRK_lowpt_var', 
            'electron_eb_ECALTRK_var', 
            'electron_ee_ECALTRK_lowpt_var', 
            'electron_ee_ECALTRK_var'
        )
    ),
    epDiffSig_ECALTRKThr = cms.double(15.0),
    epSig_ECALTRKThr = cms.double(10.0),
    forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
    highEnergy_ECALTRKThr = cms.double(200.0),
    lowEnergy_ECALTRKThr = cms.double(50.0),
    lowEnergy_ECALonlyThr = cms.double(99999.0),
    modifierName = cms.string('EGRegressionModifierV2'),
    photon_config = cms.PSet(
        regressionKey = cms.vstring(
            'photon_eb_ECALonly_lowpt', 
            'photon_eb_ECALonly', 
            'photon_ee_ECALonly_lowpt', 
            'photon_ee_ECALonly'
        ),
        uncertaintyKey = cms.vstring(
            'photon_eb_ECALonly_lowpt_var', 
            'photon_eb_ECALonly_var', 
            'photon_ee_ECALonly_lowpt_var', 
            'photon_ee_ECALonly_var'
        )
    ),
    rhoCollection = cms.InputTag("fixedGridRhoFastjetAllTmp")
)

process.showerShapeBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0),
            uncertainties = cms.vdouble(-0.0001),
            upBounds = cms.vdouble(1.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.0),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(1.5, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.94),
            uncertainties = cms.vdouble(-0.0006),
            upBounds = cms.vdouble(1.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.0, 0.94),
            uncertainties = cms.vdouble(-0.0011),
            upBounds = cms.vdouble(1.5, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0),
            uncertainties = cms.vdouble(0.0015),
            upBounds = cms.vdouble(2.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.0),
            uncertainties = cms.vdouble(0.0004),
            upBounds = cms.vdouble(6.0, 0.94),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.94),
            uncertainties = cms.vdouble(0.0002),
            upBounds = cms.vdouble(2.0, 999.0),
            values = cms.vdouble(0.0)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(2.0, 0.94),
            uncertainties = cms.vdouble(0.0003),
            upBounds = cms.vdouble(6.0, 999.0),
            values = cms.vdouble(0.0)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9'
    )
)

process.sigmaEOverEShiftBins = cms.PSet(
    bins = cms.VPSet(cms.PSet(
        lowBounds = cms.vdouble(0.0),
        uncertainties = cms.vdouble(0.05),
        upBounds = cms.vdouble(999.0),
        values = cms.vdouble(0.0)
    )),
    variables = cms.vstring('abs(superCluster.eta)')
)

process.subleadPixelSeedBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.00415083),
            upBounds = cms.vdouble(1.5, 0.85, 0.1),
            values = cms.vdouble(0.978)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, -0.1),
            uncertainties = cms.vdouble(-0.00280026),
            upBounds = cms.vdouble(1.5, 999.0, 0.1),
            values = cms.vdouble(0.9824)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, -0.1),
            uncertainties = cms.vdouble(-0.0225538),
            upBounds = cms.vdouble(6.0, 0.9, 0.1),
            values = cms.vdouble(0.9168)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, -0.1),
            uncertainties = cms.vdouble(-0.00655045),
            upBounds = cms.vdouble(6.0, 999.0, 0.1),
            values = cms.vdouble(0.9403)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0248967),
            upBounds = cms.vdouble(1.5, 0.85, 1.1),
            values = cms.vdouble(1.13196)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.85, 0.9),
            uncertainties = cms.vdouble(0.0978689),
            upBounds = cms.vdouble(1.5, 999.0, 1.1),
            values = cms.vdouble(1.61512)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.0, 0.9),
            uncertainties = cms.vdouble(0.0287957),
            upBounds = cms.vdouble(6.0, 0.9, 1.1),
            values = cms.vdouble(1.10623)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(1.5, 0.9, 0.9),
            uncertainties = cms.vdouble(0.0222861),
            upBounds = cms.vdouble(6.0, 999.0, 1.1),
            values = cms.vdouble(1.20311)
        )
    ),
    variables = cms.vstring(
        'abs(superCluster.eta)', 
        'full5x5_r9', 
        'hasPixelSeed'
    )
)

process.subleadTriggerScaleBins = cms.PSet(
    bins = cms.VPSet(
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001420359, 0.001420359),
            upBounds = cms.vdouble(0.54, 1.5, 28.0),
            values = cms.vdouble(0.9503915847)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 28.0),
            uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
            upBounds = cms.vdouble(0.54, 1.5, 31.0),
            values = cms.vdouble(0.9563040539)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 35.0),
            values = cms.vdouble(0.9554701294)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 40.0),
            values = cms.vdouble(0.9573495211)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.54, 1.5, 45.0),
            values = cms.vdouble(0.9615640328)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 45.0),
            uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
            upBounds = cms.vdouble(0.54, 1.5, 50.0),
            values = cms.vdouble(0.9635847522)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 50.0),
            uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
            upBounds = cms.vdouble(0.54, 1.5, 60.0),
            values = cms.vdouble(0.9613424282)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 60.0),
            uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
            upBounds = cms.vdouble(0.54, 1.5, 70.0),
            values = cms.vdouble(0.953179846)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 70.0),
            uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
            upBounds = cms.vdouble(0.54, 1.5, 90.0),
            values = cms.vdouble(0.9427949472)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
            upBounds = cms.vdouble(0.54, 1.5, 99999999),
            values = cms.vdouble(0.9180892383)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 28.0),
            values = cms.vdouble(0.9821722615)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 31.0),
            values = cms.vdouble(0.9846684256)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 35.0),
            values = cms.vdouble(0.9853409044)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 40.0),
            values = cms.vdouble(0.9851741151)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 45.0),
            values = cms.vdouble(0.9847237955)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 50.0),
            values = cms.vdouble(0.9836985511)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 60.0),
            values = cms.vdouble(0.9818687985)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 70.0),
            values = cms.vdouble(0.9793978257)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.85, 1.5, 90.0),
            values = cms.vdouble(0.9766027088)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.54, 0.0, 90.0),
            uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
            upBounds = cms.vdouble(0.85, 1.5, 99999999),
            values = cms.vdouble(0.972331437)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 28.0),
            values = cms.vdouble(0.9997101832)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 31.0),
            values = cms.vdouble(0.9998675478)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 35.0),
            values = cms.vdouble(0.9999351175)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 40.0),
            values = cms.vdouble(0.999954156)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 45.0),
            values = cms.vdouble(0.9999645283)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 50.0),
            values = cms.vdouble(0.9999677894)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 60.0),
            values = cms.vdouble(0.9999665309)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 70.0),
            values = cms.vdouble(0.9999602573)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 90.0),
            values = cms.vdouble(0.9999369329)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.85, 0.0, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 1.5, 99999999),
            values = cms.vdouble(0.9999456063)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
            upBounds = cms.vdouble(0.84, 3.0, 28.0),
            values = cms.vdouble(0.8799714219)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 28.0),
            uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
            upBounds = cms.vdouble(0.84, 3.0, 31.0),
            values = cms.vdouble(0.8962741603)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 31.0),
            uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
            upBounds = cms.vdouble(0.84, 3.0, 35.0),
            values = cms.vdouble(0.9042685088)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 35.0),
            uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
            upBounds = cms.vdouble(0.84, 3.0, 40.0),
            values = cms.vdouble(0.9130894467)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 40.0),
            uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
            upBounds = cms.vdouble(0.84, 3.0, 45.0),
            values = cms.vdouble(0.9236887059)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 45.0),
            uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
            upBounds = cms.vdouble(0.84, 3.0, 50.0),
            values = cms.vdouble(0.926909296)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001993287, 0.001993287),
            upBounds = cms.vdouble(0.84, 3.0, 60.0),
            values = cms.vdouble(0.9300621013)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
            upBounds = cms.vdouble(0.84, 3.0, 70.0),
            values = cms.vdouble(0.9313708557)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
            upBounds = cms.vdouble(0.84, 3.0, 90.0),
            values = cms.vdouble(0.9387860583)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 1.5, 90.0),
            uncertainties = cms.vdouble(0.007718235, 0.007718235),
            upBounds = cms.vdouble(0.84, 3.0, 99999999),
            values = cms.vdouble(0.9316696569)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 0.0),
            uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
            upBounds = cms.vdouble(0.9, 3.0, 28.0),
            values = cms.vdouble(0.9482346612)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 31.0),
            values = cms.vdouble(0.9753440965)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 35.0),
            values = cms.vdouble(0.9760310914)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 40.0),
            values = cms.vdouble(0.9752981073)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 45.0),
            values = cms.vdouble(0.973705016)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 50.0),
            values = cms.vdouble(0.9719236369)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(0.9, 3.0, 60.0),
            values = cms.vdouble(0.9704295117)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 60.0),
            uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
            upBounds = cms.vdouble(0.9, 3.0, 70.0),
            values = cms.vdouble(0.9692422639)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 70.0),
            uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
            upBounds = cms.vdouble(0.9, 3.0, 90.0),
            values = cms.vdouble(0.9692330221)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.84, 1.5, 90.0),
            uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
            upBounds = cms.vdouble(0.9, 3.0, 99999999),
            values = cms.vdouble(0.972663036)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 0.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 28.0),
            values = cms.vdouble(0.9706915047)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 28.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 31.0),
            values = cms.vdouble(0.9975115605)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 31.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 35.0),
            values = cms.vdouble(0.9992706525)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 35.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 40.0),
            values = cms.vdouble(0.9995305126)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 40.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 45.0),
            values = cms.vdouble(0.9995836941)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 45.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 50.0),
            values = cms.vdouble(0.9996279004)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 50.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 60.0),
            values = cms.vdouble(0.9995678968)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 60.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 70.0),
            values = cms.vdouble(0.9996782105)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 70.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 90.0),
            values = cms.vdouble(0.9997202663)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.9, 1.5, 90.0),
            uncertainties = cms.vdouble(0.001, 0.001),
            upBounds = cms.vdouble(999, 3.0, 99999999),
            values = cms.vdouble(0.9993842985)
        ), 
        cms.PSet(
            lowBounds = cms.vdouble(0.0, 3.0, 0),
            uncertainties = cms.vdouble(1.0, 1.0),
            upBounds = cms.vdouble(999, 999, 999999),
            values = cms.vdouble(1.0)
        )
    ),
    variables = cms.vstring(
        'full5x5_r9', 
        'abs(superCluster.eta)', 
        'pt'
    )
)

process.tagsDumpConfig = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string(''),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(1000.0),
    lumiWeight = cms.double(4.89377454824e-05),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('tth_125'),
    processIndex = cms.int32(-125300),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag(""),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.ak4CaloL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAllCalo")
)


process.ak4CaloL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4CaloL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector")
)


process.ak4CaloL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloL6SLBCorrector")
)


process.ak4CaloL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL2RelativeCorrector", "ak4CaloL3AbsoluteCorrector", "ak4CaloResidualCorrector")
)


process.ak4CaloL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2Relative')
)


process.ak4CaloL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L3Absolute')
)


process.ak4CaloL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(True),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4CaloJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4CaloJetsSoftMuonTagInfos")
)


process.ak4CaloResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK5Calo'),
    level = cms.string('L2L3Residual')
)


process.ak4JPTL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1FastjetCorrector", "ak4L1JPTFastjetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector")
)


process.ak4JPTL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4CaloL1OffsetCorrector", "ak4L1JPTOffsetCorrector", "ak4JPTL2RelativeCorrector", "ak4JPTL3AbsoluteCorrector", "ak4JPTResidualCorrector")
)


process.ak4JPTL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2Relative')
)


process.ak4JPTL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L3Absolute')
)


process.ak4JPTResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L2L3Residual')
)


process.ak4L1JPTFastjetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1FastjetCorrector")
)


process.ak4L1JPTOffsetCorrector = cms.EDProducer("L1JPTOffsetCorrectorProducer",
    algorithm = cms.string('AK4JPT'),
    level = cms.string('L1JPTOffset'),
    offsetService = cms.InputTag("ak4CaloL1OffsetCorrector")
)


process.ak4PFCHSL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1FastjetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFCHSL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL1OffsetCorrector", "ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFCHSL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector")
)


process.ak4PFCHSL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFCHSL2RelativeCorrector", "ak4PFCHSL3AbsoluteCorrector", "ak4PFCHSResidualCorrector")
)


process.ak4PFCHSL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2Relative')
)


process.ak4PFCHSL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L3Absolute')
)


process.ak4PFCHSResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFchs'),
    level = cms.string('L2L3Residual')
)


process.ak4PFL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1FastL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1FastjetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL1OffsetCorrector", "ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector")
)


process.ak4PFL2L3L6Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFL6SLBCorrector")
)


process.ak4PFL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFL2RelativeCorrector", "ak4PFL3AbsoluteCorrector", "ak4PFResidualCorrector")
)


process.ak4PFL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2Relative')
)


process.ak4PFL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L3Absolute')
)


process.ak4PFL6SLBCorrector = cms.EDProducer("L6SLBCorrectorProducer",
    addMuonToJet = cms.bool(False),
    algorithm = cms.string(''),
    level = cms.string('L6SLB'),
    srcBTagInfoElectron = cms.InputTag("ak4PFJetsSoftElectronTagInfos"),
    srcBTagInfoMuon = cms.InputTag("ak4PFJetsSoftMuonTagInfos")
)


process.ak4PFPuppiL1FastL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1FastL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1FastjetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1FastjetCorrector = cms.EDProducer("L1FastjetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1FastJet'),
    srcRho = cms.InputTag("fixedGridRhoFastjetAll")
)


process.ak4PFPuppiL1L2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL1L2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL1OffsetCorrector", "ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL1OffsetCorrector = cms.EDProducer("L1OffsetCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L1Offset'),
    minVtxNdof = cms.int32(4),
    vertexCollection = cms.InputTag("offlinePrimaryVertices")
)


process.ak4PFPuppiL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector")
)


process.ak4PFPuppiL2L3ResidualCorrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4PFPuppiL2RelativeCorrector", "ak4PFPuppiL3AbsoluteCorrector", "ak4PFPuppiResidualCorrector")
)


process.ak4PFPuppiL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2Relative')
)


process.ak4PFPuppiL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L3Absolute')
)


process.ak4PFPuppiResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PFPuppi'),
    level = cms.string('L2L3Residual')
)


process.ak4PFResidualCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4PF'),
    level = cms.string('L2L3Residual')
)


process.ak4TrackL2L3Corrector = cms.EDProducer("ChainedJetCorrectorProducer",
    correctors = cms.VInputTag("ak4TrackL2RelativeCorrector", "ak4TrackL3AbsoluteCorrector")
)


process.ak4TrackL2RelativeCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L2Relative')
)


process.ak4TrackL3AbsoluteCorrector = cms.EDProducer("LXXXCorrectorProducer",
    algorithm = cms.string('AK4TRK'),
    level = cms.string('L3Absolute')
)


process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotSigma = cms.double(3.7),
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    Version = cms.string('xgb'),
    VertexProbParamsConv = cms.vdouble(-0.045, -0.148, -0.328, -0.184),
    VertexProbParamsNoConv = cms.vdouble(-0.366, -0.126, -0.119, -0.091),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/legacyDiphoModelMerged.xml'),
    doSigmaMdecorr = cms.bool(True),
    sigmaMdecorrFile = cms.FileInPath('flashgg/Taggers/data/diphoMVA_sigmaMoMdecorr_split_Mgg40_180.root')
)


process.flashggDiPhotonSystematics = cms.EDProducer("FlashggDiPhotonSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('011')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleGain6EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('hasSwitchToGain6&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('100')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(

            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('MCScaleGain1EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('hasSwitchToGain1&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScaleEGMTool'),
            UncertaintyBitMask = cms.string('100')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialCentralBarrel'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)<1.0 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialOuterBarrel'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.0&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.000455),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.000233),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(0.002089),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.00109),
                        upBounds = cms.vdouble(999.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.002377),
                        upBounds = cms.vdouble(999.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MaterialForward'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(-0.0001),
                        upBounds = cms.vdouble(1.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.0),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(-0.0006),
                        upBounds = cms.vdouble(1.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 0.94),
                        uncertainties = cms.vdouble(-0.0011),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0015),
                        upBounds = cms.vdouble(2.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.0),
                        uncertainties = cms.vdouble(0.0004),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.0002),
                        upBounds = cms.vdouble(2.0, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 0.94),
                        uncertainties = cms.vdouble(0.0003),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ShowerShapeLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.00062),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.00208),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(5e-05),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.00227),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('FNUFEB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)<1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.00062),
                        upBounds = cms.vdouble(1.5, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.94),
                        uncertainties = cms.vdouble(0.00208),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(5e-05),
                        upBounds = cms.vdouble(6.0, 0.94),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.94),
                        uncertainties = cms.vdouble(0.00227),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('FNUFEE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(superCluster.eta)>=1.5 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonScale')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(cms.PSet(
                    lowBounds = cms.vdouble(0.0),
                    uncertainties = cms.vdouble(0.0),
                    upBounds = cms.vdouble(999.0),
                    values = cms.vdouble(0.0)
                )),
                variables = cms.vstring('abs(superCluster.eta)')
            ),
            CorrectionFile = cms.FileInPath('flashgg/Systematics/data/SystematicsIDMVA_LegRunII_v1_2017.root'),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MvaShift'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonMvaTransform')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.998)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.003),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(1.001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.006),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(0.989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.009),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(1.002)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PreselSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0023),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.982)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.0006),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(0.9911)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0076),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(0.9639)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(0.983)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('electronVetoSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0015550248, 0.0015550248),
                        upBounds = cms.vdouble(0.54, 1.5, 37.0),
                        values = cms.vdouble(0.9204369513)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 37),
                        uncertainties = cms.vdouble(0.0012001964, 0.0012001964),
                        upBounds = cms.vdouble(0.54, 1.5, 40.0),
                        values = cms.vdouble(0.9268543618)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.0010500218, 0.0010500218),
                        upBounds = cms.vdouble(0.54, 1.5, 45.0),
                        values = cms.vdouble(0.9296864506)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.0016928371, 0.0016928371),
                        upBounds = cms.vdouble(0.54, 1.5, 50.0),
                        values = cms.vdouble(0.9312181087)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0024479457, 0.0024479457),
                        upBounds = cms.vdouble(0.54, 1.5, 60.0),
                        values = cms.vdouble(0.9349061049)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.0052975139, 0.0052975139),
                        upBounds = cms.vdouble(0.54, 1.5, 70.0),
                        values = cms.vdouble(0.9425532022)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.0089854906, 0.0089854906),
                        upBounds = cms.vdouble(0.54, 1.5, 90.0),
                        values = cms.vdouble(0.9347621741)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.017714307, 0.017714307),
                        upBounds = cms.vdouble(0.54, 1.5, 99999999),
                        values = cms.vdouble(0.9489236873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 37.0),
                        values = cms.vdouble(0.9505374744)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 40.0),
                        values = cms.vdouble(0.9559316002)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 45.0),
                        values = cms.vdouble(0.960322746)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 50.0),
                        values = cms.vdouble(0.9628461917)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 60.0),
                        values = cms.vdouble(0.9662884361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 70.0),
                        values = cms.vdouble(0.9715136996)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 90.0),
                        values = cms.vdouble(0.9753661262)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 99999999),
                        values = cms.vdouble(0.9818196687)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 37.0),
                        values = cms.vdouble(0.9630117411)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 40.0),
                        values = cms.vdouble(0.9680310533)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 45.0),
                        values = cms.vdouble(0.9721152461)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 50.0),
                        values = cms.vdouble(0.9748189645)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 60.0),
                        values = cms.vdouble(0.9747597366)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 70.0),
                        values = cms.vdouble(0.9753162174)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 90.0),
                        values = cms.vdouble(0.9803243059)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 99999999),
                        values = cms.vdouble(0.9865482764)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0017122892, 0.0017122892),
                        upBounds = cms.vdouble(0.84, 3.0, 37.0),
                        values = cms.vdouble(0.9093169942)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.0012578761, 0.0012578761),
                        upBounds = cms.vdouble(0.84, 3.0, 40.0),
                        values = cms.vdouble(0.9214136806)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.84, 3.0, 45.0),
                        values = cms.vdouble(0.9396498081)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.0013009169, 0.0013009169),
                        upBounds = cms.vdouble(0.84, 3.0, 50.0),
                        values = cms.vdouble(0.9455103913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.00165793, 0.00165793),
                        upBounds = cms.vdouble(0.84, 3.0, 60.0),
                        values = cms.vdouble(0.9519493209)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0031358462, 0.0031358462),
                        upBounds = cms.vdouble(0.84, 3.0, 70.0),
                        values = cms.vdouble(0.9560088523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0036329374, 0.0036329374),
                        upBounds = cms.vdouble(0.84, 3.0, 90.0),
                        values = cms.vdouble(0.9638480843)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.0051321702, 0.0051321702),
                        upBounds = cms.vdouble(0.84, 3.0, 99999999),
                        values = cms.vdouble(0.9714734218)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 37.0),
                        values = cms.vdouble(0.961495108)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 40.0),
                        values = cms.vdouble(0.9750837371)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 45.0),
                        values = cms.vdouble(0.9814701227)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 50.0),
                        values = cms.vdouble(0.9835352074)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 60.0),
                        values = cms.vdouble(0.9851237595)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 70.0),
                        values = cms.vdouble(0.9869551174)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 90.0),
                        values = cms.vdouble(0.9916069861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 99999999),
                        values = cms.vdouble(0.9958525312)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 37.0),
                        values = cms.vdouble(0.9470889409)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 37.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 40.0),
                        values = cms.vdouble(0.9646677794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 45.0),
                        values = cms.vdouble(0.9738993606)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 50.0),
                        values = cms.vdouble(0.9784039943)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 60.0),
                        values = cms.vdouble(0.980234517)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 70.0),
                        values = cms.vdouble(0.9828741312)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 90.0),
                        values = cms.vdouble(0.9870534958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 99999999),
                        values = cms.vdouble(0.9891255039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0, 0),
                        uncertainties = cms.vdouble(1.0, 1.0),
                        upBounds = cms.vdouble(999, 999, 999999),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'full5x5_r9', 
                    'abs(superCluster.eta)', 
                    'pt'
                )
            ),
            BinList2 = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001420359, 0.001420359),
                        upBounds = cms.vdouble(0.54, 1.5, 28.0),
                        values = cms.vdouble(0.9503915847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.0011666773, 0.0011666773),
                        upBounds = cms.vdouble(0.54, 1.5, 31.0),
                        values = cms.vdouble(0.9563040539)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 35.0),
                        values = cms.vdouble(0.9554701294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 40.0),
                        values = cms.vdouble(0.9573495211)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.54, 1.5, 45.0),
                        values = cms.vdouble(0.9615640328)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.0012149116, 0.0012149116),
                        upBounds = cms.vdouble(0.54, 1.5, 50.0),
                        values = cms.vdouble(0.9635847522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0018398439, 0.0018398439),
                        upBounds = cms.vdouble(0.54, 1.5, 60.0),
                        values = cms.vdouble(0.9613424282)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.0046295174, 0.0046295174),
                        upBounds = cms.vdouble(0.54, 1.5, 70.0),
                        values = cms.vdouble(0.953179846)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.0082547803, 0.0082547803),
                        upBounds = cms.vdouble(0.54, 1.5, 90.0),
                        values = cms.vdouble(0.9427949472)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.0210727517, 0.0210727517),
                        upBounds = cms.vdouble(0.54, 1.5, 99999999),
                        values = cms.vdouble(0.9180892383)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 28.0),
                        values = cms.vdouble(0.9821722615)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 31.0),
                        values = cms.vdouble(0.9846684256)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 35.0),
                        values = cms.vdouble(0.9853409044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 40.0),
                        values = cms.vdouble(0.9851741151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 45.0),
                        values = cms.vdouble(0.9847237955)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 50.0),
                        values = cms.vdouble(0.9836985511)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 60.0),
                        values = cms.vdouble(0.9818687985)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 70.0),
                        values = cms.vdouble(0.9793978257)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.85, 1.5, 90.0),
                        values = cms.vdouble(0.9766027088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.54, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.0011171683, 0.0011171683),
                        upBounds = cms.vdouble(0.85, 1.5, 99999999),
                        values = cms.vdouble(0.972331437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 28.0),
                        values = cms.vdouble(0.9997101832)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 31.0),
                        values = cms.vdouble(0.9998675478)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 35.0),
                        values = cms.vdouble(0.9999351175)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 40.0),
                        values = cms.vdouble(0.999954156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 45.0),
                        values = cms.vdouble(0.9999645283)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 50.0),
                        values = cms.vdouble(0.9999677894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 60.0),
                        values = cms.vdouble(0.9999665309)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 70.0),
                        values = cms.vdouble(0.9999602573)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 90.0),
                        values = cms.vdouble(0.9999369329)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.85, 0.0, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 1.5, 99999999),
                        values = cms.vdouble(0.9999456063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0027302573, 0.0027302573),
                        upBounds = cms.vdouble(0.84, 3.0, 28.0),
                        values = cms.vdouble(0.8799714219)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.0021032366, 0.0021032366),
                        upBounds = cms.vdouble(0.84, 3.0, 31.0),
                        values = cms.vdouble(0.8962741603)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.0014198635, 0.0014198635),
                        upBounds = cms.vdouble(0.84, 3.0, 35.0),
                        values = cms.vdouble(0.9042685088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.0010478241, 0.0010478241),
                        upBounds = cms.vdouble(0.84, 3.0, 40.0),
                        values = cms.vdouble(0.9130894467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.0010511874, 0.0010511874),
                        upBounds = cms.vdouble(0.84, 3.0, 45.0),
                        values = cms.vdouble(0.9236887059)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.0015068743, 0.0015068743),
                        upBounds = cms.vdouble(0.84, 3.0, 50.0),
                        values = cms.vdouble(0.926909296)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001993287, 0.001993287),
                        upBounds = cms.vdouble(0.84, 3.0, 60.0),
                        values = cms.vdouble(0.9300621013)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0038708618, 0.0038708618),
                        upBounds = cms.vdouble(0.84, 3.0, 70.0),
                        values = cms.vdouble(0.9313708557)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0046452036, 0.0046452036),
                        upBounds = cms.vdouble(0.84, 3.0, 90.0),
                        values = cms.vdouble(0.9387860583)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.007718235, 0.007718235),
                        upBounds = cms.vdouble(0.84, 3.0, 99999999),
                        values = cms.vdouble(0.9316696569)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.0011380402, 0.0011380402),
                        upBounds = cms.vdouble(0.9, 3.0, 28.0),
                        values = cms.vdouble(0.9482346612)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 31.0),
                        values = cms.vdouble(0.9753440965)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 35.0),
                        values = cms.vdouble(0.9760310914)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 40.0),
                        values = cms.vdouble(0.9752981073)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 45.0),
                        values = cms.vdouble(0.973705016)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 50.0),
                        values = cms.vdouble(0.9719236369)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(0.9, 3.0, 60.0),
                        values = cms.vdouble(0.9704295117)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.0014503236, 0.0014503236),
                        upBounds = cms.vdouble(0.9, 3.0, 70.0),
                        values = cms.vdouble(0.9692422639)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.0018171502, 0.0018171502),
                        upBounds = cms.vdouble(0.9, 3.0, 90.0),
                        values = cms.vdouble(0.9692330221)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.84, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.0024173224, 0.0024173224),
                        upBounds = cms.vdouble(0.9, 3.0, 99999999),
                        values = cms.vdouble(0.972663036)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 0.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 28.0),
                        values = cms.vdouble(0.9706915047)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 28.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 31.0),
                        values = cms.vdouble(0.9975115605)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 31.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 35.0),
                        values = cms.vdouble(0.9992706525)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 35.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 40.0),
                        values = cms.vdouble(0.9995305126)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 40.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 45.0),
                        values = cms.vdouble(0.9995836941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 45.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 50.0),
                        values = cms.vdouble(0.9996279004)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 50.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 60.0),
                        values = cms.vdouble(0.9995678968)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 60.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 70.0),
                        values = cms.vdouble(0.9996782105)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 70.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 90.0),
                        values = cms.vdouble(0.9997202663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 1.5, 90.0),
                        uncertainties = cms.vdouble(0.001, 0.001),
                        upBounds = cms.vdouble(999, 3.0, 99999999),
                        values = cms.vdouble(0.9993842985)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0, 0),
                        uncertainties = cms.vdouble(1.0, 1.0),
                        upBounds = cms.vdouble(999, 999, 999999),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'full5x5_r9', 
                    'abs(superCluster.eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('TriggerWeight'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt<99999 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0001),
                        upBounds = cms.vdouble(1.5, 0.85),
                        values = cms.vdouble(0.9999)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.85),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(1.5, 999.0),
                        values = cms.vdouble(1.0003)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(6.0, 0.9),
                        values = cms.vdouble(1.0003)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.5, 0.9),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(6.0, 999.0),
                        values = cms.vdouble(1.0004)
                    )
                ),
                variables = cms.vstring(
                    'abs(superCluster.eta)', 
                    'full5x5_r9'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('LooseMvaSF'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonWeight')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            Label = cms.string('SigmaEOverESmearing'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(),
            OverallRange = cms.string('1'),
            PhotonMethodName = cms.string('FlashggPhotonSigEoverESmearingEGMTool')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(cms.PSet(
                    lowBounds = cms.vdouble(0.0),
                    uncertainties = cms.vdouble(0.05),
                    upBounds = cms.vdouble(999.0),
                    values = cms.vdouble(0.0)
                )),
                variables = cms.vstring('abs(superCluster.eta)')
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('SigmaEOverEShift'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('1 && full5x5_r9>0.'),
            PhotonMethodName = cms.string('FlashggPhotonSigEOverEShift')
        )
    ),
    SystMethods2D = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearHighR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearLowR9EE'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)>=1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearHighR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9>0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(),
                variables = cms.vstring('1')
            ),
            CorrectionFile = cms.string('EgammaAnalysis/ElectronTools/data/ScalesSmearings/Run2017_17Nov2017_v1_ele_unc'),
            Debug = cms.untracked.bool(False),
            ExaggerateShiftUp = cms.bool(False),
            FirstParameterName = cms.string('Rho'),
            Label = cms.string('MCSmearLowR9EB'),
            MethodName = cms.string('FlashggDiPhotonFromPhoton2D'),
            NSigmas = cms.PSet(
                firstVar = cms.vint32(1, -1, 0, 0),
                secondVar = cms.vint32(0, 0, 1, -1)
            ),
            OverallRange = cms.string('full5x5_r9<=0.94&&abs(superCluster.eta)<1.5'),
            PhotonMethodName = cms.string('FlashggPhotonSmearStochasticEGMTool'),
            RandomLabel = cms.string('rnd_g_E'),
            SecondParameterName = cms.string('Phi')
        )
    ),
    src = cms.InputTag("flashggDifferentialPhoIdInputsCorrection")
)


process.flashggDifferentialPhoIdInputsCorrection = cms.EDProducer("FlashggDifferentialPhoIdInputsCorrector",
    chIso_corrector_config_EB = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB'),
            regr_output_scaling = cms.string('x[0]*(0.093413)+(0.099455)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.077955)+(0.040562)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_3Cat_EB_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EB_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_3Cat_EB_chIso_chIsoWorst.xml')
        )
    ),
    chIso_corrector_config_EE = cms.PSet(
        chIsoWorst_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE'),
            regr_output_scaling = cms.string('x[0]*(0.082616)+(-0.000267)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_chIsoWorst.xml')
        ),
        chIsoWorst_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIsoWorst_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtChosenVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIsoWorst_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_chIsoWorst.xml')
        ),
        chIso_morphing = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.081217)+(0.012778)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIso03")'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfChIsoWorst03")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_chIso.xml')
        ),
        chIso_peak2tail = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('pfChgIsoWrtWorstVtx03'),
                    name = cms.untracked.string('f4')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_chIso_rnd")'),
                    name = cms.untracked.string('f5')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_chIso.xml')
        ),
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_data'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_3Cat_EE_chIso_chIsoWorst.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_chIso_EE_3Cat_mc'),
            multiclass = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_3Cat_EE_chIso_chIsoWorst.xml')
        )
    ),
    correctIsolations = cms.bool(True),
    correctShowerShapes = cms.bool(True),
    diphotonSrc = cms.InputTag("flashggDiPhotons"),
    effAreasConfigFile = cms.FileInPath('RecoEgamma/PhotonIdentification/data/Fall17/effAreaPhotons_cone03_pfPhotons_90percentBased_TrueVtx.txt'),
    etaWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000349)+(-0.000166)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_etaWidth.xml')
    ),
    etaWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_etaWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000548)+(0.000223)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_etaWidth.xml')
    ),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    is2017 = cms.bool(True),
    phiWidth_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EB'),
        regr_output_scaling = cms.string('x[0]*(0.002105)+(0.000738)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_phiWidth.xml')
    ),
    phiWidth_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_phiWidth_EE'),
        regr_output_scaling = cms.string('x[0]*(0.001946)+(0.000961)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_phiWidth.xml')
    ),
    phoIsoCutoff = cms.double(2.5),
    phoIsoPtScalingCoeff = cms.vdouble(0.0053, 0.0034),
    phoIso_corrector_config_EB = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_p2t_EB_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_p2t_EB_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB'),
            regr_output_scaling = cms.string('x[0]*(0.125619)+(0.068956)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfPhoIso03")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EB_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EB_phoIso.xml')
        )
    ),
    phoIso_corrector_config_EE = cms.PSet(
        clf_data = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_data'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/data_clf_p2t_EE_phoIso.xml')
        ),
        clf_mc = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p0t_mc'),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/mc_clf_p2t_EE_phoIso.xml')
        ),
        morphing = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE'),
            regr_output_scaling = cms.string('x[0]*(0.088698)+(0.025296)'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("uncorr_pfPhoIso03")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_phoIso.xml')
        ),
        peak2tail = cms.PSet(
            classifier = cms.string('BDTG_phoIso_EE_p2t'),
            regression = cms.bool(True),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('pt'),
                    name = cms.untracked.string('f0')
                ), 
                cms.PSet(
                    expr = cms.string('superCluster.eta'),
                    name = cms.untracked.string('f1')
                ), 
                cms.PSet(
                    expr = cms.string('phi'),
                    name = cms.untracked.string('f2')
                ), 
                cms.PSet(
                    expr = cms.string('global.rho'),
                    name = cms.untracked.string('f3')
                ), 
                cms.PSet(
                    expr = cms.string('userFloat("peak2tail_rnd")'),
                    name = cms.untracked.string('f4')
                )
            ),
            weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalTailRegressor_EE_phoIso.xml')
        )
    ),
    photonIdMVAweightfile_EB = cms.FileInPath('flashgg/MicroAOD/data/HggPhoId_94X_barrel_BDT_v2.weights.xml'),
    photonIdMVAweightfile_EE = cms.FileInPath('flashgg/MicroAOD/data/HggPhoId_94X_endcap_BDT_v2.weights.xml'),
    r9_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_r9_EB'),
        regr_output_scaling = cms.string('x[0]*(0.009489)+(-0.002028)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_r9.xml')
    ),
    r9_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_r9_EE'),
        regr_output_scaling = cms.string('x[0]*(0.014833)+(-0.007373)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_r9.xml')
    ),
    reRunRegression = cms.bool(False),
    regressionConfig = cms.PSet(
        autoDetectBunchSpacing = cms.bool(False),
        eOverP_ECALTRKThr = cms.double(0.025),
        electron_config = cms.PSet(
            regressionKey = cms.vstring(
                'electron_eb_ECALonly_lowpt', 
                'electron_eb_ECALonly', 
                'electron_ee_ECALonly_lowpt', 
                'electron_ee_ECALonly', 
                'electron_eb_ECALTRK_lowpt', 
                'electron_eb_ECALTRK', 
                'electron_ee_ECALTRK_lowpt', 
                'electron_ee_ECALTRK'
            ),
            uncertaintyKey = cms.vstring(
                'electron_eb_ECALonly_lowpt_var', 
                'electron_eb_ECALonly_var', 
                'electron_ee_ECALonly_lowpt_var', 
                'electron_ee_ECALonly_var', 
                'electron_eb_ECALTRK_lowpt_var', 
                'electron_eb_ECALTRK_var', 
                'electron_ee_ECALTRK_lowpt_var', 
                'electron_ee_ECALTRK_var'
            )
        ),
        epDiffSig_ECALTRKThr = cms.double(15.0),
        epSig_ECALTRKThr = cms.double(10.0),
        forceHighEnergyEcalTrainingIfSaturated = cms.bool(True),
        highEnergy_ECALTRKThr = cms.double(200.0),
        lowEnergy_ECALTRKThr = cms.double(50.0),
        lowEnergy_ECALonlyThr = cms.double(99999.0),
        manualBunchSpacing = cms.int32(25),
        modifierName = cms.string('EGRegressionModifierV2'),
        photon_config = cms.PSet(
            regressionKey = cms.vstring(
                'photon_eb_ECALonly_lowpt', 
                'photon_eb_ECALonly', 
                'photon_ee_ECALonly_lowpt', 
                'photon_ee_ECALonly'
            ),
            uncertaintyKey = cms.vstring(
                'photon_eb_ECALonly_lowpt_var', 
                'photon_eb_ECALonly_var', 
                'photon_ee_ECALonly_lowpt_var', 
                'photon_ee_ECALonly_var'
            )
        ),
        rhoCollection = cms.InputTag("fixedGridRhoFastjetAll"),
        vertexCollection = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    rhoFixedGridCollection = cms.InputTag("fixedGridRhoAll"),
    s4_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_s4_EB'),
        regr_output_scaling = cms.string('x[0]*(0.006531)+(-0.001477)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_s4.xml')
    ),
    s4_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_s4_EE'),
        regr_output_scaling = cms.string('x[0]*(0.014044)+(-0.008719)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_s4.xml')
    ),
    sieie_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieie_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000096)+(-0.000052)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_sieie.xml')
    ),
    sieie_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieie_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000495)+(0.000233)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_sieie.xml')
    ),
    sieip_corrector_config_EB = cms.PSet(
        classifier = cms.string('BDTG_sieip_EB'),
        regr_output_scaling = cms.string('x[0]*(0.000001)+(-0.000000)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EB_sieip.xml')
    ),
    sieip_corrector_config_EE = cms.PSet(
        classifier = cms.string('BDTG_sieip_EE'),
        regr_output_scaling = cms.string('x[0]*(0.000020)+(-0.000011)'),
        regression = cms.bool(True),
        variables = cms.VPSet(
            cms.PSet(
                expr = cms.string('pt'),
                name = cms.untracked.string('f0')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.eta'),
                name = cms.untracked.string('f1')
            ), 
            cms.PSet(
                expr = cms.string('phi'),
                name = cms.untracked.string('f2')
            ), 
            cms.PSet(
                expr = cms.string('global.rho'),
                name = cms.untracked.string('f3')
            ), 
            cms.PSet(
                expr = cms.string('sieip'),
                name = cms.untracked.string('f4')
            ), 
            cms.PSet(
                expr = cms.string('s4'),
                name = cms.untracked.string('f5')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_r9'),
                name = cms.untracked.string('f6')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.phiWidth'),
                name = cms.untracked.string('f7')
            ), 
            cms.PSet(
                expr = cms.string('full5x5_sigmaIetaIeta'),
                name = cms.untracked.string('f8')
            ), 
            cms.PSet(
                expr = cms.string('superCluster.etaWidth'),
                name = cms.untracked.string('f9')
            )
        ),
        weights = cms.FileInPath('flashgg/Taggers/data/PhoIdInputsCorrections/2017/weights_finalRegressor_EE_sieip.xml')
    )
)


process.flashggElectronSystematics = cms.EDProducer("FlashggElectronEffSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 10.0),
                        uncertainties = cms.vdouble(0.0112858730628),
                        upBounds = cms.vdouble(-2.0, 20.0),
                        values = cms.vdouble(0.949999988079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 10.0),
                        uncertainties = cms.vdouble(0.0251865457492),
                        upBounds = cms.vdouble(-1.566, 20.0),
                        values = cms.vdouble(0.965909063816)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 10.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 10.0),
                        uncertainties = cms.vdouble(0.0532923660981),
                        upBounds = cms.vdouble(-0.8, 20.0),
                        values = cms.vdouble(1.00240385532)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 10.0),
                        uncertainties = cms.vdouble(0.0185313741386),
                        upBounds = cms.vdouble(0.0, 20.0),
                        values = cms.vdouble(0.981412649155)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.0184153504817),
                        upBounds = cms.vdouble(0.8, 20.0),
                        values = cms.vdouble(0.965559661388)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 10.0),
                        uncertainties = cms.vdouble(0.0532537232346),
                        upBounds = cms.vdouble(1.444, 20.0),
                        values = cms.vdouble(0.995127916336)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 10.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 10.0),
                        uncertainties = cms.vdouble(0.0251865457492),
                        upBounds = cms.vdouble(2.0, 20.0),
                        values = cms.vdouble(0.9784091115)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 10.0),
                        uncertainties = cms.vdouble(0.0114607321663),
                        upBounds = cms.vdouble(2.5, 20.0),
                        values = cms.vdouble(0.940533995628)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 20.0),
                        uncertainties = cms.vdouble(0.0189241795783),
                        upBounds = cms.vdouble(-2.0, 35.0),
                        values = cms.vdouble(0.93119263649)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 20.0),
                        uncertainties = cms.vdouble(0.0224861645312),
                        upBounds = cms.vdouble(-1.566, 35.0),
                        values = cms.vdouble(0.941436469555)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 20.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 35.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 20.0),
                        uncertainties = cms.vdouble(0.0305900962347),
                        upBounds = cms.vdouble(-0.8, 35.0),
                        values = cms.vdouble(0.954861104488)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 20.0),
                        uncertainties = cms.vdouble(0.020587589271),
                        upBounds = cms.vdouble(0.0, 35.0),
                        values = cms.vdouble(0.988304078579)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.020587589271),
                        upBounds = cms.vdouble(0.8, 35.0),
                        values = cms.vdouble(0.987253785133)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 20.0),
                        uncertainties = cms.vdouble(0.0305900962347),
                        upBounds = cms.vdouble(1.444, 35.0),
                        values = cms.vdouble(0.976717114449)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 20.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 35.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 20.0),
                        uncertainties = cms.vdouble(0.0224861645312),
                        upBounds = cms.vdouble(2.0, 35.0),
                        values = cms.vdouble(0.952328145504)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 20.0),
                        uncertainties = cms.vdouble(0.0189241795783),
                        upBounds = cms.vdouble(2.5, 35.0),
                        values = cms.vdouble(0.931113660336)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 35.0),
                        uncertainties = cms.vdouble(0.0109725941888),
                        upBounds = cms.vdouble(-2.0, 50.0),
                        values = cms.vdouble(0.941885948181)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 35.0),
                        uncertainties = cms.vdouble(0.00693532170766),
                        upBounds = cms.vdouble(-1.566, 50.0),
                        values = cms.vdouble(0.958510637283)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 35.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 35.0),
                        uncertainties = cms.vdouble(0.00783498919711),
                        upBounds = cms.vdouble(-0.8, 50.0),
                        values = cms.vdouble(0.966996729374)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 35.0),
                        uncertainties = cms.vdouble(0.00477148982801),
                        upBounds = cms.vdouble(0.0, 50.0),
                        values = cms.vdouble(0.976769924164)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 35.0),
                        uncertainties = cms.vdouble(0.00477148982801),
                        upBounds = cms.vdouble(0.8, 50.0),
                        values = cms.vdouble(0.975850701332)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 35.0),
                        uncertainties = cms.vdouble(0.00783498919711),
                        upBounds = cms.vdouble(1.444, 50.0),
                        values = cms.vdouble(0.967955827713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 35.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 35.0),
                        uncertainties = cms.vdouble(0.00693532170766),
                        upBounds = cms.vdouble(2.0, 50.0),
                        values = cms.vdouble(0.959574460983)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 35.0),
                        uncertainties = cms.vdouble(0.0109725941888),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.93428260088)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 50.0),
                        uncertainties = cms.vdouble(0.0145086704563),
                        upBounds = cms.vdouble(-2.0, 100.0),
                        values = cms.vdouble(0.943783760071)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 50.0),
                        uncertainties = cms.vdouble(0.00537350216127),
                        upBounds = cms.vdouble(-1.566, 100.0),
                        values = cms.vdouble(0.965553224087)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 50.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 50.0),
                        uncertainties = cms.vdouble(0.00269832703724),
                        upBounds = cms.vdouble(-0.8, 100.0),
                        values = cms.vdouble(0.967672407627)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 50.0),
                        uncertainties = cms.vdouble(0.00788041010763),
                        upBounds = cms.vdouble(0.0, 100.0),
                        values = cms.vdouble(0.976164698601)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.00788041010763),
                        upBounds = cms.vdouble(0.8, 100.0),
                        values = cms.vdouble(0.975242197514)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 50.0),
                        uncertainties = cms.vdouble(0.00269832703724),
                        upBounds = cms.vdouble(1.444, 100.0),
                        values = cms.vdouble(0.970810830593)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 50.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 50.0),
                        uncertainties = cms.vdouble(0.00537350216127),
                        upBounds = cms.vdouble(2.0, 100.0),
                        values = cms.vdouble(0.972860097885)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 50.0),
                        uncertainties = cms.vdouble(0.0145086704563),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.933117568493)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 100.0),
                        uncertainties = cms.vdouble(0.0159402275827),
                        upBounds = cms.vdouble(-2.0, 200.0),
                        values = cms.vdouble(0.973655343056)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 100.0),
                        uncertainties = cms.vdouble(0.0600400414131),
                        upBounds = cms.vdouble(-1.566, 200.0),
                        values = cms.vdouble(0.972860097885)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 100.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 100.0),
                        uncertainties = cms.vdouble(0.0351614272789),
                        upBounds = cms.vdouble(-0.8, 200.0),
                        values = cms.vdouble(0.969924807549)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 100.0),
                        uncertainties = cms.vdouble(0.022243336851),
                        upBounds = cms.vdouble(0.0, 200.0),
                        values = cms.vdouble(0.982683956623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.022243336851),
                        upBounds = cms.vdouble(0.8, 200.0),
                        values = cms.vdouble(0.988146543503)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 100.0),
                        uncertainties = cms.vdouble(0.0351614272789),
                        upBounds = cms.vdouble(1.444, 200.0),
                        values = cms.vdouble(0.977346301079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 100.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 100.0),
                        uncertainties = cms.vdouble(0.0600690788596),
                        upBounds = cms.vdouble(2.0, 200.0),
                        values = cms.vdouble(0.995807111263)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 100.0),
                        uncertainties = cms.vdouble(0.0160763037584),
                        upBounds = cms.vdouble(2.5, 200.0),
                        values = cms.vdouble(0.952637255192)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 200.0),
                        uncertainties = cms.vdouble(0.0595751766054),
                        upBounds = cms.vdouble(-2.0, 500.0),
                        values = cms.vdouble(0.867357492447)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 500.0),
                        uncertainties = cms.vdouble(0.0595751766054),
                        upBounds = cms.vdouble(-2.0, 9999),
                        values = cms.vdouble(0.867357492447)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 200.0),
                        uncertainties = cms.vdouble(0.0637457498102),
                        upBounds = cms.vdouble(-1.566, 500.0),
                        values = cms.vdouble(0.994511544704)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 500.0),
                        uncertainties = cms.vdouble(0.0637457498102),
                        upBounds = cms.vdouble(-1.566, 9999),
                        values = cms.vdouble(0.994511544704)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 200.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 500.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 500.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(-1.444, 9999),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 200.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(-0.8, 500.0),
                        values = cms.vdouble(0.978284478188)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 500.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(-0.8, 9999),
                        values = cms.vdouble(0.978284478188)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 200.0),
                        uncertainties = cms.vdouble(0.0433251322231),
                        upBounds = cms.vdouble(0.0, 500.0),
                        values = cms.vdouble(0.989189207554)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.8, 500.0),
                        uncertainties = cms.vdouble(0.0433251322231),
                        upBounds = cms.vdouble(0.0, 9999),
                        values = cms.vdouble(0.989189207554)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 200.0),
                        uncertainties = cms.vdouble(0.0429830183443),
                        upBounds = cms.vdouble(0.8, 500.0),
                        values = cms.vdouble(0.95387840271)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 500.0),
                        uncertainties = cms.vdouble(0.0429830183443),
                        upBounds = cms.vdouble(0.8, 9999),
                        values = cms.vdouble(0.95387840271)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 200.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(1.444, 500.0),
                        values = cms.vdouble(0.960427820683)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.8, 500.0),
                        uncertainties = cms.vdouble(0.0593773467838),
                        upBounds = cms.vdouble(1.444, 9999),
                        values = cms.vdouble(0.960427820683)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 200.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 500.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 500.0),
                        uncertainties = cms.vdouble(1.0),
                        upBounds = cms.vdouble(1.566, 9999),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 200.0),
                        uncertainties = cms.vdouble(0.0633253690692),
                        upBounds = cms.vdouble(2.0, 500.0),
                        values = cms.vdouble(0.961256563663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 500.0),
                        uncertainties = cms.vdouble(0.0633253690692),
                        upBounds = cms.vdouble(2.0, 9999),
                        values = cms.vdouble(0.961256563663)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 200.0),
                        uncertainties = cms.vdouble(0.0695692658699),
                        upBounds = cms.vdouble(2.5, 500.0),
                        values = cms.vdouble(1.06021249294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 500.0),
                        uncertainties = cms.vdouble(0.0695692658699),
                        upBounds = cms.vdouble(2.5, 9999),
                        values = cms.vdouble(1.06021249294)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(-2.5, 99999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 999999999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 10.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ElectronIDWeight'),
            MethodName = cms.string('FlashggElectronWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 10.0),
                        uncertainties = cms.vdouble(0.0595607790053),
                        upBounds = cms.vdouble(-2.0, 20.0),
                        values = cms.vdouble(0.982328474522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 10.0),
                        uncertainties = cms.vdouble(0.0201089477996),
                        upBounds = cms.vdouble(-1.566, 20.0),
                        values = cms.vdouble(0.988577365875)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 10.0),
                        uncertainties = cms.vdouble(0.0307086960564),
                        upBounds = cms.vdouble(-1.444, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 10.0),
                        uncertainties = cms.vdouble(0.0826095038174),
                        upBounds = cms.vdouble(-1.0, 20.0),
                        values = cms.vdouble(0.976470589638)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 10.0),
                        uncertainties = cms.vdouble(0.054484510738),
                        upBounds = cms.vdouble(0.0, 20.0),
                        values = cms.vdouble(0.96931219101)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.054484510738),
                        upBounds = cms.vdouble(1.0, 20.0),
                        values = cms.vdouble(0.96931219101)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 10.0),
                        uncertainties = cms.vdouble(0.0826095038174),
                        upBounds = cms.vdouble(1.444, 20.0),
                        values = cms.vdouble(0.976470589638)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 10.0),
                        uncertainties = cms.vdouble(0.0307086960564),
                        upBounds = cms.vdouble(1.566, 20.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 10.0),
                        uncertainties = cms.vdouble(0.0201089477996),
                        upBounds = cms.vdouble(2.0, 20.0),
                        values = cms.vdouble(0.988577365875)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 10.0),
                        uncertainties = cms.vdouble(0.0595607790053),
                        upBounds = cms.vdouble(2.5, 20.0),
                        values = cms.vdouble(0.982328474522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 20.0),
                        uncertainties = cms.vdouble(0.00757915021676),
                        upBounds = cms.vdouble(-2.0, 45.0),
                        values = cms.vdouble(0.97748208046)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 20.0),
                        uncertainties = cms.vdouble(0.00260286856232),
                        upBounds = cms.vdouble(-1.566, 45.0),
                        values = cms.vdouble(0.981613874435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 20.0),
                        uncertainties = cms.vdouble(0.0139351980813),
                        upBounds = cms.vdouble(-1.444, 45.0),
                        values = cms.vdouble(0.948351621628)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 20.0),
                        uncertainties = cms.vdouble(0.00502412079629),
                        upBounds = cms.vdouble(-1.0, 45.0),
                        values = cms.vdouble(0.969262301922)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 20.0),
                        uncertainties = cms.vdouble(0.00478613853043),
                        upBounds = cms.vdouble(-0.5, 45.0),
                        values = cms.vdouble(0.976554512978)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 20.0),
                        uncertainties = cms.vdouble(0.0068174062668),
                        upBounds = cms.vdouble(0.0, 45.0),
                        values = cms.vdouble(0.970377922058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.0068174062668),
                        upBounds = cms.vdouble(0.5, 45.0),
                        values = cms.vdouble(0.970347642899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 20.0),
                        uncertainties = cms.vdouble(0.00478613853043),
                        upBounds = cms.vdouble(1.0, 45.0),
                        values = cms.vdouble(0.972420811653)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 20.0),
                        uncertainties = cms.vdouble(0.00502412079629),
                        upBounds = cms.vdouble(1.444, 45.0),
                        values = cms.vdouble(0.96991699934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 20.0),
                        uncertainties = cms.vdouble(0.0139351980813),
                        upBounds = cms.vdouble(1.566, 45.0),
                        values = cms.vdouble(0.957964599133)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 20.0),
                        uncertainties = cms.vdouble(0.00260286856232),
                        upBounds = cms.vdouble(2.0, 45.0),
                        values = cms.vdouble(0.979591846466)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 20.0),
                        uncertainties = cms.vdouble(0.00757915021676),
                        upBounds = cms.vdouble(2.5, 45.0),
                        values = cms.vdouble(0.979591846466)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 45.0),
                        uncertainties = cms.vdouble(0.00370677692937),
                        upBounds = cms.vdouble(-2.0, 75.0),
                        values = cms.vdouble(0.983673453331)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 45.0),
                        uncertainties = cms.vdouble(0.00386783804259),
                        upBounds = cms.vdouble(-1.566, 75.0),
                        values = cms.vdouble(0.981707334518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 45.0),
                        uncertainties = cms.vdouble(0.0139269471799),
                        upBounds = cms.vdouble(-1.444, 75.0),
                        values = cms.vdouble(0.970619082451)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 45.0),
                        uncertainties = cms.vdouble(0.00437480990544),
                        upBounds = cms.vdouble(-1.0, 75.0),
                        values = cms.vdouble(0.975535154343)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 45.0),
                        uncertainties = cms.vdouble(0.00263764082371),
                        upBounds = cms.vdouble(-0.5, 75.0),
                        values = cms.vdouble(0.979695439339)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 45.0),
                        uncertainties = cms.vdouble(0.00264300733607),
                        upBounds = cms.vdouble(0.0, 75.0),
                        values = cms.vdouble(0.97965413332)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 45.0),
                        uncertainties = cms.vdouble(0.00264300733607),
                        upBounds = cms.vdouble(0.5, 75.0),
                        values = cms.vdouble(0.97761952877)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 45.0),
                        uncertainties = cms.vdouble(0.00263764082371),
                        upBounds = cms.vdouble(1.0, 75.0),
                        values = cms.vdouble(0.978680193424)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 45.0),
                        uncertainties = cms.vdouble(0.00437480990544),
                        upBounds = cms.vdouble(1.444, 75.0),
                        values = cms.vdouble(0.977366268635)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 45.0),
                        uncertainties = cms.vdouble(0.013954384552),
                        upBounds = cms.vdouble(1.566, 75.0),
                        values = cms.vdouble(0.963944852352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 45.0),
                        uncertainties = cms.vdouble(0.00386783804259),
                        upBounds = cms.vdouble(2.0, 75.0),
                        values = cms.vdouble(0.982741117477)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 45.0),
                        uncertainties = cms.vdouble(0.00370677692937),
                        upBounds = cms.vdouble(2.5, 75.0),
                        values = cms.vdouble(0.983739852905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 75.0),
                        uncertainties = cms.vdouble(0.0150392770193),
                        upBounds = cms.vdouble(-2.0, 100.0),
                        values = cms.vdouble(0.99695122242)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 75.0),
                        uncertainties = cms.vdouble(0.00779811751053),
                        upBounds = cms.vdouble(-1.566, 100.0),
                        values = cms.vdouble(0.996954321861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 75.0),
                        uncertainties = cms.vdouble(0.040819128581),
                        upBounds = cms.vdouble(-1.444, 100.0),
                        values = cms.vdouble(1.00322926044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 75.0),
                        uncertainties = cms.vdouble(0.00787002638101),
                        upBounds = cms.vdouble(-1.0, 100.0),
                        values = cms.vdouble(0.99590164423)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 75.0),
                        uncertainties = cms.vdouble(0.00248175252562),
                        upBounds = cms.vdouble(-0.5, 100.0),
                        values = cms.vdouble(0.991894602776)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 75.0),
                        uncertainties = cms.vdouble(0.00392002362976),
                        upBounds = cms.vdouble(0.0, 100.0),
                        values = cms.vdouble(0.991902828217)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 75.0),
                        uncertainties = cms.vdouble(0.00392002362976),
                        upBounds = cms.vdouble(0.5, 100.0),
                        values = cms.vdouble(0.991902828217)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 75.0),
                        uncertainties = cms.vdouble(0.00248175252562),
                        upBounds = cms.vdouble(1.0, 100.0),
                        values = cms.vdouble(0.991894602776)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 75.0),
                        uncertainties = cms.vdouble(0.00787002638101),
                        upBounds = cms.vdouble(1.444, 100.0),
                        values = cms.vdouble(0.99590164423)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 75.0),
                        uncertainties = cms.vdouble(0.040819128581),
                        upBounds = cms.vdouble(1.566, 100.0),
                        values = cms.vdouble(1.00322926044)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 75.0),
                        uncertainties = cms.vdouble(0.00779811751053),
                        upBounds = cms.vdouble(2.0, 100.0),
                        values = cms.vdouble(0.996954321861)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 75.0),
                        uncertainties = cms.vdouble(0.0150392770193),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.99695122242)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 100.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(-2.0, 500.0),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.5, 500.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(-2.0, 9999),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 100.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(-1.566, 500.0),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.0, 500.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(-1.566, 9999),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 100.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(-1.444, 500.0),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.566, 500.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(-1.444, 9999),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 100.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(-1.0, 500.0),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.444, 500.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(-1.0, 9999),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 100.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(-0.5, 500.0),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.0, 500.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(-0.5, 9999),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 100.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.0, 500.0),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 500.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.0, 9999),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.5, 500.0),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 500.0),
                        uncertainties = cms.vdouble(0.0017513152756),
                        upBounds = cms.vdouble(0.5, 9999),
                        values = cms.vdouble(0.993933260441)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 100.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(1.0, 500.0),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.5, 500.0),
                        uncertainties = cms.vdouble(0.00494347072206),
                        upBounds = cms.vdouble(1.0, 9999),
                        values = cms.vdouble(0.987891018391)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 100.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(1.444, 500.0),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.0, 500.0),
                        uncertainties = cms.vdouble(0.006277407335),
                        upBounds = cms.vdouble(1.444, 9999),
                        values = cms.vdouble(0.984725058079)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 100.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(1.566, 500.0),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.444, 500.0),
                        uncertainties = cms.vdouble(0.0491215609105),
                        upBounds = cms.vdouble(1.566, 9999),
                        values = cms.vdouble(1.0095949173)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 100.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(2.0, 500.0),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.566, 500.0),
                        uncertainties = cms.vdouble(0.00484917241993),
                        upBounds = cms.vdouble(2.0, 9999),
                        values = cms.vdouble(0.98988878727)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 100.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(2.5, 500.0),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.0, 500.0),
                        uncertainties = cms.vdouble(0.00962602625042),
                        upBounds = cms.vdouble(2.5, 9999),
                        values = cms.vdouble(0.989909172058)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(-2.5, 99999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 999999999.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-10, 0.0),
                        uncertainties = cms.vdouble(0.001),
                        upBounds = cms.vdouble(10.0, 10.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('ElectronRecoWeight'),
            MethodName = cms.string('FlashggElectronWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedElectrons")
)


process.flashggJetSystematics0 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","0")
)


process.flashggJetSystematics1 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","1")
)


process.flashggJetSystematics10 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","10")
)


process.flashggJetSystematics11 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","11")
)


process.flashggJetSystematics2 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","2")
)


process.flashggJetSystematics3 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","3")
)


process.flashggJetSystematics4 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","4")
)


process.flashggJetSystematics5 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","5")
)


process.flashggJetSystematics6 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","6")
)


process.flashggJetSystematics7 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","7")
)


process.flashggJetSystematics8 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","8")
)


process.flashggJetSystematics9 = cms.EDProducer("FlashggJetSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            JetCorrectorTag = cms.InputTag("ak4PFCHSL1FastL2L3Corrector"),
            Label = cms.string('JEC'),
            MethodName = cms.string('FlashggJetEnergyCorrector'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            SetupUncertainties = cms.bool(True),
            SourceName = cms.string('notused'),
            TextFileName = cms.FileInPath('flashgg/Systematics/data/JEC/Regrouped_Fall17_17Nov2017_V32_MC_UncertaintySources_AK4PFchs.txt'),
            UseTextFile = cms.bool(False)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JER'),
            MethodName = cms.string('FlashggJetSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0'),
            RandomLabel = cms.string('rnd_g_JER'),
            TextFileResolution = cms.string('notused'),
            TextFileSF = cms.string('notused'),
            UseTextFiles = cms.bool(False),
            rho = cms.InputTag("fixedGridRhoAll")
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagCutWeight'),
            MethodName = cms.string('FlashggJetBTagWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bDiscriminator = cms.double(0.3033),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_WP_V2_B_F.csv')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 50.0),
                        values = cms.vdouble(0.0455062)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 100.0),
                        values = cms.vdouble(0.0248722)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 200.0),
                        values = cms.vdouble(0.0265933)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 2.4, 999999.0),
                        values = cms.vdouble(0.062829)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 50.0),
                        values = cms.vdouble(0.226323)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 100.0),
                        values = cms.vdouble(0.208522)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 200.0),
                        values = cms.vdouble(0.214934)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 2.4, 999999.0),
                        values = cms.vdouble(0.239287)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 200.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(4.5, 10.0, 999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 50.0),
                        values = cms.vdouble(0.702162)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 100.0),
                        values = cms.vdouble(0.770467)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 200.0),
                        values = cms.vdouble(0.771944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 0.0, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 2.4, 999999.0),
                        values = cms.vdouble(0.750926)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 0.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 50.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 50.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 100.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 200.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.5, 2.4, 200.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.5, 10.0, 999999.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'hadronFlavour', 
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('JetBTagReshapeWeight'),
            MethodName = cms.string('FlashggJetBTagReshapeWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('pt>25.0&&abs(eta)<2.5'),
            bTag = cms.string('pfDeepJet'),
            bTagCalibrationFile = cms.FileInPath('flashgg/Systematics/data/DeepFlavour_94XSF_V2_B_F.csv'),
            bTagReshapeSystOption = cms.int32(1)
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.002),
                        upBounds = cms.vdouble(2.5, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(0.02),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.04),
                        upBounds = cms.vdouble(5.0, 30.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.005),
                        upBounds = cms.vdouble(2.5, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.06),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.025),
                        upBounds = cms.vdouble(5.0, 50.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.004),
                        upBounds = cms.vdouble(2.5, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(2.75, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(3.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 50.0),
                        uncertainties = cms.vdouble(0.01),
                        upBounds = cms.vdouble(5.0, 100.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.5, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(2.75, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(3.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 100.0),
                        uncertainties = cms.vdouble(0.0),
                        upBounds = cms.vdouble(5.0, 9999999.0),
                        values = cms.vdouble(0.0)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('PUJIDShift'),
            MethodName = cms.string('FlashggJetPUJIDShift'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<5.0&&pt>20.0')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 20.0),
                        uncertainties = cms.vdouble(-0.039),
                        upBounds = cms.vdouble(2.75, 25.0),
                        values = cms.vdouble(1.039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 20.0),
                        uncertainties = cms.vdouble(-0.008),
                        upBounds = cms.vdouble(3.0, 25.0),
                        values = cms.vdouble(1.008)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 20.0),
                        uncertainties = cms.vdouble(0.046),
                        upBounds = cms.vdouble(4.0, 25.0),
                        values = cms.vdouble(0.954)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 20.0),
                        uncertainties = cms.vdouble(0.106),
                        upBounds = cms.vdouble(4.7, 25.0),
                        values = cms.vdouble(0.894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 25.0),
                        uncertainties = cms.vdouble(0.026),
                        upBounds = cms.vdouble(2.75, 30.0),
                        values = cms.vdouble(0.974)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 25.0),
                        uncertainties = cms.vdouble(0.109),
                        upBounds = cms.vdouble(3.0, 30.0),
                        values = cms.vdouble(0.891)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 25.0),
                        uncertainties = cms.vdouble(0.059),
                        upBounds = cms.vdouble(4.0, 30.0),
                        values = cms.vdouble(0.941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 25.0),
                        uncertainties = cms.vdouble(0.076),
                        upBounds = cms.vdouble(4.7, 30.0),
                        values = cms.vdouble(0.924)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.5, 30.0),
                        uncertainties = cms.vdouble(-0.068),
                        upBounds = cms.vdouble(2.75, 50.0),
                        values = cms.vdouble(1.068)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.75, 30.0),
                        uncertainties = cms.vdouble(0.32),
                        upBounds = cms.vdouble(3.0, 50.0),
                        values = cms.vdouble(0.68)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(3.0, 30.0),
                        uncertainties = cms.vdouble(0.107),
                        upBounds = cms.vdouble(4.0, 50.0),
                        values = cms.vdouble(0.893)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(4.0, 30.0),
                        uncertainties = cms.vdouble(0.123),
                        upBounds = cms.vdouble(4.7, 50.0),
                        values = cms.vdouble(0.877)
                    )
                ),
                variables = cms.vstring(
                    'abs(eta)', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('UnmatchedPUWeight'),
            MethodName = cms.string('FlashggJetWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)>2.5&&abs(eta)<4.7&&pt>20.&&pt<50.&&hasGenMatch==0')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggUnpackedJets","9")
)


process.flashggMetSystematics = cms.EDProducer("FlashggMetSmearSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJecUncertainty'),
            MethodName = cms.string('FlashggMetJecSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metJerUncertainty'),
            MethodName = cms.string('FlashggMetJerSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metPhoUncertainty'),
            MethodName = cms.string('FlashggMetPhoSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(False),
            Debug = cms.untracked.bool(False),
            Label = cms.string('metUncUncertainty'),
            MethodName = cms.string('FlashggMetUncSmear'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.5')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggMets")
)


process.flashggMuonSystematics = cms.EDProducer("FlashggMuonEffSystematicProducer",
    SystMethods = cms.VPSet(
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 20.0),
                        uncertainties = cms.vdouble(0.00717150166064, 0.00717150166064),
                        upBounds = cms.vdouble(2.1, 25.0),
                        values = cms.vdouble(0.995538375007)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 20.0),
                        uncertainties = cms.vdouble(0.00717150166064, 0.00717150166064),
                        upBounds = cms.vdouble(-1.2, 25.0),
                        values = cms.vdouble(0.995538375007)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.0),
                        uncertainties = cms.vdouble(0.00718016037829, 0.00718016037829),
                        upBounds = cms.vdouble(2.1, 3.25),
                        values = cms.vdouble(0.985213161284)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.0),
                        uncertainties = cms.vdouble(0.00718016037829, 0.00718016037829),
                        upBounds = cms.vdouble(-1.2, 3.25),
                        values = cms.vdouble(0.985213161284)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.5),
                        uncertainties = cms.vdouble(0.00757211850767, 0.00757211850767),
                        upBounds = cms.vdouble(2.1, 3.75),
                        values = cms.vdouble(0.99334396788)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.5),
                        uncertainties = cms.vdouble(0.00757211850767, 0.00757211850767),
                        upBounds = cms.vdouble(-1.2, 3.75),
                        values = cms.vdouble(0.99334396788)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.5),
                        uncertainties = cms.vdouble(0.0121376683643, 0.0121376683643),
                        upBounds = cms.vdouble(2.1, 2.75),
                        values = cms.vdouble(0.983186017152)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.5),
                        uncertainties = cms.vdouble(0.0121376683643, 0.0121376683643),
                        upBounds = cms.vdouble(-1.2, 2.75),
                        values = cms.vdouble(0.983186017152)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 8.0),
                        uncertainties = cms.vdouble(0.00995275172559, 0.00995275172559),
                        upBounds = cms.vdouble(2.1, 10.0),
                        values = cms.vdouble(0.994538587647)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 8.0),
                        uncertainties = cms.vdouble(0.00995275172559, 0.00995275172559),
                        upBounds = cms.vdouble(-1.2, 10.0),
                        values = cms.vdouble(0.994538587647)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 5.0),
                        uncertainties = cms.vdouble(0.0071508543832, 0.0071508543832),
                        upBounds = cms.vdouble(2.1, 6.0),
                        values = cms.vdouble(0.994444776905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 5.0),
                        uncertainties = cms.vdouble(0.0071508543832, 0.0071508543832),
                        upBounds = cms.vdouble(-1.2, 6.0),
                        values = cms.vdouble(0.994444776905)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 4.5),
                        uncertainties = cms.vdouble(0.0072215430303, 0.0072215430303),
                        upBounds = cms.vdouble(2.1, 5.0),
                        values = cms.vdouble(0.996519485745)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 4.5),
                        uncertainties = cms.vdouble(0.0072215430303, 0.0072215430303),
                        upBounds = cms.vdouble(-1.2, 5.0),
                        values = cms.vdouble(0.996519485745)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 50.0),
                        uncertainties = cms.vdouble(0.00096089233599, 0.00096089233599),
                        upBounds = cms.vdouble(2.1, 60.0),
                        values = cms.vdouble(0.99464683502)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 50.0),
                        uncertainties = cms.vdouble(0.00096089233599, 0.00096089233599),
                        upBounds = cms.vdouble(-1.2, 60.0),
                        values = cms.vdouble(0.99464683502)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 25.0),
                        uncertainties = cms.vdouble(0.00173622673212, 0.00173622673212),
                        upBounds = cms.vdouble(2.1, 30.0),
                        values = cms.vdouble(0.993530379812)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 25.0),
                        uncertainties = cms.vdouble(0.00173622673212, 0.00173622673212),
                        upBounds = cms.vdouble(-1.2, 30.0),
                        values = cms.vdouble(0.993530379812)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.75),
                        uncertainties = cms.vdouble(0.00912606332612, 0.00912606332612),
                        upBounds = cms.vdouble(2.1, 3.0),
                        values = cms.vdouble(0.986919644367)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.75),
                        uncertainties = cms.vdouble(0.00912606332612, 0.00912606332612),
                        upBounds = cms.vdouble(-1.2, 3.0),
                        values = cms.vdouble(0.986919644367)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 60.0),
                        uncertainties = cms.vdouble(0.00273336428507, 0.00273336428507),
                        upBounds = cms.vdouble(2.1, float('inf')),
                        values = cms.vdouble(0.996436428655)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 60.0),
                        uncertainties = cms.vdouble(0.00273336428507, 0.00273336428507),
                        upBounds = cms.vdouble(-1.2, float('inf')),
                        values = cms.vdouble(0.996436428655)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 15.0),
                        uncertainties = cms.vdouble(0.0191694887963, 0.0191694887963),
                        upBounds = cms.vdouble(2.1, 20.0),
                        values = cms.vdouble(0.999986384631)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 15.0),
                        uncertainties = cms.vdouble(0.0191694887963, 0.0191694887963),
                        upBounds = cms.vdouble(-1.2, 20.0),
                        values = cms.vdouble(0.999986384631)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 4.0),
                        uncertainties = cms.vdouble(0.00653056546752, 0.00653056546752),
                        upBounds = cms.vdouble(2.1, 4.5),
                        values = cms.vdouble(0.992218429387)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 4.0),
                        uncertainties = cms.vdouble(0.00653056546752, 0.00653056546752),
                        upBounds = cms.vdouble(-1.2, 4.5),
                        values = cms.vdouble(0.992218429387)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.25),
                        uncertainties = cms.vdouble(0.00729816164028, 0.00729816164028),
                        upBounds = cms.vdouble(2.1, 3.5),
                        values = cms.vdouble(0.986602392121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.25),
                        uncertainties = cms.vdouble(0.00729816164028, 0.00729816164028),
                        upBounds = cms.vdouble(-1.2, 3.5),
                        values = cms.vdouble(0.986602392121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 2.0),
                        uncertainties = cms.vdouble(0.022506195688, 0.022506195688),
                        upBounds = cms.vdouble(2.1, 2.5),
                        values = cms.vdouble(0.980681394619)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 2.0),
                        uncertainties = cms.vdouble(0.022506195688, 0.022506195688),
                        upBounds = cms.vdouble(-1.2, 2.5),
                        values = cms.vdouble(0.980681394619)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 10.0),
                        uncertainties = cms.vdouble(0.012656417927, 0.012656417927),
                        upBounds = cms.vdouble(2.1, 15.0),
                        values = cms.vdouble(1.00188205103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 10.0),
                        uncertainties = cms.vdouble(0.012656417927, 0.012656417927),
                        upBounds = cms.vdouble(-1.2, 15.0),
                        values = cms.vdouble(1.00188205103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 6.0),
                        uncertainties = cms.vdouble(0.0084679535697, 0.0084679535697),
                        upBounds = cms.vdouble(2.1, 8.0),
                        values = cms.vdouble(0.995278662396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 6.0),
                        uncertainties = cms.vdouble(0.0084679535697, 0.0084679535697),
                        upBounds = cms.vdouble(-1.2, 8.0),
                        values = cms.vdouble(0.995278662396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 3.75),
                        uncertainties = cms.vdouble(0.00648266247749, 0.00648266247749),
                        upBounds = cms.vdouble(2.1, 4.0),
                        values = cms.vdouble(0.98727403084)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 3.75),
                        uncertainties = cms.vdouble(0.00648266247749, 0.00648266247749),
                        upBounds = cms.vdouble(-1.2, 4.0),
                        values = cms.vdouble(0.98727403084)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 30.0),
                        uncertainties = cms.vdouble(0.0116620740623, 0.0116620740623),
                        upBounds = cms.vdouble(2.1, 40.0),
                        values = cms.vdouble(0.99824216396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 30.0),
                        uncertainties = cms.vdouble(0.0116620740623, 0.0116620740623),
                        upBounds = cms.vdouble(-1.2, 40.0),
                        values = cms.vdouble(0.99824216396)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 40.0),
                        uncertainties = cms.vdouble(0.000627874806677, 0.000627874806677),
                        upBounds = cms.vdouble(2.1, 50.0),
                        values = cms.vdouble(0.995923566095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 40.0),
                        uncertainties = cms.vdouble(0.000627874806677, 0.000627874806677),
                        upBounds = cms.vdouble(-1.2, 50.0),
                        values = cms.vdouble(0.995923566095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.1, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-1.2, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 20.0),
                        uncertainties = cms.vdouble(0.0198265829746, 0.0198265829746),
                        upBounds = cms.vdouble(2.4, 25.0),
                        values = cms.vdouble(0.975996588061)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 20.0),
                        uncertainties = cms.vdouble(0.0198265829746, 0.0198265829746),
                        upBounds = cms.vdouble(-2.1, 25.0),
                        values = cms.vdouble(0.975996588061)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.0),
                        uncertainties = cms.vdouble(0.0127859287622, 0.0127859287622),
                        upBounds = cms.vdouble(2.4, 3.25),
                        values = cms.vdouble(0.982851318095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.0),
                        uncertainties = cms.vdouble(0.0127859287622, 0.0127859287622),
                        upBounds = cms.vdouble(-2.1, 3.25),
                        values = cms.vdouble(0.982851318095)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.5),
                        uncertainties = cms.vdouble(0.0121339640224, 0.0121339640224),
                        upBounds = cms.vdouble(2.4, 3.75),
                        values = cms.vdouble(0.975062519006)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.5),
                        uncertainties = cms.vdouble(0.0121339640224, 0.0121339640224),
                        upBounds = cms.vdouble(-2.1, 3.75),
                        values = cms.vdouble(0.975062519006)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.5),
                        uncertainties = cms.vdouble(0.0104430782557, 0.0104430782557),
                        upBounds = cms.vdouble(2.4, 2.75),
                        values = cms.vdouble(0.994797585156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.5),
                        uncertainties = cms.vdouble(0.0104430782557, 0.0104430782557),
                        upBounds = cms.vdouble(-2.1, 2.75),
                        values = cms.vdouble(0.994797585156)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 8.0),
                        uncertainties = cms.vdouble(0.0287971901566, 0.0287971901566),
                        upBounds = cms.vdouble(2.4, 10.0),
                        values = cms.vdouble(0.998439579201)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 8.0),
                        uncertainties = cms.vdouble(0.0287971901566, 0.0287971901566),
                        upBounds = cms.vdouble(-2.1, 10.0),
                        values = cms.vdouble(0.998439579201)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 5.0),
                        uncertainties = cms.vdouble(0.0114309112159, 0.0114309112159),
                        upBounds = cms.vdouble(2.4, 6.0),
                        values = cms.vdouble(0.97369571971)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 5.0),
                        uncertainties = cms.vdouble(0.0114309112159, 0.0114309112159),
                        upBounds = cms.vdouble(-2.1, 6.0),
                        values = cms.vdouble(0.97369571971)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 4.5),
                        uncertainties = cms.vdouble(0.013060031494, 0.013060031494),
                        upBounds = cms.vdouble(2.4, 5.0),
                        values = cms.vdouble(0.989372207781)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 4.5),
                        uncertainties = cms.vdouble(0.013060031494, 0.013060031494),
                        upBounds = cms.vdouble(-2.1, 5.0),
                        values = cms.vdouble(0.989372207781)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 50.0),
                        uncertainties = cms.vdouble(0.0031594299819, 0.0031594299819),
                        upBounds = cms.vdouble(2.4, 60.0),
                        values = cms.vdouble(0.971127267001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 50.0),
                        uncertainties = cms.vdouble(0.0031594299819, 0.0031594299819),
                        upBounds = cms.vdouble(-2.1, 60.0),
                        values = cms.vdouble(0.971127267001)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 25.0),
                        uncertainties = cms.vdouble(0.020931162366, 0.020931162366),
                        upBounds = cms.vdouble(2.4, 30.0),
                        values = cms.vdouble(0.97456711052)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 25.0),
                        uncertainties = cms.vdouble(0.020931162366, 0.020931162366),
                        upBounds = cms.vdouble(-2.1, 30.0),
                        values = cms.vdouble(0.97456711052)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.75),
                        uncertainties = cms.vdouble(0.0105757316725, 0.0105757316725),
                        upBounds = cms.vdouble(2.4, 3.0),
                        values = cms.vdouble(0.982312781194)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.75),
                        uncertainties = cms.vdouble(0.0105757316725, 0.0105757316725),
                        upBounds = cms.vdouble(-2.1, 3.0),
                        values = cms.vdouble(0.982312781194)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 60.0),
                        uncertainties = cms.vdouble(0.00840769988892, 0.00840769988892),
                        upBounds = cms.vdouble(2.4, float('inf')),
                        values = cms.vdouble(0.981026986469)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 60.0),
                        uncertainties = cms.vdouble(0.00840769988892, 0.00840769988892),
                        upBounds = cms.vdouble(-2.1, float('inf')),
                        values = cms.vdouble(0.981026986469)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 15.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 20.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 15.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 20.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 4.0),
                        uncertainties = cms.vdouble(0.0123135695005, 0.0123135695005),
                        upBounds = cms.vdouble(2.4, 4.5),
                        values = cms.vdouble(0.979392128378)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 4.0),
                        uncertainties = cms.vdouble(0.0123135695005, 0.0123135695005),
                        upBounds = cms.vdouble(-2.1, 4.5),
                        values = cms.vdouble(0.979392128378)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.25),
                        uncertainties = cms.vdouble(0.0110961263986, 0.0110961263986),
                        upBounds = cms.vdouble(2.4, 3.5),
                        values = cms.vdouble(0.973787012958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.25),
                        uncertainties = cms.vdouble(0.0110961263986, 0.0110961263986),
                        upBounds = cms.vdouble(-2.1, 3.5),
                        values = cms.vdouble(0.973787012958)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 2.0),
                        uncertainties = cms.vdouble(0.0128486487863, 0.0128486487863),
                        upBounds = cms.vdouble(2.4, 2.5),
                        values = cms.vdouble(0.989983698915)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 2.0),
                        uncertainties = cms.vdouble(0.0128486487863, 0.0128486487863),
                        upBounds = cms.vdouble(-2.1, 2.5),
                        values = cms.vdouble(0.989983698915)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 10.0),
                        uncertainties = cms.vdouble(0.0681946163707, 0.0681946163707),
                        upBounds = cms.vdouble(2.4, 15.0),
                        values = cms.vdouble(0.958219283228)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 10.0),
                        uncertainties = cms.vdouble(0.0681946163707, 0.0681946163707),
                        upBounds = cms.vdouble(-2.1, 15.0),
                        values = cms.vdouble(0.958219283228)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 6.0),
                        uncertainties = cms.vdouble(0.0144472473076, 0.0144472473076),
                        upBounds = cms.vdouble(2.4, 8.0),
                        values = cms.vdouble(0.982296382437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 6.0),
                        uncertainties = cms.vdouble(0.0144472473076, 0.0144472473076),
                        upBounds = cms.vdouble(-2.1, 8.0),
                        values = cms.vdouble(0.982296382437)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 3.75),
                        uncertainties = cms.vdouble(0.010931477944, 0.010931477944),
                        upBounds = cms.vdouble(2.4, 4.0),
                        values = cms.vdouble(0.989547727624)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 3.75),
                        uncertainties = cms.vdouble(0.010931477944, 0.010931477944),
                        upBounds = cms.vdouble(-2.1, 4.0),
                        values = cms.vdouble(0.989547727624)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 30.0),
                        uncertainties = cms.vdouble(0.0265683528042, 0.0265683528042),
                        upBounds = cms.vdouble(2.4, 40.0),
                        values = cms.vdouble(0.979122449183)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 30.0),
                        uncertainties = cms.vdouble(0.0265683528042, 0.0265683528042),
                        upBounds = cms.vdouble(-2.1, 40.0),
                        values = cms.vdouble(0.979122449183)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 40.0),
                        uncertainties = cms.vdouble(0.000995955133576, 0.000995955133576),
                        upBounds = cms.vdouble(2.4, 50.0),
                        values = cms.vdouble(0.976366805953)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 40.0),
                        uncertainties = cms.vdouble(0.000995955133576, 0.000995955133576),
                        upBounds = cms.vdouble(-2.1, 50.0),
                        values = cms.vdouble(0.976366805953)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 20.0),
                        uncertainties = cms.vdouble(0.00468476023906, 0.00468476023906),
                        upBounds = cms.vdouble(1.2, 25.0),
                        values = cms.vdouble(1.00460587803)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 20.0),
                        uncertainties = cms.vdouble(0.00468476023906, 0.00468476023906),
                        upBounds = cms.vdouble(-0.9, 25.0),
                        values = cms.vdouble(1.00460587803)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.0),
                        uncertainties = cms.vdouble(0.296887585958, 0.296887585958),
                        upBounds = cms.vdouble(1.2, 3.25),
                        values = cms.vdouble(1.11706863713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.0),
                        uncertainties = cms.vdouble(0.296887585958, 0.296887585958),
                        upBounds = cms.vdouble(-0.9, 3.25),
                        values = cms.vdouble(1.11706863713)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.5),
                        uncertainties = cms.vdouble(0.0245327565848, 0.0245327565848),
                        upBounds = cms.vdouble(1.2, 3.75),
                        values = cms.vdouble(1.00671914661)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.5),
                        uncertainties = cms.vdouble(0.0245327565848, 0.0245327565848),
                        upBounds = cms.vdouble(-0.9, 3.75),
                        values = cms.vdouble(1.00671914661)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.5),
                        uncertainties = cms.vdouble(9.74130183204, 9.74130183204),
                        upBounds = cms.vdouble(1.2, 2.75),
                        values = cms.vdouble(0.392514388413)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.5),
                        uncertainties = cms.vdouble(9.74130183204, 9.74130183204),
                        upBounds = cms.vdouble(-0.9, 2.75),
                        values = cms.vdouble(0.392514388413)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 8.0),
                        uncertainties = cms.vdouble(0.00977003583855, 0.00977003583855),
                        upBounds = cms.vdouble(1.2, 10.0),
                        values = cms.vdouble(0.993092222523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 8.0),
                        uncertainties = cms.vdouble(0.00977003583855, 0.00977003583855),
                        upBounds = cms.vdouble(-0.9, 10.0),
                        values = cms.vdouble(0.993092222523)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 5.0),
                        uncertainties = cms.vdouble(0.00806563696427, 0.00806563696427),
                        upBounds = cms.vdouble(1.2, 6.0),
                        values = cms.vdouble(0.995174524966)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 5.0),
                        uncertainties = cms.vdouble(0.00806563696427, 0.00806563696427),
                        upBounds = cms.vdouble(-0.9, 6.0),
                        values = cms.vdouble(0.995174524966)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 4.5),
                        uncertainties = cms.vdouble(0.0100275932498, 0.0100275932498),
                        upBounds = cms.vdouble(1.2, 5.0),
                        values = cms.vdouble(0.994052917641)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 4.5),
                        uncertainties = cms.vdouble(0.0100275932498, 0.0100275932498),
                        upBounds = cms.vdouble(-0.9, 5.0),
                        values = cms.vdouble(0.994052917641)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 50.0),
                        uncertainties = cms.vdouble(0.00140847732849, 0.00140847732849),
                        upBounds = cms.vdouble(1.2, 60.0),
                        values = cms.vdouble(0.996740307518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 50.0),
                        uncertainties = cms.vdouble(0.00140847732849, 0.00140847732849),
                        upBounds = cms.vdouble(-0.9, 60.0),
                        values = cms.vdouble(0.996740307518)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 25.0),
                        uncertainties = cms.vdouble(0.0076611932683, 0.0076611932683),
                        upBounds = cms.vdouble(1.2, 30.0),
                        values = cms.vdouble(0.996304500853)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 25.0),
                        uncertainties = cms.vdouble(0.0076611932683, 0.0076611932683),
                        upBounds = cms.vdouble(-0.9, 30.0),
                        values = cms.vdouble(0.996304500853)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.75),
                        uncertainties = cms.vdouble(3.13949110829, 3.13949110829),
                        upBounds = cms.vdouble(1.2, 3.0),
                        values = cms.vdouble(1.02551382269)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.75),
                        uncertainties = cms.vdouble(3.13949110829, 3.13949110829),
                        upBounds = cms.vdouble(-0.9, 3.0),
                        values = cms.vdouble(1.02551382269)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 60.0),
                        uncertainties = cms.vdouble(0.00509423672107, 0.00509423672107),
                        upBounds = cms.vdouble(1.2, float('inf')),
                        values = cms.vdouble(0.99567430311)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 60.0),
                        uncertainties = cms.vdouble(0.00509423672107, 0.00509423672107),
                        upBounds = cms.vdouble(-0.9, float('inf')),
                        values = cms.vdouble(0.99567430311)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 15.0),
                        uncertainties = cms.vdouble(0.0183853610848, 0.0183853610848),
                        upBounds = cms.vdouble(1.2, 20.0),
                        values = cms.vdouble(0.99999464277)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 15.0),
                        uncertainties = cms.vdouble(0.0183853610848, 0.0183853610848),
                        upBounds = cms.vdouble(-0.9, 20.0),
                        values = cms.vdouble(0.99999464277)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 4.0),
                        uncertainties = cms.vdouble(0.0103227916212, 0.0103227916212),
                        upBounds = cms.vdouble(1.2, 4.5),
                        values = cms.vdouble(0.996421849121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 4.0),
                        uncertainties = cms.vdouble(0.0103227916212, 0.0103227916212),
                        upBounds = cms.vdouble(-0.9, 4.5),
                        values = cms.vdouble(0.996421849121)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.25),
                        uncertainties = cms.vdouble(0.0533754930135, 0.0533754930135),
                        upBounds = cms.vdouble(1.2, 3.5),
                        values = cms.vdouble(1.04051878063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.25),
                        uncertainties = cms.vdouble(0.0533754930135, 0.0533754930135),
                        upBounds = cms.vdouble(-0.9, 3.5),
                        values = cms.vdouble(1.04051878063)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 2.0),
                        uncertainties = cms.vdouble(5.4486102689, 5.4486102689),
                        upBounds = cms.vdouble(1.2, 2.5),
                        values = cms.vdouble(0.287230284869)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 2.0),
                        uncertainties = cms.vdouble(5.4486102689, 5.4486102689),
                        upBounds = cms.vdouble(-0.9, 2.5),
                        values = cms.vdouble(0.287230284869)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 10.0),
                        uncertainties = cms.vdouble(0.0131433116066, 0.0131433116066),
                        upBounds = cms.vdouble(1.2, 15.0),
                        values = cms.vdouble(1.00136073769)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 10.0),
                        uncertainties = cms.vdouble(0.0131433116066, 0.0131433116066),
                        upBounds = cms.vdouble(-0.9, 15.0),
                        values = cms.vdouble(1.00136073769)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 6.0),
                        uncertainties = cms.vdouble(0.00832230192794, 0.00832230192794),
                        upBounds = cms.vdouble(1.2, 8.0),
                        values = cms.vdouble(0.992275142352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 6.0),
                        uncertainties = cms.vdouble(0.00832230192794, 0.00832230192794),
                        upBounds = cms.vdouble(-0.9, 8.0),
                        values = cms.vdouble(0.992275142352)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 3.75),
                        uncertainties = cms.vdouble(0.017244093964, 0.017244093964),
                        upBounds = cms.vdouble(1.2, 4.0),
                        values = cms.vdouble(1.01217517033)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 3.75),
                        uncertainties = cms.vdouble(0.017244093964, 0.017244093964),
                        upBounds = cms.vdouble(-0.9, 4.0),
                        values = cms.vdouble(1.01217517033)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 30.0),
                        uncertainties = cms.vdouble(0.00239937467763, 0.00239937467763),
                        upBounds = cms.vdouble(1.2, 40.0),
                        values = cms.vdouble(0.999489017253)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 30.0),
                        uncertainties = cms.vdouble(0.00239937467763, 0.00239937467763),
                        upBounds = cms.vdouble(-0.9, 40.0),
                        values = cms.vdouble(0.999489017253)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 40.0),
                        uncertainties = cms.vdouble(0.000529028569286, 0.000529028569286),
                        upBounds = cms.vdouble(1.2, 50.0),
                        values = cms.vdouble(0.9975113899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 40.0),
                        uncertainties = cms.vdouble(0.000529028569286, 0.000529028569286),
                        upBounds = cms.vdouble(-0.9, 50.0),
                        values = cms.vdouble(0.9975113899)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(1.2, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.9, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.0042584153216, 0.0042584153216),
                        upBounds = cms.vdouble(0.9, 25.0),
                        values = cms.vdouble(0.994630070584)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 20.0),
                        uncertainties = cms.vdouble(0.0042584153216, 0.0042584153216),
                        upBounds = cms.vdouble(-0.0, 25.0),
                        values = cms.vdouble(0.994630070584)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.0),
                        uncertainties = cms.vdouble(0.288563828351, 0.288563828351),
                        upBounds = cms.vdouble(0.9, 3.25),
                        values = cms.vdouble(1.06254655623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.0),
                        uncertainties = cms.vdouble(0.288563828351, 0.288563828351),
                        upBounds = cms.vdouble(-0.0, 3.25),
                        values = cms.vdouble(1.06254655623)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.5),
                        uncertainties = cms.vdouble(0.0119829149142, 0.0119829149142),
                        upBounds = cms.vdouble(0.9, 3.75),
                        values = cms.vdouble(0.987593707404)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.5),
                        uncertainties = cms.vdouble(0.0119829149142, 0.0119829149142),
                        upBounds = cms.vdouble(-0.0, 3.75),
                        values = cms.vdouble(0.987593707404)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.5),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.75),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.5),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.75),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 8.0),
                        uncertainties = cms.vdouble(0.00579502099243, 0.00579502099243),
                        upBounds = cms.vdouble(0.9, 10.0),
                        values = cms.vdouble(0.995333082799)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 8.0),
                        uncertainties = cms.vdouble(0.00579502099243, 0.00579502099243),
                        upBounds = cms.vdouble(-0.0, 10.0),
                        values = cms.vdouble(0.995333082799)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 5.0),
                        uncertainties = cms.vdouble(0.00489401366652, 0.00489401366652),
                        upBounds = cms.vdouble(0.9, 6.0),
                        values = cms.vdouble(0.996237115913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 5.0),
                        uncertainties = cms.vdouble(0.00489401366652, 0.00489401366652),
                        upBounds = cms.vdouble(-0.0, 6.0),
                        values = cms.vdouble(0.996237115913)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 4.5),
                        uncertainties = cms.vdouble(0.00544655327423, 0.00544655327423),
                        upBounds = cms.vdouble(0.9, 5.0),
                        values = cms.vdouble(0.994989399151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 4.5),
                        uncertainties = cms.vdouble(0.00544655327423, 0.00544655327423),
                        upBounds = cms.vdouble(-0.0, 5.0),
                        values = cms.vdouble(0.994989399151)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.000769664095383, 0.000769664095383),
                        upBounds = cms.vdouble(0.9, 60.0),
                        values = cms.vdouble(0.993757790384)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 50.0),
                        uncertainties = cms.vdouble(0.000769664095383, 0.000769664095383),
                        upBounds = cms.vdouble(-0.0, 60.0),
                        values = cms.vdouble(0.993757790384)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 25.0),
                        uncertainties = cms.vdouble(0.00162720030192, 0.00162720030192),
                        upBounds = cms.vdouble(0.9, 30.0),
                        values = cms.vdouble(0.994270401894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 25.0),
                        uncertainties = cms.vdouble(0.00162720030192, 0.00162720030192),
                        upBounds = cms.vdouble(-0.0, 30.0),
                        values = cms.vdouble(0.994270401894)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.75),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 3.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.75),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 3.0),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 60.0),
                        uncertainties = cms.vdouble(0.00300287148272, 0.00300287148272),
                        upBounds = cms.vdouble(0.9, float('inf')),
                        values = cms.vdouble(0.997312258632)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 60.0),
                        uncertainties = cms.vdouble(0.00300287148272, 0.00300287148272),
                        upBounds = cms.vdouble(-0.0, float('inf')),
                        values = cms.vdouble(0.997312258632)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 15.0),
                        uncertainties = cms.vdouble(0.0076883687727, 0.0076883687727),
                        upBounds = cms.vdouble(0.9, 20.0),
                        values = cms.vdouble(0.994972383613)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 15.0),
                        uncertainties = cms.vdouble(0.0076883687727, 0.0076883687727),
                        upBounds = cms.vdouble(-0.0, 20.0),
                        values = cms.vdouble(0.994972383613)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 4.0),
                        uncertainties = cms.vdouble(0.00566742840082, 0.00566742840082),
                        upBounds = cms.vdouble(0.9, 4.5),
                        values = cms.vdouble(0.995624981547)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 4.0),
                        uncertainties = cms.vdouble(0.00566742840082, 0.00566742840082),
                        upBounds = cms.vdouble(-0.0, 4.5),
                        values = cms.vdouble(0.995624981547)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.25),
                        uncertainties = cms.vdouble(0.0292255510167, 0.0292255510167),
                        upBounds = cms.vdouble(0.9, 3.5),
                        values = cms.vdouble(1.00067406873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.25),
                        uncertainties = cms.vdouble(0.0292255510167, 0.0292255510167),
                        upBounds = cms.vdouble(-0.0, 3.5),
                        values = cms.vdouble(1.00067406873)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 2.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.5),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 2.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.5),
                        values = cms.vdouble(1)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 10.0),
                        uncertainties = cms.vdouble(0.0068073849175, 0.0068073849175),
                        upBounds = cms.vdouble(0.9, 15.0),
                        values = cms.vdouble(0.995411694989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 10.0),
                        uncertainties = cms.vdouble(0.0068073849175, 0.0068073849175),
                        upBounds = cms.vdouble(-0.0, 15.0),
                        values = cms.vdouble(0.995411694989)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 6.0),
                        uncertainties = cms.vdouble(0.00490421169823, 0.00490421169823),
                        upBounds = cms.vdouble(0.9, 8.0),
                        values = cms.vdouble(0.994088331695)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 6.0),
                        uncertainties = cms.vdouble(0.00490421169823, 0.00490421169823),
                        upBounds = cms.vdouble(-0.0, 8.0),
                        values = cms.vdouble(0.994088331695)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 3.75),
                        uncertainties = cms.vdouble(0.0081997787709, 0.0081997787709),
                        upBounds = cms.vdouble(0.9, 4.0),
                        values = cms.vdouble(0.99739659542)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 3.75),
                        uncertainties = cms.vdouble(0.0081997787709, 0.0081997787709),
                        upBounds = cms.vdouble(-0.0, 4.0),
                        values = cms.vdouble(0.99739659542)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.0026058520667, 0.0026058520667),
                        upBounds = cms.vdouble(0.9, 40.0),
                        values = cms.vdouble(0.998511261944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 30.0),
                        uncertainties = cms.vdouble(0.0026058520667, 0.0026058520667),
                        upBounds = cms.vdouble(-0.0, 40.0),
                        values = cms.vdouble(0.998511261944)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 40.0),
                        uncertainties = cms.vdouble(0.000359094425458, 0.000359094425458),
                        upBounds = cms.vdouble(0.9, 50.0),
                        values = cms.vdouble(0.996668218039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 40.0),
                        uncertainties = cms.vdouble(0.000359094425458, 0.000359094425458),
                        upBounds = cms.vdouble(-0.0, 50.0),
                        values = cms.vdouble(0.996668218039)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 2.0),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 2.0),
                        values = cms.vdouble(1.0)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MuonMediumIDWeight'),
            MethodName = cms.string('FlashggMuonWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.4')
        ), 
        cms.PSet(
            ApplyCentralValue = cms.bool(True),
            BinList = cms.PSet(
                bins = cms.VPSet(
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 20.0),
                        uncertainties = cms.vdouble(0.00195976775559, 0.00195976775559),
                        upBounds = cms.vdouble(2.1, 25.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 20.0),
                        uncertainties = cms.vdouble(0.00195976775559, 0.00195976775559),
                        upBounds = cms.vdouble(-1.2, 25.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 50.0),
                        uncertainties = cms.vdouble(0.000248116114645, 0.000248116114645),
                        upBounds = cms.vdouble(2.1, 60.0),
                        values = cms.vdouble(0.99969852486)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 50.0),
                        uncertainties = cms.vdouble(0.000248116114645, 0.000248116114645),
                        upBounds = cms.vdouble(-1.2, 60.0),
                        values = cms.vdouble(0.99969852486)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 25.0),
                        uncertainties = cms.vdouble(0.00102940216472, 0.00102940216472),
                        upBounds = cms.vdouble(2.1, 30.0),
                        values = cms.vdouble(0.998951934051)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 25.0),
                        uncertainties = cms.vdouble(0.00102940216472, 0.00102940216472),
                        upBounds = cms.vdouble(-1.2, 30.0),
                        values = cms.vdouble(0.998951934051)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 60.0),
                        uncertainties = cms.vdouble(0.00054048095508, 0.00054048095508),
                        upBounds = cms.vdouble(2.1, float('inf')),
                        values = cms.vdouble(1.00035447289)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 60.0),
                        uncertainties = cms.vdouble(0.00054048095508, 0.00054048095508),
                        upBounds = cms.vdouble(-1.2, float('inf')),
                        values = cms.vdouble(1.00035447289)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 30.0),
                        uncertainties = cms.vdouble(0.000356942539717, 0.000356942539717),
                        upBounds = cms.vdouble(2.1, 40.0),
                        values = cms.vdouble(0.998898672807)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 30.0),
                        uncertainties = cms.vdouble(0.000356942539717, 0.000356942539717),
                        upBounds = cms.vdouble(-1.2, 40.0),
                        values = cms.vdouble(0.998898672807)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 40.0),
                        uncertainties = cms.vdouble(0.000119050115919, 0.000119050115919),
                        upBounds = cms.vdouble(2.1, 50.0),
                        values = cms.vdouble(0.999386758588)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 40.0),
                        uncertainties = cms.vdouble(0.000119050115919, 0.000119050115919),
                        upBounds = cms.vdouble(-1.2, 50.0),
                        values = cms.vdouble(0.999386758588)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.1, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-1.2, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(1.2, 5),
                        uncertainties = cms.vdouble(0.00391953551119, 0.00391953551119),
                        upBounds = cms.vdouble(2.1, 20.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.1, 5),
                        uncertainties = cms.vdouble(0.00391953551119, 0.00391953551119),
                        upBounds = cms.vdouble(-1.2, 20.0),
                        values = cms.vdouble(0.996690354512)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 20.0),
                        uncertainties = cms.vdouble(0.00237277391402, 0.00237277391402),
                        upBounds = cms.vdouble(2.4, 25.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 20.0),
                        uncertainties = cms.vdouble(0.00237277391402, 0.00237277391402),
                        upBounds = cms.vdouble(-2.1, 25.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 50.0),
                        uncertainties = cms.vdouble(0.000522685299927, 0.000522685299927),
                        upBounds = cms.vdouble(2.4, 60.0),
                        values = cms.vdouble(1.00011124693)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 50.0),
                        uncertainties = cms.vdouble(0.000522685299927, 0.000522685299927),
                        upBounds = cms.vdouble(-2.1, 60.0),
                        values = cms.vdouble(1.00011124693)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 25.0),
                        uncertainties = cms.vdouble(0.00130829186635, 0.00130829186635),
                        upBounds = cms.vdouble(2.4, 30.0),
                        values = cms.vdouble(0.999028750143)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 25.0),
                        uncertainties = cms.vdouble(0.00130829186635, 0.00130829186635),
                        upBounds = cms.vdouble(-2.1, 30.0),
                        values = cms.vdouble(0.999028750143)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 60.0),
                        uncertainties = cms.vdouble(0.000908910123556, 0.000908910123556),
                        upBounds = cms.vdouble(2.4, float('inf')),
                        values = cms.vdouble(0.99937695355)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 60.0),
                        uncertainties = cms.vdouble(0.000908910123556, 0.000908910123556),
                        upBounds = cms.vdouble(-2.1, float('inf')),
                        values = cms.vdouble(0.99937695355)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 30.0),
                        uncertainties = cms.vdouble(0.000513599294717, 0.000513599294717),
                        upBounds = cms.vdouble(2.4, 40.0),
                        values = cms.vdouble(0.998896811778)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 30.0),
                        uncertainties = cms.vdouble(0.000513599294717, 0.000513599294717),
                        upBounds = cms.vdouble(-2.1, 40.0),
                        values = cms.vdouble(0.998896811778)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 40.0),
                        uncertainties = cms.vdouble(0.000588106305763, 0.000588106305763),
                        upBounds = cms.vdouble(2.4, 50.0),
                        values = cms.vdouble(0.999605390435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 40.0),
                        uncertainties = cms.vdouble(0.000588106305763, 0.000588106305763),
                        upBounds = cms.vdouble(-2.1, 50.0),
                        values = cms.vdouble(0.999605390435)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(2.4, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-2.1, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(2.1, 5),
                        uncertainties = cms.vdouble(0.00474554782804, 0.00474554782804),
                        upBounds = cms.vdouble(2.4, 20.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-2.4, 5),
                        uncertainties = cms.vdouble(0.00474554782804, 0.00474554782804),
                        upBounds = cms.vdouble(-2.1, 20.0),
                        values = cms.vdouble(0.997504245941)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 20.0),
                        uncertainties = cms.vdouble(0.00436024925765, 0.00436024925765),
                        upBounds = cms.vdouble(1.2, 25.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 20.0),
                        uncertainties = cms.vdouble(0.00436024925765, 0.00436024925765),
                        upBounds = cms.vdouble(-0.9, 25.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 50.0),
                        uncertainties = cms.vdouble(0.000618031671457, 0.000618031671457),
                        upBounds = cms.vdouble(1.2, 60.0),
                        values = cms.vdouble(0.999299532103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 50.0),
                        uncertainties = cms.vdouble(0.000618031671457, 0.000618031671457),
                        upBounds = cms.vdouble(-0.9, 60.0),
                        values = cms.vdouble(0.999299532103)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 25.0),
                        uncertainties = cms.vdouble(0.00218414248432, 0.00218414248432),
                        upBounds = cms.vdouble(1.2, 30.0),
                        values = cms.vdouble(0.993100424785)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 25.0),
                        uncertainties = cms.vdouble(0.00218414248432, 0.00218414248432),
                        upBounds = cms.vdouble(-0.9, 30.0),
                        values = cms.vdouble(0.993100424785)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 60.0),
                        uncertainties = cms.vdouble(0.00101961792784, 0.00101961792784),
                        upBounds = cms.vdouble(1.2, float('inf')),
                        values = cms.vdouble(1.00011893067)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 60.0),
                        uncertainties = cms.vdouble(0.00101961792784, 0.00101961792784),
                        upBounds = cms.vdouble(-0.9, float('inf')),
                        values = cms.vdouble(1.00011893067)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 30.0),
                        uncertainties = cms.vdouble(0.000530612904543, 0.000530612904543),
                        upBounds = cms.vdouble(1.2, 40.0),
                        values = cms.vdouble(0.997462630361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 30.0),
                        uncertainties = cms.vdouble(0.000530612904543, 0.000530612904543),
                        upBounds = cms.vdouble(-0.9, 40.0),
                        values = cms.vdouble(0.997462630361)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 40.0),
                        uncertainties = cms.vdouble(0.000227245277765, 0.000227245277765),
                        upBounds = cms.vdouble(1.2, 50.0),
                        values = cms.vdouble(0.998862324847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 40.0),
                        uncertainties = cms.vdouble(0.000227245277765, 0.000227245277765),
                        upBounds = cms.vdouble(-0.9, 50.0),
                        values = cms.vdouble(0.998862324847)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(1.2, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.9, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.9, 5),
                        uncertainties = cms.vdouble(0.0087204985153, 0.0087204985153),
                        upBounds = cms.vdouble(1.2, 20.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-1.2, 5),
                        uncertainties = cms.vdouble(0.0087204985153, 0.0087204985153),
                        upBounds = cms.vdouble(-0.9, 20.0),
                        values = cms.vdouble(0.994414232258)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 20.0),
                        uncertainties = cms.vdouble(0.00255836254879, 0.00255836254879),
                        upBounds = cms.vdouble(0.9, 25.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 20.0),
                        uncertainties = cms.vdouble(0.00255836254879, 0.00255836254879),
                        upBounds = cms.vdouble(-0.0, 25.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 50.0),
                        uncertainties = cms.vdouble(0.000299982567634, 0.000299982567634),
                        upBounds = cms.vdouble(0.9, 60.0),
                        values = cms.vdouble(0.999720244659)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 50.0),
                        uncertainties = cms.vdouble(0.000299982567634, 0.000299982567634),
                        upBounds = cms.vdouble(-0.0, 60.0),
                        values = cms.vdouble(0.999720244659)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 25.0),
                        uncertainties = cms.vdouble(0.00126427851203, 0.00126427851203),
                        upBounds = cms.vdouble(0.9, 30.0),
                        values = cms.vdouble(0.996396474716)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 25.0),
                        uncertainties = cms.vdouble(0.00126427851203, 0.00126427851203),
                        upBounds = cms.vdouble(-0.0, 30.0),
                        values = cms.vdouble(0.996396474716)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 60.0),
                        uncertainties = cms.vdouble(0.000351458119665, 0.000351458119665),
                        upBounds = cms.vdouble(0.9, float('inf')),
                        values = cms.vdouble(1.00003708794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 60.0),
                        uncertainties = cms.vdouble(0.000351458119665, 0.000351458119665),
                        upBounds = cms.vdouble(-0.0, float('inf')),
                        values = cms.vdouble(1.00003708794)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 30.0),
                        uncertainties = cms.vdouble(0.000405487475336, 0.000405487475336),
                        upBounds = cms.vdouble(0.9, 40.0),
                        values = cms.vdouble(0.998285156643)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 30.0),
                        uncertainties = cms.vdouble(0.000405487475336, 0.000405487475336),
                        upBounds = cms.vdouble(-0.0, 40.0),
                        values = cms.vdouble(0.998285156643)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 40.0),
                        uncertainties = cms.vdouble(0.000134135966903, 0.000134135966903),
                        upBounds = cms.vdouble(0.9, 50.0),
                        values = cms.vdouble(0.999386282629)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 40.0),
                        uncertainties = cms.vdouble(0.000134135966903, 0.000134135966903),
                        upBounds = cms.vdouble(-0.0, 50.0),
                        values = cms.vdouble(0.999386282629)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(0.9, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 0.0),
                        uncertainties = cms.vdouble(0.0, 0.0),
                        upBounds = cms.vdouble(-0.0, 5),
                        values = cms.vdouble(1.0)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(0.0, 5),
                        uncertainties = cms.vdouble(0.00511672509758, 0.00511672509758),
                        upBounds = cms.vdouble(0.9, 20.0),
                        values = cms.vdouble(0.992514242393)
                    ), 
                    cms.PSet(
                        lowBounds = cms.vdouble(-0.9, 5),
                        uncertainties = cms.vdouble(0.00511672509758, 0.00511672509758),
                        upBounds = cms.vdouble(-0.0, 20.0),
                        values = cms.vdouble(0.992514242393)
                    )
                ),
                variables = cms.vstring(
                    'eta', 
                    'pt'
                )
            ),
            Debug = cms.untracked.bool(False),
            Label = cms.string('MuonLooseRelISOWeight'),
            MethodName = cms.string('FlashggMuonWeight'),
            NSigmas = cms.vint32(-1, 1),
            OverallRange = cms.string('abs(eta)<2.4')
        )
    ),
    SystMethods2D = cms.VPSet(),
    src = cms.InputTag("flashggSelectedMuons")
)


process.flashggPrefireDiPhotons = cms.EDProducer("FlashggPrefireDiPhotonProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotonSystematics"),
    applyToCentral = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    isRelevant = cms.bool(True),
    jetFileName = cms.FileInPath('flashgg/Taggers/data/L1prefiring_jetpt_2017BtoF.root'),
    jetHistName = cms.untracked.string('L1prefiring_jetpt_2017BtoF'),
    photonFileName = cms.FileInPath('flashgg/Taggers/data/L1prefiring_photonpt_2017BtoF.root'),
    photonHistName = cms.untracked.string('L1prefiring_photonpt_2017BtoF')
)


process.flashggSigmaMoMpToMTag = cms.EDProducer("FlashggSigmaMpTTagPreCleanerProducer",
    BoundariesSigmaMoM = cms.vdouble(0.0, 0.00841, 0.0116, 0.0298),
    CompositeCandidateTags = cms.PSet(

    ),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggSystTagMerger = cms.EDProducer("TagMerger",
    src = cms.VInputTag("flashggTagSorter")
)


process.flashggTHQLeptonicTag = cms.EDProducer("FlashggTHQLeptonicTagProducer",
    Boundaries = cms.vdouble(
        -0.5, -0.45, -0.4, -0.35, -0.3, 
        -0.25, -0.2, -0.15, -0.1, -0.05, 
        0, 0.05, 0.1, 0.15, 0.2, 
        0.25, 0.3, 0.35, 0.4, 0.45
    ),
    DeltaRTrkElec = cms.double(0.35),
    DeltaRbjetfwdjet = cms.double(0.4),
    DeltaRtHchainfwdjet = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.3),
    MVAThreshold_tHqVsNonHiggsBkg = cms.double(0.05),
    MVAThreshold_tHqVsttHBDT = cms.double(-0.02),
    MVAThreshold_tHqVsttHDNN = cms.double(0.3),
    MVAweight_tHqVsNonHiggsBkg = cms.FileInPath('flashgg/Taggers/data/TMVA_THQLeptonicTag_tHq_Vs_NonPeakingBkg_BDT_17_v1.weights.xml'),
    MVAweight_tHqVsttHBDT = cms.FileInPath('flashgg/Taggers/data/TMVA_THQLeptonicTag_tHq_Vs_ttH_BDT.weights.xml'),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.7),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    deltaRLepPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.4),
    electronPtThreshold = cms.double(10.0),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(5),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    muonPtThreshold = cms.double(5.0),
    processId = cms.string('tth_125'),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    tthVstHDNN_global_mean = cms.vdouble(
        0.00231610401534, -2.88768351311e-05, 0.00520802242681, -0.00501471152529, 1.38837742805, 
        0.628725111485, 0.916627764702, 0.634564638138, 4.43414545059, 0.0621220208704, 
        0.0410859063268, 0.0488660633564, 0.00108957767952, 1.77521967888, 1.4959448576, 
        0.779049396515, 0.273214250803, 4.22647190094, 1.00189828873, 0.0696517378092, 
        -0.00085379119264, 2.45250582695, 3.95277500153
    ),
    tthVstHDNN_global_stddev = cms.vdouble(
        0.898130297661, 0.969476997852, 1.81390285492, 1.81198608875, 0.897601664066, 
        0.408543676138, 0.136938676238, 0.40609061718, 0.783773541451, 1.85750067234, 
        0.198488920927, 0.215587943792, 0.837704181671, 1.27375972271, 0.70099067688, 
        0.306284993887, 0.462327390909, 1.65539610386, 0.372171789408, 0.997571349144, 
        0.281717956066, 1.11738729477, 0.739496529102
    ),
    tthVstHDNN_object_mean = cms.vdouble(
        4.14551063204, 0.00858706897797, -0.00436269956806, 4.9521215665, -0.312457953369, 
        -0.54220945911, -0.470127030834, -0.257896148181, -1.5088640215
    ),
    tthVstHDNN_object_stddev = cms.vdouble(
        0.712723752294, 1.65500047514, 1.81099004661, 0.984552970296, 1.02325926961, 
        0.821026427504, 0.873895261504, 1.05918633335, 0.99607827402
    ),
    tthVstHDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_tH_v4.14_ttH_vs_tH_13Jan2020_weights.pb'),
    use_MVAs = cms.bool(True),
    use_tthVstHBDT = cms.bool(False),
    use_tthVstHDNN = cms.bool(True)
)


process.flashggTTHDiLeptonTag = cms.EDProducer("FlashggTTHDiLeptonTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    LeptonsZMassCut = cms.double(5),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.5),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.2),
    SystLabel = cms.string(''),
    UseCutBasedDiphoId = cms.bool(False),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(1.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(1.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    Boundaries = cms.vdouble(-1.0),
    Boundaries_pt1 = cms.vdouble(-1.0),
    Boundaries_pt2 = cms.vdouble(-1.0),
    Boundaries_pt3 = cms.vdouble(-1.0),
    Boundaries_pt4 = cms.vdouble(-1.0),
    DeltaRTrkEle = cms.double(0),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(''),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(''),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAMethod = cms.string('BDT'),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVATTHHMVAThreshold = cms.double(-1.0),
    MVAThreshold = cms.double(-1.0),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(''),
    ModifySystematicsWorkflow = cms.bool(False),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    STXSPtBoundaries_pt1 = cms.vdouble(0, 100000),
    STXSPtBoundaries_pt2 = cms.vdouble(100000),
    STXSPtBoundaries_pt3 = cms.vdouble(100001),
    STXSPtBoundaries_pt4 = cms.vdouble(100002),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    applyMETfilters = cms.bool(False),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsLooseNumberTTHHMVAThreshold = cms.int32(0),
    bjetsLooseNumberThreshold = cms.int32(0),
    bjetsNumberTTHHMVAThreshold = cms.int32(0),
    bjetsNumberThreshold = cms.int32(1),
    dRJetPhoLeadCut = cms.double(0.4),
    dRJetPhoSubleadCut = cms.double(0.4),
    debug = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(25.0),
    jetsNumberTTHHMVAThreshold = cms.int32(0),
    jetsNumberThreshold = cms.int32(5),
    leadPhoOverMassTTHHMVAThreshold = cms.double(0.33333),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadPhoPtThreshold = cms.double(20),
    leadPhoUseVariableThreshold = cms.bool(True),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    secondMaxBTagTTHHMVAThreshold = cms.double(-1000.0),
    subleadPhoOverMassThreshold = cms.double(0.25),
    subleadPhoPtThreshold = cms.double(20),
    subleadPhoUseVariableThreshold = cms.bool(True),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/Hadronic__v3.10_8Oct2019_RunII_MVA_Presel_impute_addDNNs_addTopTag__bdt.xml'),
    tthMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_tth_hadronic_2017Data_30vars_v0.weights.xml'),
    tthVsDiphoDNN_global_mean = cms.vdouble(
        0.00152201671153, 0.00302867335267, 0.00315805035643, 0.00688193039969, 0.771673560143, 
        0.363572388887, 0.886482715607, 0.522570729256, 3.56763720512, 0.0935503467917, 
        0.101326495409, 0.110947936773, 0.00207540788688, 0.750782728195, 2.48975729942, 
        0.5315117836, 0.243677765131, 4.18497562408
    ),
    tthVsDiphoDNN_global_stddev = cms.vdouble(
        1.20663011074, 1.26458907127, 1.81220948696, 1.81402361393, 0.438891172409, 
        0.185313045979, 0.175735637546, 0.46096983552, 0.750450849533, 1.88561069965, 
        0.301760524511, 0.314067721367, 1.01092660427, 0.628997027874, 0.774070262909, 
        0.300279557705, 0.263016819954, 1.42759954929
    ),
    tthVsDiphoDNN_object_mean = cms.vdouble(
        4.16153414153, 0.000754749699826, -0.00340882556517, 4.70285575282, 0.180382396024, 
        -0.0305975821698, 0.104652404672, 0.516345532117
    ),
    tthVsDiphoDNN_object_stddev = cms.vdouble(
        0.696971003362, 1.2104022278, 1.81317892109, 0.806361583215, 0.374734858911, 
        0.220256821012, 0.264271459217, 0.448252132411
    ),
    tthVsDiphoDNNfile = cms.FileInPath('flashgg/Taggers/data/Hadronic_ttHHadronic_ttH_vs_dipho_v3.10_8Oct2019_weights.pb'),
    tthVsttGGDNN_global_mean = cms.vdouble(
        0.00261678616516, 0.0019222504925, 0.00218238146044, 0.0070875287056, 0.934275448322, 
        0.43064776063, 0.873566091061, 0.469487607479, 3.85253500938, 0.0814090818167, 
        0.0738145112991, 0.0836782678962, 0.00236786599271, 1.01976275444, 2.11701178551, 
        0.816003441811, 0.468147218227, 5.4772644043
    ),
    tthVsttGGDNN_global_stddev = cms.vdouble(
        0.995167076588, 1.05544877052, 1.81155133247, 1.81459748745, 0.537029922009, 
        0.236725747585, 0.19902266562, 0.49345394969, 0.805905163288, 1.8517575264, 
        0.261468797922, 0.276904761791, 0.860031187534, 0.786265015602, 0.754843711853, 
        0.224930226803, 0.303750425577, 1.58055150509
    ),
    tthVsttGGDNN_object_mean = cms.vdouble(
        4.2339309661, -0.000104270757355, -0.00409245370178, 4.71751419818, 0.265346353649, 
        -0.0131178987147, 0.10522758513, 0.466619298927
    ),
    tthVsttGGDNN_object_stddev = cms.vdouble(
        0.662306564749, 1.13322545536, 1.81324589659, 0.766340161718, 0.412563815663, 
        0.202457777353, 0.239660326938, 0.44526342984
    ),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/Hadronic_ttHHadronic_ttH_vs_ttGG_v3.10_8Oct2019_weights.pb'),
    useTTHHadronicMVA = cms.bool(True)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    CutBasedDiphoId = cms.vdouble(
        0.4, 0.3, 0.0, -0.5, 2.0, 
        2.5
    ),
    DeltaRTrkEle = cms.double(0.35),
    DiLeptonJetThreshold = cms.double(0),
    DiLeptonMVAThreshold = cms.double(-999),
    DiLeptonbJetThreshold = cms.double(1),
    DiPhotonName = cms.string('flashggPreselectedDiPhotons'),
    DiPhotonSuffixes = cms.vstring(''),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    EleEtaCuts = cms.vdouble(1.4442, 1.566, 2.5),
    ElePhotonDrCut = cms.double(0.2),
    ElePhotonZMassCut = cms.double(5),
    ElePtCut = cms.double(10),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    JetsCollSize = cms.uint32(12),
    JetsName = cms.string('flashggUnpackedJets'),
    JetsSuffixes = cms.vstring(''),
    LeptonsZMassCut = cms.double(5),
    MVAResultName = cms.string('flashggDiPhotonMVA'),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.vdouble(-1.0),
    MVAThreshold_pt1 = cms.vdouble(-1.0),
    MVAThreshold_pt2 = cms.vdouble(-1.0),
    MVAThreshold_pt3 = cms.vdouble(-1.0),
    MVAThreshold_pt4 = cms.vdouble(-1.0),
    MVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVAClassification_BDT_training_v2.json.weights.xml'),
    MaxNLep = cms.int32(999),
    MetName = cms.string('flashggMets'),
    MetSuffixes = cms.vstring(''),
    MetTag = cms.InputTag("flashggMetSystematics"),
    MinNLep = cms.int32(1),
    ModifySystematicsWorkflow = cms.bool(False),
    MuonEtaCut = cms.double(2.4),
    MuonIsoCut = cms.double(0.25),
    MuonPhotonDrCut = cms.double(0.2),
    MuonPtCut = cms.double(5),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    STXSPtBoundaries_pt1 = cms.vdouble(0, 100000),
    STXSPtBoundaries_pt2 = cms.vdouble(100000),
    STXSPtBoundaries_pt3 = cms.vdouble(100001),
    STXSPtBoundaries_pt4 = cms.vdouble(100002),
    SplitDiLeptEv = cms.bool(True),
    SystLabel = cms.string(''),
    SystematicsJetsName = cms.string('flashggJetSystematics'),
    SystematicsMetName = cms.string('flashggMetSystematics'),
    UseCutBasedDiphoId = cms.bool(False),
    UseLargeMVAs = cms.bool(True),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    bDiscriminator = cms.vdouble(0.1522, 0.4941, 0.8001),
    bTag = cms.string('pfDeepCSV'),
    bjetsNumberThreshold = cms.double(0.0),
    debug = cms.bool(False),
    deltaRJetLeadPhoThreshold = cms.double(0.4),
    deltaRJetLepton = cms.double(0.4),
    deltaRJetSubLeadPhoThreshold = cms.double(0.4),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(5.0),
    jetPtThreshold = cms.double(25.0),
    jetsNumberThreshold = cms.double(0.0),
    leadPhoOverMassThreshold = cms.double(0.33),
    leadingJetPtThreshold = cms.double(0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    topTaggerXMLfile = cms.FileInPath('flashgg/Taggers/data/resTop_xgb_csv_order_deepCTag.xml'),
    tthMVA_RunII_weightfile = cms.FileInPath('flashgg/Taggers/data/Leptonic__v3.10_8Oct2019_RunII_MVA_Presel_addDNNs__bdt.xml'),
    tthVstHDNN_global_mean = cms.vdouble(
        0.00231610401534, -2.88768351311e-05, 0.00520802242681, -0.00501471152529, 1.38837742805, 
        0.628725111485, 0.916627764702, 0.634564638138, 4.43414545059, 0.0621220208704, 
        0.0410859063268, 0.0488660633564, 0.00108957767952, 1.77521967888, 1.4959448576, 
        0.779049396515, 0.273214250803, 4.22647190094, 1.00189828873, 0.0696517378092, 
        -0.00085379119264, 2.45250582695, 3.95277500153
    ),
    tthVstHDNN_global_stddev = cms.vdouble(
        0.898130297661, 0.969476997852, 1.81390285492, 1.81198608875, 0.897601664066, 
        0.408543676138, 0.136938676238, 0.40609061718, 0.783773541451, 1.85750067234, 
        0.198488920927, 0.215587943792, 0.837704181671, 1.27375972271, 0.70099067688, 
        0.306284993887, 0.462327390909, 1.65539610386, 0.372171789408, 0.997571349144, 
        0.281717956066, 1.11738729477, 0.739496529102
    ),
    tthVstHDNN_object_mean = cms.vdouble(
        4.14551063204, 0.00858706897797, -0.00436269956806, 4.9521215665, -0.312457953369, 
        -0.54220945911, -0.470127030834, -0.257896148181, -1.5088640215
    ),
    tthVstHDNN_object_stddev = cms.vdouble(
        0.712723752294, 1.65500047514, 1.81099004661, 0.984552970296, 1.02325926961, 
        0.821026427504, 0.873895261504, 1.05918633335, 0.99607827402
    ),
    tthVstHDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_tH_v4.14_ttH_vs_tH_13Jan2020_weights.pb'),
    tthVstHThreshold = cms.double(0.13699667),
    tthVsttGGDNN_global_mean = cms.vdouble(
        0.00309572508559, 0.00227243429981, 0.000709600397386, 0.00152105814777, 0.924737334251, 
        0.428190767765, 0.885528326035, 0.511256337166, 4.274061203, 0.0517073124647, 
        0.0782018229365, 0.0865454673767, 0.00297803385183, 1.00528120995, 2.12756466866, 
        0.77261865139, 0.388340443373, 4.03639984131, 1.00354862213
    ),
    tthVsttGGDNN_global_stddev = cms.vdouble(
        0.992114543915, 1.05300045013, 1.81294727325, 1.81304335594, 0.517700374126, 
        0.231130376458, 0.179511576891, 0.4742410779, 0.746088266373, 1.83815228939, 
        0.268488913774, 0.281167834997, 0.855819165707, 0.76338994503, 0.752846717834, 
        0.302179276943, 0.362395644188, 1.56759655476, 0.40263441205
    ),
    tthVsttGGDNN_object_mean = cms.vdouble(
        4.13886676016, 0.000450927530891, -0.00384525961969, 4.6234905801, -0.193124324951, 
        -0.444149826021, -0.359735467167, -0.100155836552, -1.48444198221
    ),
    tthVsttGGDNN_object_stddev = cms.vdouble(
        0.696225147959, 1.13738008768, 1.81333109505, 0.796197152337, 1.02378932804, 
        0.834939489354, 0.885342073026, 1.07410500152, 1.01446871028
    ),
    tthVsttGGDNNfile = cms.FileInPath('flashgg/Taggers/data/Leptonic_ttHLeptonic_ttH_vs_ttGG_v3.10_8Oct2019_weights.pb')
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    AddTruthInfo = cms.bool(True),
    BlindedSelectionPrintout = cms.bool(False),
    CreateNoTag = cms.bool(True),
    Debug = cms.untracked.bool(False),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HTXSTags = cms.PSet(
        ClassificationObj = cms.InputTag("rivetProducerHTXS","HiggsClassification"),
        njets = cms.InputTag("rivetProducerHTXS","njets"),
        pTH = cms.InputTag("rivetProducerHTXS","pTH"),
        pTV = cms.InputTag("rivetProducerHTXS","pTV"),
        stage0bin = cms.InputTag("rivetProducerHTXS","stage0bin"),
        stage1bin = cms.InputTag("rivetProducerHTXS","stage1bin")
    ),
    MassCutLower = cms.double(100),
    MassCutUpper = cms.double(180.0),
    MaxObjectWeightException = cms.double(10.0),
    MaxObjectWeightWarning = cms.double(2.5),
    MinObjectWeightException = cms.double(0.0),
    MinObjectWeightWarning = cms.double(0.4),
    NNLOPSWeightFile = cms.FileInPath('flashgg/Taggers/data/NNLOPS_reweight.root'),
    SetHTXSinfo = cms.bool(True),
    StoreOtherTagInfo = cms.bool(False),
    TagPriorityRanges = cms.VPSet(
        cms.PSet(
            TagName = cms.InputTag("flashggTTHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHHadronicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggUntagged")
        )
    ),
    applyNNLOPSweight = cms.bool(True),
    isGluonFusion = cms.bool(False)
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(12)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.vdouble(-1.0),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireScaledPtCuts = cms.bool(True),
    SystLabel = cms.string('')
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/sklearn_combined_moriond17_v4.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('Multi'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/dijetDataDrivenMerged.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.vdouble(0.553, 0.902, 0.957),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DropNonGoldData = cms.bool(False),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    GetQCDWeights = cms.bool(False),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    RequireVBFPreselection = cms.bool(True),
    SetArbitraryNonGoldMC = cms.bool(False),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    VBFPreselLeadPtMin = cms.double(40.0),
    VBFPreselPhoIDMVAMin = cms.double(-0.2),
    VBFPreselSubleadPtMin = cms.double(30.0)
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMets"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    dPhiDiphotonMetThreshold = cms.double(2.1),
    diphoMVAThreshold = cms.double(-1.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    metPtThreshold = cms.double(70),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useVertex0only = cms.bool(True)
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.double(0.5),
    dRJetToPhoLThreshold = cms.double(0.4),
    dRJetToPhoSThreshold = cms.double(0.4),
    dijetMassHighThreshold = cms.double(120.0),
    dijetMassLowThreshold = cms.double(60.0),
    diphoMVAThreshold = cms.double(0.6),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(40.0),
    jetsNumberThreshold = cms.double(2.0),
    leadPhoOverMassThreshold = cms.double(0.5),
    phoIdMVAThreshold = cms.double(-0.9),
    subleadPhoOverMassThreshold = cms.double(0.25)
)


process.flashggVHLeptonicLooseTag = cms.EDProducer("FlashggVHLeptonicLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.0),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.4),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(False)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(0.5),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggVHMetTag = cms.EDProducer("FlashggVHMetTagProducer",
    Boundaries = cms.vdouble(0.62015, 0.79),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    SystLabel = cms.string(''),
    VHMetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_VHMetTag_BDT_24Mar2020.weights.xml'),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    dPhiDiphotonMetThreshold = cms.double(2.0),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    diphoMVAThreshold = cms.double(-1.0),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    leadPhoOverMassThreshold = cms.double(0.333333),
    metPtThreshold = cms.double(50),
    phoIdMVAThreshold = cms.double(-0.7),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.2)
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronPtThreshold = cms.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    FLASHfilters = cms.InputTag("TriggerResults","","FLASHggMicroAOD"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    LongitudinalImpactParam = cms.double(0.2),
    METTag = cms.InputTag("flashggMets"),
    METThreshold = cms.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(0.187),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PATfilters = cms.InputTag("TriggerResults","","PAT"),
    PhoMVAThreshold = cms.double(-0.9),
    PuIDCutoffThreshold = cms.double(0.8),
    RECOfilters = cms.InputTag("TriggerResults","","RECO"),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.double(0.02),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetElectronThreshold = cms.double(0.5),
    deltaRJetMuonThreshold = cms.double(0.5),
    deltaRLowPtMuonPhoThreshold = cms.double(0.5),
    deltaRMuonPhoThreshold = cms.double(1),
    deltaRPhoElectronThreshold = cms.double(1.0),
    deltaRPhoLeadJet = cms.double(0.5),
    deltaRPhoSubLeadJet = cms.double(0.5),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    electronIsoThreshold = cms.double(0.15),
    electronNumOfHitsThreshold = cms.double(1),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(110.0),
    invMassLepLowThreshold = cms.double(70.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20.0),
    jetsNumberThreshold = cms.double(3.0),
    leadPhoOverMassThreshold = cms.double(0.375),
    leptonLowPtThreshold = cms.double(10.0),
    leptonPtThreshold = cms.double(20),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    nonTrigMVAEtaCuts = cms.vdouble(0.8, 1.479, 2.5),
    nonTrigMVAThresholds = cms.vdouble(0.913286, 0.805013, 0.358969),
    numberOfHighPtMuonsThreshold = cms.double(1.0),
    numberOfLowPtMuonsThreshold = cms.double(2.0),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.25),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False),
    useVertex0only = cms.bool(True)
)


process.flashggVHhadMVA = cms.EDProducer("FlashggVHhadMVAProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    DrJetPhoton = cms.double(0.4),
    JetIDLevel = cms.string('Tight2017'),
    MVAMethod = cms.string('BDTG'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.bool(True),
    UsePuJetID = cms.bool(False),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    merge3rdJet = cms.bool(False),
    pujidWpPtBin1 = cms.vdouble(0.69, -0.35, -0.26, -0.21),
    pujidWpPtBin2 = cms.vdouble(0.86, -0.1, -0.05, -0.01),
    rmsforwardCut = cms.double(3.0),
    thirdJetDRCut = cms.double(1.8),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/vhHadDataDrivenMerged.xml'),
    vhHadMVAweightfile = cms.FileInPath('flashgg/Taggers/data/STXSmodels/vhHadDataDrivenMerged.xml')
)


process.flashggWHLeptonicTag = cms.EDProducer("FlashggWHLeptonicTagProducer",
    Boundaries_0_75 = cms.vdouble(0.0927, 0.221, 0.354),
    Boundaries_GT75 = cms.vdouble(0.0726, 0.221, 0.365),
    DeltaRTrkElec = cms.double(0.4),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    METThreshold = cms.double(0.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-1.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.4),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    WHMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_WHLeptonicTag_BDT_16Dec2019.weights.xml'),
    deltaMassElectronZThreshold = cms.double(10.0),
    deltaRJetMuonThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.4),
    deltaRPhoElectronThreshold = cms.double(0.4),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(0.0),
    jetsNumberThreshold = cms.double(999),
    leadPhoOverMassThreshold = cms.double(0.0),
    leptonPtThreshold = cms.double(15),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False)
)


process.flashggZHLeptonicTag = cms.EDProducer("FlashggZHLeptonicTagProducer",
    Boundaries = cms.vdouble(0.17, 0.309),
    DeltaRTrkElec = cms.double(0.35),
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    ElectronTag = cms.InputTag("flashggElectronSystematics"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("flashggMetSystematics"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.double(-1.0),
    MuonTag = cms.InputTag("flashggMuonSystematics"),
    PhoMVAThreshold = cms.double(-0.9),
    SystLabel = cms.string(''),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    ZHMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_ZHLeptonicTag_BDT_02Feb2020.weights.xml'),
    deltaMassElectronZThreshold = cms.double(-1.0),
    deltaRJetLepThreshold = cms.double(0.4),
    deltaRMuonPhoThreshold = cms.double(0.2),
    deltaRPhoElectronThreshold = cms.double(0.2),
    deltaRPhoLeadJet = cms.double(0.4),
    deltaRPhoSubLeadJet = cms.double(0.4),
    electronEtaThresholds = cms.vdouble(1.4442, 1.566, 2.5),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    ),
    invMassLepHighThreshold = cms.double(120.0),
    invMassLepLowThreshold = cms.double(60.0),
    jetEtaThreshold = cms.double(2.4),
    jetPtThreshold = cms.double(20),
    leadPhoOverMassThreshold = cms.double(0.0),
    leptonPtThreshold = cms.double(10),
    muPFIsoSumRelThreshold = cms.double(0.25),
    muonEtaThreshold = cms.double(2.4),
    rhoTag = cms.InputTag("fixedGridRhoFastjetAll"),
    subleadPhoOverMassThreshold = cms.double(0.0),
    useElectronLooseID = cms.bool(True),
    useElectronMVARecipe = cms.bool(False)
)


process.flashggZPlusJetTag = cms.EDProducer("FlashggZPlusJetTagProducer",
    DiPhotonTag = cms.InputTag("flashggPreselectedDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    inputTagJets = cms.VInputTag(
        cms.InputTag("flashggJetSystematics0"), cms.InputTag("flashggJetSystematics1"), cms.InputTag("flashggJetSystematics2"), cms.InputTag("flashggJetSystematics3"), cms.InputTag("flashggJetSystematics4"), 
        cms.InputTag("flashggJetSystematics5"), cms.InputTag("flashggJetSystematics6"), cms.InputTag("flashggJetSystematics7"), cms.InputTag("flashggJetSystematics8"), cms.InputTag("flashggJetSystematics9"), 
        cms.InputTag("flashggJetSystematics10"), cms.InputTag("flashggJetSystematics11")
    )
)


process.flashggMetFilters = cms.EDFilter("flashggMetFilters",
    filtersInputTag = cms.InputTag("TriggerResults","","PAT"),
    requiredFilterNames = cms.untracked.vstring(
        'Flag_goodVertices', 
        'Flag_globalSuperTightHalo2016Filter', 
        'Flag_HBHENoiseFilter', 
        'Flag_HBHENoiseIsoFilter', 
        'Flag_EcalDeadCellTriggerPrimitiveFilter', 
        'Flag_BadPFMuonFilter'
    )
)


process.flashggPreselectedDiPhotons = cms.EDFilter("GenericDiPhotonCandidateSelector",
    categories = cms.VPSet(
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9>0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9>0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('100000.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    max = cms.string('100000.0')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEB && full5x5_r9<=0.85'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.015')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        ), 
        cms.PSet(
            cut = cms.string('isEE && full5x5_r9<=0.90'),
            selection = cms.VPSet(
                cms.PSet(
                    max = cms.string('4.0'),
                    rhocorr = cms.PSet(
                        bins = cms.vdouble(
                            0.0, 0.9, 1.5, 2, 2.2, 
                            3
                        ),
                        vals = cms.vdouble(0.16544, 0.16544, 0.13212, 0.13212, 0.13212),
                        var = cms.string('abs(superCluster.eta)')
                    )
                ), 
                cms.PSet(
                    max = cms.string('6.0')
                ), 
                cms.PSet(
                    max = cms.string('0.035')
                ), 
                cms.PSet(
                    min = cms.string('0.8')
                ), 
                cms.PSet(
                    min = cms.string('0.5')
                )
            )
        )
    ),
    cut = cms.string('    (leadingPhoton.full5x5_r9>0.8||leadingPhoton.egChargedHadronIso<20||leadingPhoton.egChargedHadronIso/leadingPhoton.pt<0.3) && (subLeadingPhoton.full5x5_r9>0.8||subLeadingPhoton.egChargedHadronIso<20||subLeadingPhoton.egChargedHadronIso/subLeadingPhoton.pt<0.3) && (leadingPhoton.hadronicOverEm < 0.08 && subLeadingPhoton.hadronicOverEm < 0.08) && (leadingPhoton.pt >35.0 && subLeadingPhoton.pt > 25.0) && (abs(leadingPhoton.superCluster.eta) < 2.5 && abs(subLeadingPhoton.superCluster.eta) < 2.5) && (abs(leadingPhoton.superCluster.eta) < 1.4442 || abs(leadingPhoton.superCluster.eta) > 1.566) && (abs(subLeadingPhoton.superCluster.eta) < 1.4442 || abs(subLeadingPhoton.superCluster.eta) > 1.566) && (leadPhotonId > -0.9 && subLeadPhotonId > -0.9)'),
    rho = cms.InputTag("fixedGridRhoAll"),
    src = cms.InputTag("flashggPrefireDiPhotons"),
    variables = cms.vstring(
        'pfPhoIso03', 
        'trkSumPtHollowConeDR03', 
        'full5x5_sigmaIetaIeta', 
        'full5x5_r9', 
        'passElectronVeto'
    )
)


process.hltHighLevel = cms.EDFilter("HLTHighLevel",
    HLTPaths = cms.vstring(),
    TriggerResultsTag = cms.InputTag("TriggerResults","","HLT"),
    andOr = cms.bool(True),
    eventSetupPathsKey = cms.string(''),
    throw = cms.bool(True)
)


process.tagsDumper = cms.EDAnalyzer("DiPhotonTagDumper",
    categories = cms.VPSet(
        cms.PSet(
            className = cms.string('UntaggedTag'),
            histograms = cms.VPSet(),
            label = cms.string(''),
            nAlphaSWeights = cms.int32(-1),
            nPdfWeights = cms.int32(-1),
            nScaleWeights = cms.int32(-1),
            splitPdfByStage0Bin = cms.bool(False),
            splitPdfByStage1Bin = cms.bool(False),
            subcats = cms.int32(0),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('CMS_hgg_mass'),
                    nbins = cms.untracked.int32(160),
                    vmax = cms.untracked.double(180.0),
                    vmin = cms.untracked.double(100.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('sigmaMoM_decorr')
                ), 
                cms.PSet(
                    expr = cms.string('(tagTruth().genPV().z-diPhoton().vtx().z)'),
                    name = cms.untracked.string('dZ'),
                    nbins = cms.untracked.int32(40),
                    vmax = cms.untracked.double(20.0),
                    vmin = cms.untracked.double(-20.0)
                ), 
                cms.PSet(
                    expr = cms.string('centralWeight'),
                    name = cms.untracked.string('centralObjectWeight'),
                    nbins = cms.untracked.int32(1),
                    vmax = cms.untracked.double(999999.0),
                    vmin = cms.untracked.double(-999999.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().nVert'),
                    name = cms.untracked.string('nVtx')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('diPhoMass')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().result'),
                    name = cms.untracked.string('diPhoMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt'),
                    name = cms.untracked.string('diPhoPt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt / diPhoton().mass'),
                    name = cms.untracked.string('diPhoPtoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().eta'),
                    name = cms.untracked.string('diPhoEta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().rapidity'),
                    name = cms.untracked.string('diPhoY')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().phi'),
                    name = cms.untracked.string('diPhoPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtxProbMVA'),
                    name = cms.untracked.string('diPhoVtxProbMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmarv'),
                    name = cms.untracked.string('diPhoSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('diPhoDecorrSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmawv'),
                    name = cms.untracked.string('diPhoSigmaWV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().CosPhi'),
                    name = cms.untracked.string('diPhoCosPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt'),
                    name = cms.untracked.string('pho1_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt'),
                    name = cms.untracked.string('pho2_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho1_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho2_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho1_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho2_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho1_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho2_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.et'),
                    name = cms.untracked.string('pho1_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.et'),
                    name = cms.untracked.string('pho2_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.energy'),
                    name = cms.untracked.string('pho1_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.energy'),
                    name = cms.untracked.string('pho2_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.eta'),
                    name = cms.untracked.string('pho1_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.eta'),
                    name = cms.untracked.string('pho2_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.phi'),
                    name = cms.untracked.string('pho1_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.phi'),
                    name = cms.untracked.string('pho2_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho1_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho2_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho1_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho2_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.isEB'),
                    name = cms.untracked.string('pho1_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.isEB'),
                    name = cms.untracked.string('pho2_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho1_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho2_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho1_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho2_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho1_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho2_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho1_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho2_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('max(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('maxPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('min(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('minPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho1_r9')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho2_r9')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasGenMatchType)? diPhoton().leadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho1_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasGenMatchType)? diPhoton().subLeadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho2_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? diPhoton().leadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho1_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? diPhoton().subLeadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho2_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho1_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho2_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtx().z'),
                    name = cms.untracked.string('vtxZ')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vertexIndex'),
                    name = cms.untracked.string('vtxI')
                ), 
                cms.PSet(
                    expr = cms.string('weight("totalWeight")'),
                    name = cms.untracked.string('weight_totalWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("lumiWeightCentral")'),
                    name = cms.untracked.string('weight_lumiWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("electronVetoSFCentral")'),
                    name = cms.untracked.string('weight_electronVetoSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PreselSFCentral")'),
                    name = cms.untracked.string('weight_PreselSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("TriggerWeightCentral")'),
                    name = cms.untracked.string('weight_TriggerWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("LooseMvaSFCentral")'),
                    name = cms.untracked.string('weight_LooseMvaSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PixelSeedWeightCentral")'),
                    name = cms.untracked.string('weight_PixelSeedWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVNvtxWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVNvtxWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonMediumIDWeightCentral")'),
                    name = cms.untracked.string('weight_MuonMediumIDWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonLooseRelISOWeightCentral")'),
                    name = cms.untracked.string('weight_MuonLooseRelISOWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonWeightCentral")'),
                    name = cms.untracked.string('weight_MuonWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("ElectronWeightCentral")'),
                    name = cms.untracked.string('weight_ElectronWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JECCentral")'),
                    name = cms.untracked.string('weight_JEC')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JERCentral")'),
                    name = cms.untracked.string('weight_JER')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagCutWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagCutWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagReshapeWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagReshapeWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverEShiftCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverEShift')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("puweightCentral")'),
                    name = cms.untracked.string('weight_puweight')
                )
            )
        ), 
        cms.PSet(
            className = cms.string('TTHHadronicTag'),
            histograms = cms.VPSet(),
            label = cms.string(''),
            nAlphaSWeights = cms.int32(-1),
            nPdfWeights = cms.int32(-1),
            nScaleWeights = cms.int32(-1),
            splitPdfByStage0Bin = cms.bool(False),
            splitPdfByStage1Bin = cms.bool(False),
            subcats = cms.int32(0),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('CMS_hgg_mass'),
                    nbins = cms.untracked.int32(160),
                    vmax = cms.untracked.double(180.0),
                    vmin = cms.untracked.double(100.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('sigmaMoM_decorr')
                ), 
                cms.PSet(
                    expr = cms.string('(tagTruth().genPV().z-diPhoton().vtx().z)'),
                    name = cms.untracked.string('dZ'),
                    nbins = cms.untracked.int32(40),
                    vmax = cms.untracked.double(20.0),
                    vmin = cms.untracked.double(-20.0)
                ), 
                cms.PSet(
                    expr = cms.string('centralWeight'),
                    name = cms.untracked.string('centralObjectWeight'),
                    nbins = cms.untracked.int32(1),
                    vmax = cms.untracked.double(999999.0),
                    vmin = cms.untracked.double(-999999.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().nVert'),
                    name = cms.untracked.string('nVtx')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('diPhoMass')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().result'),
                    name = cms.untracked.string('diPhoMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt'),
                    name = cms.untracked.string('diPhoPt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt / diPhoton().mass'),
                    name = cms.untracked.string('diPhoPtoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().eta'),
                    name = cms.untracked.string('diPhoEta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().rapidity'),
                    name = cms.untracked.string('diPhoY')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().phi'),
                    name = cms.untracked.string('diPhoPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtxProbMVA'),
                    name = cms.untracked.string('diPhoVtxProbMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmarv'),
                    name = cms.untracked.string('diPhoSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('diPhoDecorrSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmawv'),
                    name = cms.untracked.string('diPhoSigmaWV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().CosPhi'),
                    name = cms.untracked.string('diPhoCosPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt'),
                    name = cms.untracked.string('pho1_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt'),
                    name = cms.untracked.string('pho2_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho1_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho2_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho1_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho2_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho1_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho2_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.et'),
                    name = cms.untracked.string('pho1_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.et'),
                    name = cms.untracked.string('pho2_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.energy'),
                    name = cms.untracked.string('pho1_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.energy'),
                    name = cms.untracked.string('pho2_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.eta'),
                    name = cms.untracked.string('pho1_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.eta'),
                    name = cms.untracked.string('pho2_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.phi'),
                    name = cms.untracked.string('pho1_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.phi'),
                    name = cms.untracked.string('pho2_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho1_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho2_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho1_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho2_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.isEB'),
                    name = cms.untracked.string('pho1_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.isEB'),
                    name = cms.untracked.string('pho2_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho1_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho2_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho1_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho2_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho1_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho2_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho1_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho2_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('max(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('maxPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('min(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('minPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho1_r9')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho2_r9')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasGenMatchType)? diPhoton().leadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho1_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasGenMatchType)? diPhoton().subLeadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho2_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? diPhoton().leadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho1_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? diPhoton().subLeadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho2_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho1_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho2_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtx().z'),
                    name = cms.untracked.string('vtxZ')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vertexIndex'),
                    name = cms.untracked.string('vtxI')
                ), 
                cms.PSet(
                    expr = cms.string('weight("totalWeight")'),
                    name = cms.untracked.string('weight_totalWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("lumiWeightCentral")'),
                    name = cms.untracked.string('weight_lumiWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("electronVetoSFCentral")'),
                    name = cms.untracked.string('weight_electronVetoSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PreselSFCentral")'),
                    name = cms.untracked.string('weight_PreselSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("TriggerWeightCentral")'),
                    name = cms.untracked.string('weight_TriggerWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("LooseMvaSFCentral")'),
                    name = cms.untracked.string('weight_LooseMvaSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PixelSeedWeightCentral")'),
                    name = cms.untracked.string('weight_PixelSeedWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVNvtxWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVNvtxWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonMediumIDWeightCentral")'),
                    name = cms.untracked.string('weight_MuonMediumIDWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonLooseRelISOWeightCentral")'),
                    name = cms.untracked.string('weight_MuonLooseRelISOWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonWeightCentral")'),
                    name = cms.untracked.string('weight_MuonWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("ElectronWeightCentral")'),
                    name = cms.untracked.string('weight_ElectronWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JECCentral")'),
                    name = cms.untracked.string('weight_JEC')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JERCentral")'),
                    name = cms.untracked.string('weight_JER')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagCutWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagCutWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagReshapeWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagReshapeWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverEShiftCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverEShift')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("puweightCentral")'),
                    name = cms.untracked.string('weight_puweight')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoHelicity'),
                    name = cms.untracked.string('diPhoHelicity')
                ), 
                cms.PSet(
                    expr = cms.string('nJet'),
                    name = cms.untracked.string('nJets')
                ), 
                cms.PSet(
                    expr = cms.string('nBMedium'),
                    name = cms.untracked.string('nJetsBm')
                ), 
                cms.PSet(
                    expr = cms.string('nBLoose'),
                    name = cms.untracked.string('nJetsBl')
                ), 
                cms.PSet(
                    expr = cms.string('nBTight'),
                    name = cms.untracked.string('nJetsBt')
                ), 
                cms.PSet(
                    expr = cms.string('leadJetPt'),
                    name = cms.untracked.string('leadJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('subLeadJetPt'),
                    name = cms.untracked.string('subLeadJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('sumJetPt'),
                    name = cms.untracked.string('sumJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('maxBTagVal'),
                    name = cms.untracked.string('maxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('secondMaxBTagVal'),
                    name = cms.untracked.string('secondMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('thirdMaxBTagVal'),
                    name = cms.untracked.string('thirdMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('fourthMaxBTagVal'),
                    name = cms.untracked.string('fourthMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('maxBTagVal_noBB'),
                    name = cms.untracked.string('maxBTagVal_noBB')
                ), 
                cms.PSet(
                    expr = cms.string('secondMaxBTagVal_noBB'),
                    name = cms.untracked.string('secondMaxBTagVal_noBB')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetPt'),
                    name = cms.untracked.string('fwdjetLogPt')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetEta'),
                    name = cms.untracked.string('fwdjetAbsEta')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetPhi'),
                    name = cms.untracked.string('fwdjetAbsPhi')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).pt : -1'),
                    name = cms.untracked.string('jetPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).energy : -1'),
                    name = cms.untracked.string('jetE_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).eta : -6'),
                    name = cms.untracked.string('jetEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).phi : -6'),
                    name = cms.untracked.string('jetPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? min(deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi,  jetVector.at(0).eta,  jetVector.at(0).phi),deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(1).eta, jetVector.at(1).phi)) : -9'),
                    name = cms.untracked.string('mindRPhoLeadJet')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? max(deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi,  jetVector.at(0).eta,  jetVector.at(0).phi),deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(1).eta, jetVector.at(1).phi)) : -9'),
                    name = cms.untracked.string('maxdRPhoLeadJet')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(0).eta, jetVector.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(0).eta, jetVector.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>0)? jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>0)? jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>0)? jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).hadronFlavour : -9'),
                    name = cms.untracked.string('jetHFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>0)? jetVector.at(0).partonFlavour : -9'),
                    name = cms.untracked.string('jetPFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).pt : -1'),
                    name = cms.untracked.string('jetPt_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).energy : -1'),
                    name = cms.untracked.string('jetE_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).eta : -6'),
                    name = cms.untracked.string('jetEta_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).phi : -6'),
                    name = cms.untracked.string('jetPhi_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(1).eta, jetVector.at(1).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(1).eta, jetVector.at(1).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>1)? jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>1)? jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>1)? jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).hadronFlavour : -9'),
                    name = cms.untracked.string('jetHFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>1)? jetVector.at(1).partonFlavour : -9'),
                    name = cms.untracked.string('jetPFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? jetVector.at(2).pt : -1'),
                    name = cms.untracked.string('jetPt_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? jetVector.at(2).energy : -1'),
                    name = cms.untracked.string('jetE_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? jetVector.at(2).eta : -6'),
                    name = cms.untracked.string('jetEta_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? jetVector.at(2).phi : -6'),
                    name = cms.untracked.string('jetPhi_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(2).eta, jetVector.at(2).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>2)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(2).eta, jetVector.at(2).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>2)? jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>2)? jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>2)? jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? jetVector.at(3).pt : -1'),
                    name = cms.untracked.string('jetPt_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? jetVector.at(3).energy : -1'),
                    name = cms.untracked.string('jetE_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? jetVector.at(3).eta : -6'),
                    name = cms.untracked.string('jetEta_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? jetVector.at(3).phi : -6'),
                    name = cms.untracked.string('jetPhi_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(3).eta, jetVector.at(3).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>3)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(3).eta, jetVector.at(3).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>3)? jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>3)? jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>3)? jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(3).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? jetVector.at(4).pt : -1'),
                    name = cms.untracked.string('jetPt_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? jetVector.at(4).energy : -1'),
                    name = cms.untracked.string('jetE_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? jetVector.at(4).eta : -6'),
                    name = cms.untracked.string('jetEta_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? jetVector.at(4).phi : -6'),
                    name = cms.untracked.string('jetPhi_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(4).eta, jetVector.at(4).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>4)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(4).eta, jetVector.at(4).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>4)? jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>4)? jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>4)? jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(4).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? jetVector.at(5).pt : -1'),
                    name = cms.untracked.string('jetPt_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? jetVector.at(5).energy : -1'),
                    name = cms.untracked.string('jetE_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? jetVector.at(5).eta : -6'),
                    name = cms.untracked.string('jetEta_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? jetVector.at(5).phi : -6'),
                    name = cms.untracked.string('jetPhi_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(5).eta, jetVector.at(5).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>5)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(5).eta, jetVector.at(5).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>5)? jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>5)? jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>5)? jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(5).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>6)? jetVector.at(6).pt : -9'),
                    name = cms.untracked.string('jetPt_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>6)? jetVector.at(6).eta : -9'),
                    name = cms.untracked.string('jetEta_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>6)? jetVector.at(6).phi : -9'),
                    name = cms.untracked.string('jetPhi_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>6)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(6).eta, jetVector.at(6).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>6)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(6).eta, jetVector.at(6).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>6)? jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>6)? jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>6)? jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(6).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>7)? jetVector.at(7).pt : -9'),
                    name = cms.untracked.string('jetPt_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>7)? jetVector.at(7).eta : -9'),
                    name = cms.untracked.string('jetEta_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>7)? jetVector.at(7).phi : -9'),
                    name = cms.untracked.string('jetPhi_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>7)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jetVector.at(7).eta, jetVector.at(7).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jetVector.size>7)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jetVector.at(7).eta, jetVector.at(7).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>7)? jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>7)? jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jetVector.size>7)? jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jetVector.at(7).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_8')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPt'),
                    name = cms.untracked.string('MET')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPx'),
                    name = cms.untracked.string('METPx')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPy'),
                    name = cms.untracked.string('METPy')
                ), 
                cms.PSet(
                    expr = cms.string('met.phi'),
                    name = cms.untracked.string('METPhi')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).pt : -1'),
                    name = cms.untracked.string('bjetPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).energy : -1'),
                    name = cms.untracked.string('bjetE_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).eta : -6'),
                    name = cms.untracked.string('bjetEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).phi : -6'),
                    name = cms.untracked.string('bjetPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJetVector.size>0)? bJetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('bjetBtag_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>0)? bJetVector.at(0).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).pt : -1'),
                    name = cms.untracked.string('bjetPt_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).energy : -1'),
                    name = cms.untracked.string('bjetE_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).eta : -6'),
                    name = cms.untracked.string('bjetEta_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).phi : -6'),
                    name = cms.untracked.string('bjetPhi_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJetVector.size>1)? bJetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJetVector.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\')  : -1"),
                    name = cms.untracked.string('bjetBtag_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>1)? bJetVector.at(1).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).pt : -1'),
                    name = cms.untracked.string('bjetPt_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).energy : -1'),
                    name = cms.untracked.string('bjetE_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).eta : -6'),
                    name = cms.untracked.string('bjetEta_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).phi : -6'),
                    name = cms.untracked.string('bjetPhi_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJetVector.size>2)? bJetVector.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJetVector.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('bjetBtag_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJetVector.size>2)? bJetVector.at(2).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_3')
                ), 
                cms.PSet(
                    expr = cms.string('tthMvaRes'),
                    name = cms.untracked.string('tthMva')
                )
            )
        ), 
        cms.PSet(
            className = cms.string('TTHLeptonicTag'),
            histograms = cms.VPSet(),
            label = cms.string(''),
            nAlphaSWeights = cms.int32(-1),
            nPdfWeights = cms.int32(-1),
            nScaleWeights = cms.int32(-1),
            splitPdfByStage0Bin = cms.bool(False),
            splitPdfByStage1Bin = cms.bool(False),
            subcats = cms.int32(0),
            variables = cms.VPSet(
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('CMS_hgg_mass'),
                    nbins = cms.untracked.int32(160),
                    vmax = cms.untracked.double(180.0),
                    vmin = cms.untracked.double(100.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('sigmaMoM_decorr')
                ), 
                cms.PSet(
                    expr = cms.string('(tagTruth().genPV().z-diPhoton().vtx().z)'),
                    name = cms.untracked.string('dZ'),
                    nbins = cms.untracked.int32(40),
                    vmax = cms.untracked.double(20.0),
                    vmin = cms.untracked.double(-20.0)
                ), 
                cms.PSet(
                    expr = cms.string('centralWeight'),
                    name = cms.untracked.string('centralObjectWeight'),
                    nbins = cms.untracked.int32(1),
                    vmax = cms.untracked.double(999999.0),
                    vmin = cms.untracked.double(-999999.0)
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().nVert'),
                    name = cms.untracked.string('nVtx')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().mass'),
                    name = cms.untracked.string('diPhoMass')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().result'),
                    name = cms.untracked.string('diPhoMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt'),
                    name = cms.untracked.string('diPhoPt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().pt / diPhoton().mass'),
                    name = cms.untracked.string('diPhoPtoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().eta'),
                    name = cms.untracked.string('diPhoEta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().rapidity'),
                    name = cms.untracked.string('diPhoY')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().phi'),
                    name = cms.untracked.string('diPhoPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtxProbMVA'),
                    name = cms.untracked.string('diPhoVtxProbMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmarv'),
                    name = cms.untracked.string('diPhoSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().decorrSigmarv'),
                    name = cms.untracked.string('diPhoDecorrSigmaRV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().sigmawv'),
                    name = cms.untracked.string('diPhoSigmaWV')
                ), 
                cms.PSet(
                    expr = cms.string('diPhotonMVA().CosPhi'),
                    name = cms.untracked.string('diPhoCosPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt'),
                    name = cms.untracked.string('pho1_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt'),
                    name = cms.untracked.string('pho2_pt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho1_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hasPixelSeed'),
                    name = cms.untracked.string('pho2_hasPixelSeed')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho1_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigEOverE()'),
                    name = cms.untracked.string('pho2_sigmaEOverE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho1_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.pt / diPhoton().mass'),
                    name = cms.untracked.string('pho2_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.et'),
                    name = cms.untracked.string('pho1_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.et'),
                    name = cms.untracked.string('pho2_et')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.energy'),
                    name = cms.untracked.string('pho1_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.energy'),
                    name = cms.untracked.string('pho2_energy')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.eta'),
                    name = cms.untracked.string('pho1_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.eta'),
                    name = cms.untracked.string('pho2_eta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.phi'),
                    name = cms.untracked.string('pho1_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.phi'),
                    name = cms.untracked.string('pho2_phi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho1_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('pho2_sigmaIetaIeta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho1_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('pho2_hadronicOverEm')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.isEB'),
                    name = cms.untracked.string('pho1_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.isEB'),
                    name = cms.untracked.string('pho2_isEB')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho1_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.eta'),
                    name = cms.untracked.string('pho2_sceta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho1_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.superCluster.phi'),
                    name = cms.untracked.string('pho2_scphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho1_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('pho2_idmva')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho1_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton().passElectronVeto'),
                    name = cms.untracked.string('pho2_eleveto')
                ), 
                cms.PSet(
                    expr = cms.string('max(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('maxPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('min(diPhoton().leadingView.phoIdMvaWrtChosenVtx,diPhoton.subLeadingView.phoIdMvaWrtChosenVtx)'),
                    name = cms.untracked.string('minPhoID')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().leadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho1_r9')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().subLeadingPhoton.full5x5_r9'),
                    name = cms.untracked.string('pho2_r9')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasGenMatchType)? diPhoton().leadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho1_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasGenMatchType)? diPhoton().subLeadingPhoton.genMatchType : -999'),
                    name = cms.untracked.string('pho2_genmatch')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? diPhoton().leadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho1_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? diPhoton().subLeadingPhoton.matchedGenPhoton.pt : 0'),
                    name = cms.untracked.string('pho2_genmatchPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().leadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().leadingPhoton.phi - diPhoton().leadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho1_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('?(diPhoton().subLeadingPhoton.hasMatchedGenPhoton)? sqrt( pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2) + pow((diPhoton().subLeadingPhoton.phi - diPhoton().subLeadingPhoton.matchedGenPhoton.phi), 2)) : -999'),
                    name = cms.untracked.string('pho2_genmatchDeltaR')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vtx().z'),
                    name = cms.untracked.string('vtxZ')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton().vertexIndex'),
                    name = cms.untracked.string('vtxI')
                ), 
                cms.PSet(
                    expr = cms.string('weight("totalWeight")'),
                    name = cms.untracked.string('weight_totalWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("lumiWeightCentral")'),
                    name = cms.untracked.string('weight_lumiWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("electronVetoSFCentral")'),
                    name = cms.untracked.string('weight_electronVetoSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PreselSFCentral")'),
                    name = cms.untracked.string('weight_PreselSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("TriggerWeightCentral")'),
                    name = cms.untracked.string('weight_TriggerWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("LooseMvaSFCentral")'),
                    name = cms.untracked.string('weight_LooseMvaSF')
                ), 
                cms.PSet(
                    expr = cms.string('weight("PixelSeedWeightCentral")'),
                    name = cms.untracked.string('weight_PixelSeedWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("FracRVNvtxWeightCentral")'),
                    name = cms.untracked.string('weight_FracRVNvtxWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonMediumIDWeightCentral")'),
                    name = cms.untracked.string('weight_MuonMediumIDWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonLooseRelISOWeightCentral")'),
                    name = cms.untracked.string('weight_MuonLooseRelISOWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("MuonWeightCentral")'),
                    name = cms.untracked.string('weight_MuonWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("ElectronWeightCentral")'),
                    name = cms.untracked.string('weight_ElectronWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JECCentral")'),
                    name = cms.untracked.string('weight_JEC')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JERCentral")'),
                    name = cms.untracked.string('weight_JER')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagCutWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagCutWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("JetBTagReshapeWeightCentral")'),
                    name = cms.untracked.string('weight_JetBTagReshapeWeight')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverEShiftCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverEShift')
                ), 
                cms.PSet(
                    expr = cms.string('weight("SigmaEOverESmearingCentral")'),
                    name = cms.untracked.string('weight_SigmaEOverESmearing')
                ), 
                cms.PSet(
                    expr = cms.string('weight("puweightCentral")'),
                    name = cms.untracked.string('weight_puweight')
                ), 
                cms.PSet(
                    expr = cms.string('leadPrompt'),
                    name = cms.untracked.string('leadPrompt')
                ), 
                cms.PSet(
                    expr = cms.string('subleadPrompt'),
                    name = cms.untracked.string('subLeadPrompt')
                ), 
                cms.PSet(
                    expr = cms.string('leadMad'),
                    name = cms.untracked.string('leadMad')
                ), 
                cms.PSet(
                    expr = cms.string('subleadMad'),
                    name = cms.untracked.string('subLeadMad')
                ), 
                cms.PSet(
                    expr = cms.string('leadPythia'),
                    name = cms.untracked.string('leadPythia')
                ), 
                cms.PSet(
                    expr = cms.string('subleadPythia'),
                    name = cms.untracked.string('subLeadPythia')
                ), 
                cms.PSet(
                    expr = cms.string('leadMomID'),
                    name = cms.untracked.string('leadMomID')
                ), 
                cms.PSet(
                    expr = cms.string('subleadMomID'),
                    name = cms.untracked.string('subLeadMomID')
                ), 
                cms.PSet(
                    expr = cms.string('leadMomMomID'),
                    name = cms.untracked.string('leadMomMomID')
                ), 
                cms.PSet(
                    expr = cms.string('subleadMomMomID'),
                    name = cms.untracked.string('subLeadMomMomID')
                ), 
                cms.PSet(
                    expr = cms.string('leadPassFrix'),
                    name = cms.untracked.string('leadPassFrix')
                ), 
                cms.PSet(
                    expr = cms.string('subleadPassFrix'),
                    name = cms.untracked.string('subLeadPassFrix')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoHelicity'),
                    name = cms.untracked.string('diPhoHelicity')
                ), 
                cms.PSet(
                    expr = cms.string('electrons.size+muons.size'),
                    name = cms.untracked.string('nLep')
                ), 
                cms.PSet(
                    expr = cms.string('nLepTight'),
                    name = cms.untracked.string('nLepTight')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsPt.at(0) : -1'),
                    name = cms.untracked.string('lepPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsE.at(0) :  -1'),
                    name = cms.untracked.string('lepE_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsEta.at(0) : -6'),
                    name = cms.untracked.string('lepEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsPhi.at(0) : -6'),
                    name = cms.untracked.string('lepPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsCharge.at(0) : -6'),
                    name = cms.untracked.string('lepCharge_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=1)? leptonsType.at(0) : -1'),
                    name = cms.untracked.string('lepType_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsPt.at(1) : -1'),
                    name = cms.untracked.string('lepPt_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsE.at(1) :  -1'),
                    name = cms.untracked.string('lepE_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsEta.at(1) : -6'),
                    name = cms.untracked.string('lepEta_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsPhi.at(1) : -6'),
                    name = cms.untracked.string('lepPhi_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsCharge.at(1) : -6'),
                    name = cms.untracked.string('lepCharge_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size+muons.size>=2)? leptonsType.at(1) : -1'),
                    name = cms.untracked.string('lepType_2')
                ), 
                cms.PSet(
                    expr = cms.string('electrons.size'),
                    name = cms.untracked.string('nElec')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).pt : -1'),
                    name = cms.untracked.string('elecPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).eta : -6'),
                    name = cms.untracked.string('elecEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).phi : -6'),
                    name = cms.untracked.string('elecPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).charge : -6'),
                    name = cms.untracked.string('elecCh_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).superCluster.eta : -6'),
                    name = cms.untracked.string('elecScEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).superCluster.phi : -6'),
                    name = cms.untracked.string('elecScPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, electrons.at(0).eta, electrons.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadElec_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, electrons.at(0).eta, electrons.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadElec_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).passMVATightId : -9'),
                    name = cms.untracked.string('elecMVATightId_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).passMVAMediumId : -9'),
                    name = cms.untracked.string('elecMVAMediumId_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).passLooseId : -9'),
                    name = cms.untracked.string('elecLooseId_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).passMediumId : -9'),
                    name = cms.untracked.string('elecMediumId_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).passVetoId : -9'),
                    name = cms.untracked.string('elecVetoId_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(electrons.size>0)? electrons.at(0).fggMiniIsoSumRel : -9'),
                    name = cms.untracked.string('elecMiniIso_1')
                ), 
                cms.PSet(
                    expr = cms.string('muons.size'),
                    name = cms.untracked.string('nMuons')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? muons.at(0).pt : -1'),
                    name = cms.untracked.string('muPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? muons.at(0).eta : -6'),
                    name = cms.untracked.string('muEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? muons.at(0).phi : -6'),
                    name = cms.untracked.string('muPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? muons.at(0).charge : -6'),
                    name = cms.untracked.string('muCh_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, muons.at(0).eta, muons.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadMuon_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(muons.size>0)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, muons.at(0).eta, muons.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadMuon_1')
                ), 
                cms.PSet(
                    expr = cms.string('mvaRes'),
                    name = cms.untracked.string('tthMVA')
                ), 
                cms.PSet(
                    expr = cms.string('jets.size'),
                    name = cms.untracked.string('nJets')
                ), 
                cms.PSet(
                    expr = cms.string('nBMedium'),
                    name = cms.untracked.string('nJetsBm')
                ), 
                cms.PSet(
                    expr = cms.string('nBLoose'),
                    name = cms.untracked.string('nJetsBl')
                ), 
                cms.PSet(
                    expr = cms.string('nBTight'),
                    name = cms.untracked.string('nJetsBt')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).pt : 0.'),
                    name = cms.untracked.string('leadJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).pt : 0.'),
                    name = cms.untracked.string('subLeadJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('sumJetPt'),
                    name = cms.untracked.string('sumJetPt')
                ), 
                cms.PSet(
                    expr = cms.string('maxBTagVal'),
                    name = cms.untracked.string('maxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('secondMaxBTagVal'),
                    name = cms.untracked.string('secondMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('thirdMaxBTagVal'),
                    name = cms.untracked.string('thirdMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('fourthMaxBTagVal'),
                    name = cms.untracked.string('fourthMaxBTagVal')
                ), 
                cms.PSet(
                    expr = cms.string('maxBTagVal_noBB'),
                    name = cms.untracked.string('maxBTagVal_noBB')
                ), 
                cms.PSet(
                    expr = cms.string('secondMaxBTagVal_noBB'),
                    name = cms.untracked.string('secondMaxBTagVal_noBB')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetPt'),
                    name = cms.untracked.string('fwdjetLogPt')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetEta'),
                    name = cms.untracked.string('fwdjetAbsEta')
                ), 
                cms.PSet(
                    expr = cms.string('fwdjetPhi'),
                    name = cms.untracked.string('fwdjetAbsPhi')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).pt : -1'),
                    name = cms.untracked.string('jetPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).energy : -1'),
                    name = cms.untracked.string('jetE_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).eta : -6'),
                    name = cms.untracked.string('jetEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).phi : -6'),
                    name = cms.untracked.string('jetPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? min(deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi,  jets.at(0).eta,  jets.at(0).phi),deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(1).eta, jets.at(1).phi)) : -9'),
                    name = cms.untracked.string('mindRPhoLeadJet')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? max(deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi,  jets.at(0).eta,  jets.at(0).phi),deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(1).eta, jets.at(1).phi)) : -9'),
                    name = cms.untracked.string('maxdRPhoLeadJet')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(0).eta, jets.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(0).eta, jets.at(0).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>0)? jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>0)? jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>0)? jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).hadronFlavour : -9'),
                    name = cms.untracked.string('jetHFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>0)? jets.at(0).partonFlavour : -9'),
                    name = cms.untracked.string('jetPFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).pt : -1'),
                    name = cms.untracked.string('jetPt_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).energy : -1'),
                    name = cms.untracked.string('jetE_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).eta : -6'),
                    name = cms.untracked.string('jetEta_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).phi : -6'),
                    name = cms.untracked.string('jetPhi_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(1).eta, jets.at(1).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(1).eta, jets.at(1).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>1)? jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>1)? jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>1)? jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).hadronFlavour : -9'),
                    name = cms.untracked.string('jetHFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>1)? jets.at(1).partonFlavour : -9'),
                    name = cms.untracked.string('jetPFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? jets.at(2).pt : -1'),
                    name = cms.untracked.string('jetPt_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? jets.at(2).energy : -1'),
                    name = cms.untracked.string('jetE_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? jets.at(2).eta : -6'),
                    name = cms.untracked.string('jetEta_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? jets.at(2).phi : -6'),
                    name = cms.untracked.string('jetPhi_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(2).eta, jets.at(2).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>2)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(2).eta, jets.at(2).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>2)? jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>2)? jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>2)? jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? jets.at(3).pt : -1'),
                    name = cms.untracked.string('jetPt_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? jets.at(3).energy : -1'),
                    name = cms.untracked.string('jetE_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? jets.at(3).eta : -6'),
                    name = cms.untracked.string('jetEta_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? jets.at(3).phi : -6'),
                    name = cms.untracked.string('jetPhi_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(3).eta, jets.at(3).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>3)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(3).eta, jets.at(3).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>3)? jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>3)? jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_4')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>3)? jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(3).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_4')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? jets.at(4).pt : -1'),
                    name = cms.untracked.string('jetPt_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? jets.at(4).energy : -1'),
                    name = cms.untracked.string('jetE_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? jets.at(4).eta : -6'),
                    name = cms.untracked.string('jetEta_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? jets.at(4).phi : -6'),
                    name = cms.untracked.string('jetPhi_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(4).eta, jets.at(4).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>4)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(4).eta, jets.at(4).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>4)? jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>4)? jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_5')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>4)? jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(4).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_5')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? jets.at(5).pt : -1'),
                    name = cms.untracked.string('jetPt_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? jets.at(5).energy : -1'),
                    name = cms.untracked.string('jetE_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? jets.at(5).eta : -6'),
                    name = cms.untracked.string('jetEta_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? jets.at(5).phi : -6'),
                    name = cms.untracked.string('jetPhi_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>5)? jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>5)? jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_6')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>5)? jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(5).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(5).eta, jets.at(5).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>5)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(5).eta, jets.at(5).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_6')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? jets.at(6).pt : -1'),
                    name = cms.untracked.string('jetPt_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? jets.at(6).energy : -1'),
                    name = cms.untracked.string('jetE_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? jets.at(6).eta : -6'),
                    name = cms.untracked.string('jetEta_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? jets.at(6).phi : -6'),
                    name = cms.untracked.string('jetPhi_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>6)? jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>6)? jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_7')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>6)? jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(6).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(6).eta, jets.at(6).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>6)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(6).eta, jets.at(6).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_7')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? jets.at(7).pt : -1'),
                    name = cms.untracked.string('jetPt_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? jets.at(7).energy : -1'),
                    name = cms.untracked.string('jetE_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? jets.at(7).eta : -6'),
                    name = cms.untracked.string('jetEta_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? jets.at(7).phi : -6'),
                    name = cms.untracked.string('jetPhi_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>7)? jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('btag_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>7)? jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probudsg\') : -1"),
                    name = cms.untracked.string('cvsl_8')
                ), 
                cms.PSet(
                    expr = cms.string("?(jets.size>7)? jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probc\')+jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probb\')+jets.at(7).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('cvsb_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? deltaR(diPhoton().leadingPhoton.eta, diPhoton().leadingPhoton.phi, jets.at(7).eta, jets.at(7).phi) : -9'),
                    name = cms.untracked.string('dRPhoLeadJet_8')
                ), 
                cms.PSet(
                    expr = cms.string('?(jets.size>7)? deltaR(diPhoton().subLeadingPhoton.eta, diPhoton().subLeadingPhoton.phi, jets.at(7).eta, jets.at(7).phi) : -9'),
                    name = cms.untracked.string('dRPhoSubLeadJet_8')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPt'),
                    name = cms.untracked.string('MET')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPx'),
                    name = cms.untracked.string('METPx')
                ), 
                cms.PSet(
                    expr = cms.string('met.getCorPy'),
                    name = cms.untracked.string('METPy')
                ), 
                cms.PSet(
                    expr = cms.string('met.phi'),
                    name = cms.untracked.string('METPhi')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).pt : -1'),
                    name = cms.untracked.string('bjetPt_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).energy : -1'),
                    name = cms.untracked.string('bjetE_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).eta : -6'),
                    name = cms.untracked.string('bjetEta_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).phi : -6'),
                    name = cms.untracked.string('bjetPhi_1')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJets.size>0)? bJets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJets.at(0).bDiscriminator(\'pfDeepCSVJetTags:probbb\') : -1"),
                    name = cms.untracked.string('bjetBtag_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>0)? bJets.at(0).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_1')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).pt : -1'),
                    name = cms.untracked.string('bjetPt_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).energy : -1'),
                    name = cms.untracked.string('bjetE_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).eta : -6'),
                    name = cms.untracked.string('bjetEta_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).phi : -6'),
                    name = cms.untracked.string('bjetPhi_2')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJets.size>1)? bJets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJets.at(1).bDiscriminator(\'pfDeepCSVJetTags:probbb\')  : -1"),
                    name = cms.untracked.string('bjetBtag_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>1)? bJets.at(1).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_2')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).pt : -1'),
                    name = cms.untracked.string('bjetPt_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).energy : -1'),
                    name = cms.untracked.string('bjetE_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).eta : -6'),
                    name = cms.untracked.string('bjetEta_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).phi : -6'),
                    name = cms.untracked.string('bjetPhi_3')
                ), 
                cms.PSet(
                    expr = cms.string("?(bJets.size>2)? bJets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probb\')+ bJets.at(2).bDiscriminator(\'pfDeepCSVJetTags:probbb\')  : -1"),
                    name = cms.untracked.string('bjetBtag_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).hadronFlavour() : -9'),
                    name = cms.untracked.string('bjetHFlav_3')
                ), 
                cms.PSet(
                    expr = cms.string('?(bJets.size>2)? bJets.at(2).partonFlavour() : -9'),
                    name = cms.untracked.string('bjetPFlav_3')
                )
            )
        )
    ),
    className = cms.untracked.string('DiPhotonTagDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('hasSyst("") '),
            name = cms.untracked.string('')
        )),
        remap = cms.untracked.VPSet(
            cms.untracked.PSet(
                dst = cms.untracked.string('UntaggedTag'),
                src = cms.untracked.string('flashggUntaggedTag')
            ), 
            cms.untracked.PSet(
                dst = cms.untracked.string('TTHHadronicTag'),
                src = cms.untracked.string('flashggTTHHadronicTag')
            ), 
            cms.untracked.PSet(
                dst = cms.untracked.string('TTHLeptonicTag'),
                src = cms.untracked.string('flashggTTHLeptonicTag')
            )
        )
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(False),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(True),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        dataPu = cms.vdouble(
            6.245e-06, 2.63e-05, 4.92e-05, 9.084e-05, 9.854e-05, 
            0.0001426, 0.0001557, 0.0001656, 0.0002269, 0.0005395, 
            0.001076, 0.002034, 0.003219, 0.004616, 0.006528, 
            0.009201, 0.01283, 0.01707, 0.02125, 0.0251, 
            0.02847, 0.03118, 0.03325, 0.03486, 0.03626, 
            0.03758, 0.0387, 0.03937, 0.03946, 0.03892, 
            0.03782, 0.03627, 0.03435, 0.03211, 0.02967, 
            0.02719, 0.02482, 0.02264, 0.0207, 0.01907, 
            0.01784, 0.01709, 0.01685, 0.0171, 0.01771, 
            0.01849, 0.01916, 0.01945, 0.01911, 0.01804, 
            0.01627, 0.01399, 0.01147, 0.008976, 0.006728, 
            0.004848, 0.003375, 0.002281, 0.001504, 0.0009715, 
            0.0006178, 0.0003882, 0.0002419, 0.0001501, 9.294e-05, 
            5.768e-05, 3.598e-05, 2.263e-05, 1.437e-05, 9.233e-06, 
            5.996e-06, 3.933e-06, 2.601e-06, 1.731e-06, 1.157e-06, 
            7.743e-07, 5.184e-07, 3.466e-07, 2.311e-07, 1.535e-07, 
            1.015e-07, 6.676e-08, 4.365e-08, 2.836e-08, 1.829e-08, 
            1.171e-08, 7.437e-09, 4.685e-09, 2.926e-09, 1.812e-09, 
            1.111e-09, 6.754e-10, 4.066e-10, 2.424e-10, 1.431e-10, 
            8.363e-11, 4.839e-11, 2.771e-11, 1.571e-11, 8.814e-12
        ),
        extraFloats = cms.PSet(

        ),
        mcPu = cms.vdouble(
            0.0238775, 0.000874622, 0.00124831, 0.00153105, 0.00147725, 
            0.00141303, 0.00126538, 0.00115647, 0.00218504, 0.00171699, 
            0.00229043, 0.00333221, 0.0048993, 0.00663561, 0.00897475, 
            0.011538, 0.0141801, 0.0169121, 0.0192551, 0.0214591, 
            0.0231318, 0.0243014, 0.0251415, 0.0257144, 0.0264036, 
            0.0272533, 0.0279565, 0.028333, 0.0282152, 0.0281867, 
            0.0280371, 0.0282786, 0.0282462, 0.0279432, 0.0276964, 
            0.0270571, 0.0259487, 0.0247456, 0.0239501, 0.0231562, 
            0.0214979, 0.0197288, 0.0179504, 0.0162761, 0.0148308, 
            0.0136544, 0.0125744, 0.0122772, 0.0120571, 0.0118004, 
            0.0120413, 0.0120674, 0.0120442, 0.0120637, 0.0119306, 
            0.0121372, 0.0119726, 0.0117524, 0.0113325, 0.0105063, 
            0.00941031, 0.00811139, 0.00662999, 0.00554745, 0.00434088, 
            0.00362642, 0.00318208, 0.00228125, 0.00171769, 0.00117662, 
            0.000909775, 0.000725548, 0.000478647, 0.000399337, 0.000367371, 
            0.000333013, 0.000231815, 0.000234494, 0.000226693, 0.000381801, 
            0.000485566, 0.000441125, 0.000234348, 0.000323903, 0.000166324, 
            0.000254228, 0.000143739, 0.000292395, 0.000254309, 0.000174261, 
            8.52316e-05, 5.89512e-05, 1.01815e-05, 3.82778e-05, 2.63483e-05, 
            0.000187418, 1.01005e-05, 2.22584e-05, 3.01709e-05, 3.36291e-05
        ),
        puBins = cms.vdouble(
            0.0, 1.0, 2.0, 3.0, 4.0, 
            5.0, 6.0, 7.0, 8.0, 9.0, 
            10.0, 11.0, 12.0, 13.0, 14.0, 
            15.0, 16.0, 17.0, 18.0, 19.0, 
            20.0, 21.0, 22.0, 23.0, 24.0, 
            25.0, 26.0, 27.0, 28.0, 29.0, 
            30.0, 31.0, 32.0, 33.0, 34.0, 
            35.0, 36.0, 37.0, 38.0, 39.0, 
            40.0, 41.0, 42.0, 43.0, 44.0, 
            45.0, 46.0, 47.0, 48.0, 49.0, 
            50.0, 51.0, 52.0, 53.0, 54.0, 
            55.0, 56.0, 57.0, 58.0, 59.0, 
            60.0, 61.0, 62.0, 63.0, 64.0, 
            65.0, 66.0, 67.0, 68.0, 69.0, 
            70.0, 71.0, 72.0, 73.0, 74.0, 
            75.0, 76.0, 77.0, 78.0, 79.0, 
            80.0, 81.0, 82.0, 83.0, 84.0, 
            85.0, 86.0, 87.0, 88.0, 89.0, 
            90.0, 91.0, 92.0, 93.0, 94.0, 
            95.0, 96.0, 97.0, 98.0, 99.0
        ),
        puInfo = cms.InputTag("slimmedAddPileupInfo"),
        puReWeight = cms.bool(True),
        rho = cms.InputTag("fixedGridRhoAll"),
        useTruePu = cms.bool(True),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(1000.0),
    lumiWeight = cms.double(4.89377454824e-05),
    maxCandPerEvent = cms.int32(-1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('tth_125'),
    processIndex = cms.int32(-125300),
    quietRooFit = cms.untracked.bool(True),
    splitPdfByStage0Bin = cms.untracked.bool(False),
    splitPdfByStage1Bin = cms.untracked.bool(False),
    src = cms.InputTag("flashggSystTagMerger"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring(
        'FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'
    ),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1000)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring(
        'warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'
    ),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.RandomNumberGeneratorService = cms.Service("RandomNumberGeneratorService",
    flashggDifferentialPhoIdInputsCorrection = cms.PSet(
        initialSeed = cms.untracked.uint32(90)
    )
)


process.TFileService = cms.Service("TFileService",
    fileName = cms.string('tth_output/output_ttHJetToGG_M125_13TeV_amcatnloFXFX_madspin_pythia8_numEvent1000.root')
)


process.CSCGeometryESModule = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.CaloGeometryBuilder = cms.ESProducer("CaloGeometryBuilder",
    SelectedCalos = cms.vstring(
        'HCAL', 
        'ZDC', 
        'CASTOR', 
        'EcalBarrel', 
        'EcalEndcap', 
        'EcalPreshower', 
        'TOWER'
    )
)


process.CaloTopologyBuilder = cms.ESProducer("CaloTopologyBuilder")


process.CaloTowerGeometryFromDBEP = cms.ESProducer("CaloTowerGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.CaloTowerTopologyEP = cms.ESProducer("CaloTowerTopologyEP")


process.CastorDbProducer = cms.ESProducer("CastorDbProducer",
    appendToDataLabel = cms.string('')
)


process.CastorGeometryFromDBEP = cms.ESProducer("CastorGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.DTGeometryESModule = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.EcalBarrelGeometryFromDBEP = cms.ESProducer("EcalBarrelGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalElectronicsMappingBuilder = cms.ESProducer("EcalElectronicsMappingBuilder")


process.EcalEndcapGeometryFromDBEP = cms.ESProducer("EcalEndcapGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalLaserCorrectionService = cms.ESProducer("EcalLaserCorrectionService")


process.EcalPreshowerGeometryFromDBEP = cms.ESProducer("EcalPreshowerGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalTrigTowerConstituentsMapBuilder = cms.ESProducer("EcalTrigTowerConstituentsMapBuilder",
    MapFile = cms.untracked.string('Geometry/EcalMapping/data/EndCap_TTMap.txt')
)


process.GlobalTrackingGeometryESProducer = cms.ESProducer("GlobalTrackingGeometryESProducer")


process.HcalAlignmentEP = cms.ESProducer("HcalAlignmentEP")


process.HcalGeometryFromDBEP = cms.ESProducer("HcalGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.MuonDetLayerGeometryESProducer = cms.ESProducer("MuonDetLayerGeometryESProducer")


process.MuonNumberingInitialization = cms.ESProducer("MuonNumberingInitialization")


process.ParabolicParametrizedMagneticFieldProducer = cms.ESProducer("AutoParametrizedMagneticFieldProducer",
    label = cms.untracked.string('ParabolicMf'),
    valueOverride = cms.int32(-1),
    version = cms.string('Parabolic')
)


process.RPCGeometryESModule = cms.ESProducer("RPCGeometryESModule",
    compatibiltyWith11 = cms.untracked.bool(True),
    useDDD = cms.untracked.bool(False)
)


process.SiStripRecHitMatcherESProducer = cms.ESProducer("SiStripRecHitMatcherESProducer",
    ComponentName = cms.string('StandardMatcher'),
    NSigmaInside = cms.double(3.0),
    PreFilter = cms.bool(False)
)


process.StripCPEfromTrackAngleESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('StripCPEfromTrackAngle'),
    ComponentType = cms.string('StripCPEfromTrackAngle'),
    parameters = cms.PSet(
        mLC_P0 = cms.double(-0.326),
        mLC_P1 = cms.double(0.618),
        mLC_P2 = cms.double(0.3),
        mTEC_P0 = cms.double(-1.885),
        mTEC_P1 = cms.double(0.471),
        mTIB_P0 = cms.double(-0.742),
        mTIB_P1 = cms.double(0.202),
        mTID_P0 = cms.double(-1.427),
        mTID_P1 = cms.double(0.433),
        mTOB_P0 = cms.double(-1.026),
        mTOB_P1 = cms.double(0.253),
        maxChgOneMIP = cms.double(6000.0),
        useLegacyError = cms.bool(False)
    )
)


process.TrackerRecoGeometryESProducer = cms.ESProducer("TrackerRecoGeometryESProducer")


process.VolumeBasedMagneticFieldESProducer = cms.ESProducer("VolumeBasedMagneticFieldESProducerFromDB",
    debugBuilder = cms.untracked.bool(False),
    label = cms.untracked.string(''),
    valueOverride = cms.int32(-1)
)


process.XMLFromDBSource = cms.ESProducer("XMLIdealGeometryESProducer",
    label = cms.string('Extended'),
    rootDDName = cms.string('cms:OCMS')
)


process.ZdcGeometryFromDBEP = cms.ESProducer("ZdcGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.fakeForIdealAlignment = cms.ESProducer("FakeAlignmentProducer",
    appendToDataLabel = cms.string('fakeForIdeal')
)


process.hcalDDDRecConstants = cms.ESProducer("HcalDDDRecConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalDDDSimConstants = cms.ESProducer("HcalDDDSimConstantsESModule",
    appendToDataLabel = cms.string('')
)


process.hcalTopologyIdeal = cms.ESProducer("HcalTopologyIdealEP",
    Exclude = cms.untracked.string(''),
    MergePosition = cms.untracked.bool(False),
    appendToDataLabel = cms.string('')
)


process.hcal_db_producer = cms.ESProducer("HcalDbProducer",
    dump = cms.untracked.vstring(''),
    file = cms.untracked.string('')
)


process.idealForDigiCSCGeometry = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.idealForDigiDTGeometry = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.idealForDigiTrackerGeometry = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.siPixelQualityESProducer = cms.ESProducer("SiPixelQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiPixelQualityFromDbRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiPixelDetVOffRcd'),
            tag = cms.string('')
        )
    ),
    siPixelQualityLabel = cms.string('')
)


process.siStripBackPlaneCorrectionDepESProducer = cms.ESProducer("SiStripBackPlaneCorrectionDepESProducer",
    BackPlaneCorrectionDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    BackPlaneCorrectionPeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    )
)


process.siStripGainESProducer = cms.ESProducer("SiStripGainESProducer",
    APVGain = cms.VPSet(
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGainRcd')
        ), 
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGain2Rcd')
        )
    ),
    AutomaticNormalization = cms.bool(False),
    appendToDataLabel = cms.string(''),
    printDebug = cms.untracked.bool(False)
)


process.siStripLorentzAngleDepESProducer = cms.ESProducer("SiStripLorentzAngleDepESProducer",
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    ),
    LorentzAngleDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripLorentzAngleRcd')
    ),
    LorentzAnglePeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripLorentzAngleRcd')
    )
)


process.siStripQualityESProducer = cms.ESProducer("SiStripQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(
        cms.PSet(
            record = cms.string('SiStripDetVOffRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripDetCablingRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('RunInfoRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadChannelRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadFiberRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadModuleRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadStripRcd'),
            tag = cms.string('')
        )
    ),
    PrintDebugOutput = cms.bool(False),
    ReduceGranularity = cms.bool(False),
    ThresholdForReducedGranularity = cms.double(0.3),
    UseEmptyRunInfo = cms.bool(False),
    appendToDataLabel = cms.string('')
)


process.sistripconn = cms.ESProducer("SiStripConnectivity")


process.stripCPEESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('stripCPE'),
    ComponentType = cms.string('SimpleStripCPE'),
    parameters = cms.PSet(

    )
)


process.trackerGeometryDB = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.trackerNumberingGeometryDB = cms.ESProducer("TrackerGeometricDetESModule",
    appendToDataLabel = cms.string(''),
    fromDDD = cms.bool(False)
)


process.trackerTopology = cms.ESProducer("TrackerTopologyEP",
    appendToDataLabel = cms.string('')
)


process.GlobalTag = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        messageLevel = cms.untracked.int32(0),
        security = cms.untracked.string('')
    ),
    DumpStat = cms.untracked.bool(False),
    ReconnectEachRun = cms.untracked.bool(False),
    RefreshAlways = cms.untracked.bool(False),
    RefreshEachRun = cms.untracked.bool(False),
    RefreshOpenIOVs = cms.untracked.bool(False),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    globaltag = cms.string('94X_mc2017_realistic_v17'),
    pfnPostfix = cms.untracked.string(''),
    pfnPrefix = cms.untracked.string(''),
    snapshotTime = cms.string(''),
    toGet = cms.VPSet()
)


process.HcalTimeSlewEP = cms.ESSource("HcalTimeSlewEP",
    appendToDataLabel = cms.string('HBHE'),
    timeSlewParametersM2 = cms.VPSet(
        cms.PSet(
            slope = cms.double(-3.178648),
            tmax = cms.double(16.0),
            tzero = cms.double(23.960177)
        ), 
        cms.PSet(
            slope = cms.double(-1.5610227),
            tmax = cms.double(10.0),
            tzero = cms.double(11.977461)
        ), 
        cms.PSet(
            slope = cms.double(-1.075824),
            tmax = cms.double(6.25),
            tzero = cms.double(9.109694)
        )
    ),
    timeSlewParametersM3 = cms.VPSet(
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(15.5),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-3.2),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(32.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        ), 
        cms.PSet(
            cap = cms.double(6.0),
            tspar0 = cms.double(12.2999),
            tspar0_siPM = cms.double(0.0),
            tspar1 = cms.double(-2.19142),
            tspar1_siPM = cms.double(0.0),
            tspar2 = cms.double(0.0),
            tspar2_siPM = cms.double(0.0)
        )
    )
)


process.eegeom = cms.ESSource("EmptyESSource",
    firstValid = cms.vuint32(1),
    iovIsRunNotTime = cms.bool(True),
    recordName = cms.string('EcalMappingRcd')
)


process.es_hardcode = cms.ESSource("HcalHardcodeCalibrations",
    GainWidthsForTrigPrims = cms.bool(False),
    HBRecalibration = cms.bool(False),
    HBmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHB.txt'),
    HBreCalibCutoff = cms.double(20.0),
    HERecalibration = cms.bool(False),
    HEmeanenergies = cms.FileInPath('CalibCalorimetry/HcalPlugins/data/meanenergiesHE.txt'),
    HEreCalibCutoff = cms.double(20.0),
    HFRecalParameterBlock = cms.PSet(
        HFdepthOneParameterA = cms.vdouble(
            0.004123, 0.00602, 0.008201, 0.010489, 0.013379, 
            0.016997, 0.021464, 0.027371, 0.034195, 0.044807, 
            0.058939, 0.125497
        ),
        HFdepthOneParameterB = cms.vdouble(
            -4e-06, -2e-06, 0.0, 4e-06, 1.5e-05, 
            2.6e-05, 6.3e-05, 8.4e-05, 0.00016, 0.000107, 
            0.000425, 0.000209
        ),
        HFdepthTwoParameterA = cms.vdouble(
            0.002861, 0.004168, 0.0064, 0.008388, 0.011601, 
            0.014425, 0.018633, 0.023232, 0.028274, 0.035447, 
            0.051579, 0.086593
        ),
        HFdepthTwoParameterB = cms.vdouble(
            -2e-06, -0.0, -7e-06, -6e-06, -2e-06, 
            1e-06, 1.9e-05, 3.1e-05, 6.7e-05, 1.2e-05, 
            0.000157, -3e-06
        )
    ),
    HFRecalibration = cms.bool(False),
    SiPMCharacteristics = cms.VPSet(
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(36000)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(2500)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.17),
            nonlin1 = cms.double(1.00985),
            nonlin2 = cms.double(7.84089e-06),
            nonlin3 = cms.double(2.86282e-10),
            pixels = cms.int32(27370)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.196),
            nonlin1 = cms.double(1.00546),
            nonlin2 = cms.double(6.40239e-06),
            nonlin3 = cms.double(1.27011e-10),
            pixels = cms.int32(38018)
        ), 
        cms.PSet(
            crosstalk = cms.double(0.0),
            nonlin1 = cms.double(1.0),
            nonlin2 = cms.double(0.0),
            nonlin3 = cms.double(0.0),
            pixels = cms.int32(0)
        )
    ),
    hb = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.19),
        gainWidth = cms.vdouble(0.0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.285),
        pedestalWidth = cms.double(0.809),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.49, 1.8, 7.2, 37.9),
        qieSlope = cms.vdouble(0.912, 0.917, 0.922, 0.923),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(8)
    ),
    hbUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(150),
            intlumiToNeutrons = cms.double(367000000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(-5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    he = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.23),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(125),
        pedestal = cms.double(3.163),
        pedestalWidth = cms.double(0.9698),
        photoelectronsToAnalog = cms.double(0.3305),
        qieOffset = cms.vdouble(-0.38, 2.0, 7.6, 39.6),
        qieSlope = cms.vdouble(0.912, 0.916, 0.92, 0.922),
        qieType = cms.int32(0),
        recoShape = cms.int32(105),
        zsThreshold = cms.int32(9)
    ),
    heUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.01, 0.015),
        doRadiationDamage = cms.bool(True),
        gain = cms.vdouble(0.0006252),
        gainWidth = cms.vdouble(0),
        mcShape = cms.int32(206),
        pedestal = cms.double(17.3),
        pedestalWidth = cms.double(1.5),
        photoelectronsToAnalog = cms.double(40.0),
        qieOffset = cms.vdouble(0.0, 0.0, 0.0, 0.0),
        qieSlope = cms.vdouble(0.05376, 0.05376, 0.05376, 0.05376),
        qieType = cms.int32(2),
        radiationDamage = cms.PSet(
            depVsNeutrons = cms.vdouble(5.543e-10, 8.012e-10),
            depVsTemp = cms.double(0.0631),
            intlumiOffset = cms.double(75),
            intlumiToNeutrons = cms.double(29200000.0),
            temperatureBase = cms.double(20),
            temperatureNew = cms.double(5)
        ),
        recoShape = cms.int32(206),
        zsThreshold = cms.int32(16)
    ),
    hf = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(9.354),
        pedestalWidth = cms.double(2.516),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(-0.87, 1.4, 7.8, -29.6),
        qieSlope = cms.vdouble(0.359, 0.358, 0.36, 0.367),
        qieType = cms.int32(0),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    hfUpgrade = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.14, 0.135),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(301),
        pedestal = cms.double(13.33),
        pedestalWidth = cms.double(3.33),
        photoelectronsToAnalog = cms.double(0.0),
        qieOffset = cms.vdouble(0.0697, -0.7405, 12.38, -671.9),
        qieSlope = cms.vdouble(0.297, 0.298, 0.298, 0.313),
        qieType = cms.int32(1),
        recoShape = cms.int32(301),
        zsThreshold = cms.int32(-9999)
    ),
    ho = cms.PSet(
        darkCurrent = cms.vdouble(0.0),
        doRadiationDamage = cms.bool(False),
        gain = cms.vdouble(0.006, 0.0087),
        gainWidth = cms.vdouble(0.0, 0.0),
        mcShape = cms.int32(201),
        pedestal = cms.double(12.06),
        pedestalWidth = cms.double(0.6285),
        photoelectronsToAnalog = cms.double(4.0),
        qieOffset = cms.vdouble(-0.44, 1.4, 7.1, 38.5),
        qieSlope = cms.vdouble(0.907, 0.915, 0.92, 0.921),
        qieType = cms.int32(0),
        recoShape = cms.int32(201),
        zsThreshold = cms.int32(24)
    ),
    iLumi = cms.double(-1.0),
    killHE = cms.bool(False),
    testHEPlan1 = cms.bool(False),
    testHFQIE10 = cms.bool(False),
    toGet = cms.untracked.vstring('GainWidths'),
    useHBUpgrade = cms.bool(False),
    useHEUpgrade = cms.bool(False),
    useHFUpgrade = cms.bool(False),
    useHOUpgrade = cms.bool(True),
    useIeta18depth1 = cms.bool(True),
    useLayer0Weight = cms.bool(False)
)


process.jec = cms.ESSource("PoolDBESSource",
    DBParameters = cms.PSet(
        messageLevel = cms.untracked.int32(0)
    ),
    connect = cms.string('frontier://FrontierProd/CMS_CONDITIONS'),
    timetype = cms.string('runnumber'),
    toGet = cms.VPSet(cms.PSet(
        label = cms.untracked.string('AK4PFchs'),
        record = cms.string('JetCorrectionsRecord'),
        tag = cms.string('JetCorrectorParametersCollection_Fall17_17Nov2017_V32_102X_MC_AK4PFchs')
    ))
)


process.prefer("es_hardcode")

process.prefer("jec")

process.ak4CaloL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL2L3ResidualCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL2L3ResidualCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4CaloL1L2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1L2L3ResidualCorrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFPuppiL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3ResidualCorrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4L1JPTOffsetCorrectorTask = cms.Task(process.ak4CaloL1OffsetCorrector, process.ak4L1JPTOffsetCorrector)


process.ak4JPTL1L2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1L2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFL1L2L3CorrectorTask = cms.Task(process.ak4PFL1L2L3Corrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1L2L3CorrectorTask = cms.Task(process.ak4CaloL1L2L3Corrector, process.ak4CaloL1OffsetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3ResidualCorrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4CaloL2L3L6CorrectorTask = cms.Task(process.ak4CaloL2L3L6Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4L1JPTFastjetCorrectorTask = cms.Task(process.ak4CaloL1FastjetCorrector, process.ak4L1JPTFastjetCorrector)


process.ak4PFL1FastL2L3CorrectorTask = cms.Task(process.ak4PFL1FastL2L3Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4TrackL2L3CorrectorTask = cms.Task(process.ak4TrackL2L3Corrector, process.ak4TrackL2RelativeCorrector, process.ak4TrackL3AbsoluteCorrector)


process.ak4PFL2L3L6CorrectorTask = cms.Task(process.ak4PFL2L3L6Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4JPTL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4JPTL2L3CorrectorTask = cms.Task(process.ak4JPTL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1FastL2L3Corrector, process.ak4PFPuppiL1FastjetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFPuppiL1L2L3CorrectorTask = cms.Task(process.ak4PFPuppiL1L2L3Corrector, process.ak4PFPuppiL1OffsetCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4PFL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1FastL2L3ResidualCorrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4CaloL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4CaloL1FastL2L3ResidualCorrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloResidualCorrector)


process.ak4PFCHSL1FastL2L3CorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3Corrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFL1L2L3ResidualCorrector, process.ak4PFL1OffsetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4PFL2L3ResidualCorrectorTask = cms.Task(process.ak4PFL2L3ResidualCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFResidualCorrector)


process.ak4JPTL1L2L3CorrectorTask = cms.Task(process.ak4JPTL1L2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTOffsetCorrectorTask)


process.ak4PFCHSL2L3CorrectorTask = cms.Task(process.ak4PFCHSL2L3Corrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4CaloL2L3CorrectorTask = cms.Task(process.ak4CaloL2L3Corrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector)


process.ak4PFL1FastL2L3L6CorrectorTask = cms.Task(process.ak4PFL1FastL2L3L6Corrector, process.ak4PFL1FastjetCorrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector, process.ak4PFL6SLBCorrector)


process.ak4PFCHSL1L2L3CorrectorTask = cms.Task(process.ak4PFCHSL1L2L3Corrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector)


process.ak4PFCHSL1L2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1L2L3ResidualCorrector, process.ak4PFCHSL1OffsetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFPuppiL2L3ResidualCorrectorTask = cms.Task(process.ak4PFPuppiL2L3ResidualCorrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector, process.ak4PFPuppiResidualCorrector)


process.ak4PFPuppiL2L3CorrectorTask = cms.Task(process.ak4PFPuppiL2L3Corrector, process.ak4PFPuppiL2RelativeCorrector, process.ak4PFPuppiL3AbsoluteCorrector)


process.ak4JPTL1FastL2L3CorrectorTask = cms.Task(process.ak4JPTL1FastL2L3Corrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4PFCHSL1FastL2L3ResidualCorrector, process.ak4PFCHSL1FastjetCorrector, process.ak4PFCHSL2RelativeCorrector, process.ak4PFCHSL3AbsoluteCorrector, process.ak4PFCHSResidualCorrector)


process.ak4PFL2L3CorrectorTask = cms.Task(process.ak4PFL2L3Corrector, process.ak4PFL2RelativeCorrector, process.ak4PFL3AbsoluteCorrector)


process.ak4CaloL1FastL2L3L6CorrectorTask = cms.Task(process.ak4CaloL1FastL2L3L6Corrector, process.ak4CaloL1FastjetCorrector, process.ak4CaloL2RelativeCorrector, process.ak4CaloL3AbsoluteCorrector, process.ak4CaloL6SLBCorrector)


process.ak4JPTL1FastL2L3ResidualCorrectorTask = cms.Task(process.ak4JPTL1FastL2L3ResidualCorrector, process.ak4JPTL2RelativeCorrector, process.ak4JPTL3AbsoluteCorrector, process.ak4JPTResidualCorrector, process.ak4L1JPTFastjetCorrectorTask)


process.jetCorrectorsTask = cms.Task(process.ak4CaloL1FastL2L3CorrectorTask, process.ak4CaloL1FastL2L3L6CorrectorTask, process.ak4CaloL1FastL2L3ResidualCorrectorTask, process.ak4CaloL1L2L3CorrectorTask, process.ak4CaloL1L2L3ResidualCorrectorTask, process.ak4CaloL2L3CorrectorTask, process.ak4CaloL2L3L6CorrectorTask, process.ak4CaloL2L3ResidualCorrectorTask, process.ak4JPTL1FastL2L3CorrectorTask, process.ak4JPTL1FastL2L3ResidualCorrectorTask, process.ak4JPTL1L2L3CorrectorTask, process.ak4JPTL1L2L3ResidualCorrectorTask, process.ak4JPTL2L3CorrectorTask, process.ak4JPTL2L3ResidualCorrectorTask, process.ak4L1JPTFastjetCorrectorTask, process.ak4L1JPTOffsetCorrectorTask, process.ak4PFCHSL1FastL2L3CorrectorTask, process.ak4PFCHSL1FastL2L3ResidualCorrectorTask, process.ak4PFCHSL1L2L3CorrectorTask, process.ak4PFCHSL1L2L3ResidualCorrectorTask, process.ak4PFCHSL2L3CorrectorTask, process.ak4PFCHSL2L3ResidualCorrectorTask, process.ak4PFL1FastL2L3CorrectorTask, process.ak4PFL1FastL2L3L6CorrectorTask, process.ak4PFL1FastL2L3ResidualCorrectorTask, process.ak4PFL1L2L3CorrectorTask, process.ak4PFL1L2L3ResidualCorrectorTask, process.ak4PFL2L3CorrectorTask, process.ak4PFL2L3L6CorrectorTask, process.ak4PFL2L3ResidualCorrectorTask, process.ak4PFPuppiL1FastL2L3CorrectorTask, process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask, process.ak4PFPuppiL1L2L3CorrectorTask, process.ak4PFPuppiL1L2L3ResidualCorrectorTask, process.ak4PFPuppiL2L3CorrectorTask, process.ak4PFPuppiL2L3ResidualCorrectorTask, process.ak4TrackL2L3CorrectorTask)


process.ak4JPTL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3L6CorrectorTask)


process.ak4L1JPTOffsetCorrectorChain = cms.Sequence(process.ak4L1JPTOffsetCorrectorTask)


process.ak4TrackL2L3CorrectorChain = cms.Sequence(process.ak4TrackL2L3CorrectorTask)


process.ak4PFPuppiL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3ResidualCorrectorTask)


process.flashggTagSequence = cms.Sequence(process.flashggPrefireDiPhotons+process.flashggPreselectedDiPhotons+process.flashggDiPhotonMVA+process.flashggVBFMVA+process.flashggVHhadMVA+process.flashggVBFDiPhoDiJetMVA+process.flashggUntagged+process.flashggTTHLeptonicTag+process.flashggTHQLeptonicTag+process.flashggTTHHadronicTag+process.flashggTagSorter)


process.ak4JPTL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3ResidualCorrectorTask)


process.ak4PFL2L3L6CorrectorChain = cms.Sequence(process.ak4PFL2L3L6CorrectorTask)


process.ak4PFL1L2L3CorrectorChain = cms.Sequence(process.ak4PFL1L2L3CorrectorTask)


process.ak4PFCHSL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3CorrectorTask)


process.ak4CaloL1L2L3CorrectorChain = cms.Sequence(process.ak4CaloL1L2L3CorrectorTask)


process.finalFilter = cms.Sequence()


process.ak4PFCHSL1L2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3CorrectorTask)


process.genFilter = cms.Sequence()


process.ak4CaloL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3ResidualCorrectorTask)


process.ak4PFL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3CorrectorTask)


process.jetCorrectorChain = cms.Sequence(process.ak4PFCHSL1FastL2L3CorrectorChain)


process.ak4CaloL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL2L3L6CorrectorTask)


process.penultimateFilter = cms.Sequence()


process.ak4JPTL2L3CorrectorChain = cms.Sequence(process.ak4JPTL2L3CorrectorTask)


process.ak4CaloL2L3CorrectorChain = cms.Sequence(process.ak4CaloL2L3CorrectorTask)


process.ak4JPTL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4JPTL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3ResidualCorrectorTask)


process.ak4PFPuppiL1FastL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3CorrectorTask)


process.ak4PFL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1FastL2L3ResidualCorrectorTask)


process.extraDumpers = cms.Sequence()


process.ak4L1JPTFastjetCorrectorChain = cms.Sequence(process.ak4L1JPTFastjetCorrectorTask)


process.ak4JPTL1L2L3CorrectorChain = cms.Sequence(process.ak4JPTL1L2L3CorrectorTask)


process.ak4PFPuppiL1FastL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFPuppiL1FastL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL2L3ResidualCorrectorTask)


process.dataRequirements = cms.Sequence()


process.jetSystematicsSequence = cms.Sequence(process.jetCorrectorChain+process.flashggJetSystematics0+process.flashggJetSystematics1+process.flashggJetSystematics2+process.flashggJetSystematics3+process.flashggJetSystematics4+process.flashggJetSystematics5+process.flashggJetSystematics6+process.flashggJetSystematics7+process.flashggJetSystematics8+process.flashggJetSystematics9+process.flashggJetSystematics10+process.flashggJetSystematics11)


process.systematicsTagSequences = cms.Sequence()


process.ak4CaloL1FastL2L3L6CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3L6CorrectorTask)


process.ak4PFL2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL2L3ResidualCorrectorTask)


process.ak4PFCHSL2L3CorrectorChain = cms.Sequence(process.ak4PFCHSL2L3CorrectorTask)


process.ak4PFPuppiL1L2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL1L2L3CorrectorTask)


process.ak4CaloL2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL2L3ResidualCorrectorTask)


process.ak4PFCHSL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFCHSL1L2L3ResidualCorrectorTask)


process.ak4PFL2L3CorrectorChain = cms.Sequence(process.ak4PFL2L3CorrectorTask)


process.ak4CaloL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4CaloL1L2L3ResidualCorrectorTask)


process.ak4CaloL1FastL2L3CorrectorChain = cms.Sequence(process.ak4CaloL1FastL2L3CorrectorTask)


process.ak4PFPuppiL2L3CorrectorChain = cms.Sequence(process.ak4PFPuppiL2L3CorrectorTask)


process.ak4JPTL1FastL2L3CorrectorChain = cms.Sequence(process.ak4JPTL1FastL2L3CorrectorTask)


process.ak4PFL1L2L3ResidualCorrectorChain = cms.Sequence(process.ak4PFL1L2L3ResidualCorrectorTask)


process.p = cms.Path(process.dataRequirements+process.flashggMetFilters+process.genFilter+process.flashggDifferentialPhoIdInputsCorrection+process.flashggDiPhotonSystematics+process.flashggMetSystematics+process.flashggMuonSystematics+process.flashggElectronSystematics+process.flashggUnpackedJets+process.jetSystematicsSequence+process.flashggTagSequence+process.systematicsTagSequences+process.flashggSystTagMerger+process.penultimateFilter+process.finalFilter+process.tagsDumper)


